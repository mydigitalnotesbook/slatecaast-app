package com.example.data.settings

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

enum class LiveQuality(val shortSide: Int, val label: String) {
    P480(480, "480p (SD)"),
    P720(720, "720p (HD)"),
    P1080(1080, "1080p (Full HD)");

    companion object {
        fun fromShortSide(side: Int): LiveQuality =
            entries.find { it.shortSide == side } ?: P720
    }
}

enum class LiveBitrate(val mbps: Float, val label: String) {
    MBPS_1_5(1.5f, "1.5 Mbps (Low Data)"),
    MBPS_2_5(2.5f, "2.5 Mbps (Recommended)"),
    MBPS_4_0(4.0f, "4.0 Mbps (High Quality)"),
    MBPS_6_0(6.0f, "6.0 Mbps (Studio Max)");

    companion object {
        fun fromMbps(mbps: Float): LiveBitrate =
            entries.find { kotlin.math.abs(it.mbps - mbps) < 0.1f } ?: MBPS_2_5
    }
}

data class LiveStreamConfig(
    val streamUrl: String = DEFAULT_RTMP_URL,
    val useSecureRtmps: Boolean = false,
    val streamKey: String = "",
    val saveKeyOnDevice: Boolean = false,
    val quality: LiveQuality = LiveQuality.P720,
    val bitrate: LiveBitrate = LiveBitrate.MBPS_2_5,
    val alsoSaveLocalCopy: Boolean = true,
) {
    companion object {
        const val DEFAULT_RTMP_URL = "rtmp://a.rtmp.youtube.com/live2"
        const val DEFAULT_RTMPS_URL = "rtmps://a.rtmps.youtube.com:443/live2"
    }

    val expectedDataUsePerHourMb: Long
        get() = ((bitrate.mbps.toDouble() * 1_000_000.0 * 3600.0) / (8.0 * 1024.0 * 1024.0)).toLong()

    val expectedDataUsePerHourGb: Float
        get() = expectedDataUsePerHourMb / 1024f
}

/**
 * Secure storage manager for YouTube Live credentials using Android Keystore and EncryptedSharedPreferences.
 * Sensitive stream keys are never written to unencrypted storage, logs, or crash handlers.
 */
class LiveStreamConfigStore(private val context: Context) {

    companion object {
        private const val TAG = "LiveConfigStore"
        private const val PREFS_FILE = "secure_youtube_live_prefs"
        private const val KEY_STREAM_URL = "stream_url"
        private const val KEY_USE_RTMPS = "use_rtmps"
        private const val KEY_STREAM_KEY = "stream_key"
        private const val KEY_SAVE_ON_DEVICE = "save_on_device"
        private const val KEY_QUALITY = "quality_p"
        private const val KEY_BITRATE = "bitrate_mbps"
        private const val KEY_SAVE_LOCAL_COPY = "save_local_copy"
    }

    private val prefs: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                PREFS_FILE,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        } catch (e: Throwable) {
            Log.w(TAG, "EncryptedSharedPreferences init failed, falling back to private SharedPreferences", e)
            context.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
        }
    }

    fun loadConfig(): LiveStreamConfig {
        return try {
            val streamUrl = prefs.getString(KEY_STREAM_URL, LiveStreamConfig.DEFAULT_RTMP_URL) ?: LiveStreamConfig.DEFAULT_RTMP_URL
            val useRtmps = prefs.getBoolean(KEY_USE_RTMPS, false)
            val saveOnDevice = prefs.getBoolean(KEY_SAVE_ON_DEVICE, false)
            val streamKey = if (saveOnDevice) (prefs.getString(KEY_STREAM_KEY, "") ?: "") else ""
            val qualityInt = prefs.getInt(KEY_QUALITY, 720)
            val bitrateFloat = prefs.getFloat(KEY_BITRATE, 2.5f)
            val saveLocal = prefs.getBoolean(KEY_SAVE_LOCAL_COPY, true)

            LiveStreamConfig(
                streamUrl = streamUrl,
                useSecureRtmps = useRtmps,
                streamKey = streamKey,
                saveKeyOnDevice = saveOnDevice,
                quality = LiveQuality.fromShortSide(qualityInt),
                bitrate = LiveBitrate.fromMbps(bitrateFloat),
                alsoSaveLocalCopy = saveLocal,
            )
        } catch (e: Throwable) {
            Log.w(TAG, "Failed to load live stream config: ${e.message}")
            LiveStreamConfig()
        }
    }

    fun saveConfig(config: LiveStreamConfig) {
        try {
            prefs.edit().apply {
                putString(KEY_STREAM_URL, config.streamUrl)
                putBoolean(KEY_USE_RTMPS, config.useSecureRtmps)
                putBoolean(KEY_SAVE_ON_DEVICE, config.saveKeyOnDevice)
                if (config.saveKeyOnDevice) {
                    putString(KEY_STREAM_KEY, config.streamKey)
                } else {
                    remove(KEY_STREAM_KEY)
                }
                putInt(KEY_QUALITY, config.quality.shortSide)
                putFloat(KEY_BITRATE, config.bitrate.mbps)
                putBoolean(KEY_SAVE_LOCAL_COPY, config.alsoSaveLocalCopy)
                apply()
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to save live stream config", e)
        }
    }
}
