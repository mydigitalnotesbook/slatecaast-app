package com.example.data.settings

import android.content.Context
import android.media.MediaCodecList
import android.media.MediaFormat
import android.util.Size
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Aspect ratio options for lecture videos.
 */
enum class OutputAspectRatio(val labelResName: String, val shortDesc: String) {
    LANDSCAPE_16_9("aspect_16_9_label", "16:9 (1920x1080)"),
    PORTRAIT_9_16("aspect_9_16_label", "9:16 (1080x1920)"),
}

/**
 * Audio source options.
 */
enum class AudioSourceOption {
    MIC,
    CAMCORDER,
}

/**
 * Video codec options.
 */
enum class VideoCodecOption(val mimeType: String) {
    H264(MediaFormat.MIMETYPE_VIDEO_AVC),
    HEVC(MediaFormat.MIMETYPE_VIDEO_HEVC),
}

/**
 * Complete recorder configuration model.
 */
data class RecorderSettings(
    val audioSource: AudioSourceOption = AudioSourceOption.MIC,
    val audioBitrateKbps: Int = 128,
    val videoCodec: VideoCodecOption = VideoCodecOption.H264,
    val videoQuality: Int = 1080, // Short side (1080 or 720)
    val fps: Int = 30,
    val videoBitrateMbps: Int = 4,
    val defaultAspect: OutputAspectRatio = OutputAspectRatio.LANDSCAPE_16_9,
)

/**
 * Computes exact output resolution dimensions based on aspect ratio and short-side quality.
 * LANDSCAPE 1080 -> 1920x1080, PORTRAIT 1080 -> 1080x1920
 * LANDSCAPE 720  -> 1280x720,  PORTRAIT 720  -> 720x1280
 */
fun outputSize(aspect: OutputAspectRatio, quality: Int): Size {
    return when (aspect) {
        OutputAspectRatio.LANDSCAPE_16_9 -> {
            val width = if (quality <= 720) 1280 else 1920
            val height = if (quality <= 720) 720 else 1080
            Size(width, height)
        }
        OutputAspectRatio.PORTRAIT_9_16 -> {
            val width = if (quality <= 720) 720 else 1080
            val height = if (quality <= 720) 1280 else 1920
            Size(width, height)
        }
    }
}

/**
 * Checks whether hardware HEVC video encoder is supported on this device.
 */
fun isHevcSupported(): Boolean {
    return try {
        val codecList = MediaCodecList(MediaCodecList.REGULAR_CODECS)
        codecList.codecInfos.any { info ->
            info.isEncoder && info.supportedTypes.any { type ->
                type.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, ignoreCase = true)
            }
        }
    } catch (_: Exception) {
        false
    }
}

object CodecSupportUtils {
    fun isHevcSupported(): Boolean = com.example.data.settings.isHevcSupported()
}

val Context.recorderDataStore: DataStore<Preferences> by preferencesDataStore(name = "slatecast_recorder_settings")
