package com.example.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Settings repository managing recorder preferences backed by Jetpack DataStore Preferences.
 */
interface SettingsRepository {
    val settingsFlow: Flow<RecorderSettings>
    val defaultAspectFlow: Flow<OutputAspectRatio>

    suspend fun setAudioSource(source: AudioSourceOption)
    suspend fun setAudioBitrateKbps(kbps: Int)
    suspend fun setVideoCodec(codec: VideoCodecOption)
    suspend fun setVideoQuality(shortSidePx: Int)
    suspend fun setFps(fps: Int)
    suspend fun setVideoBitrateMbps(mbps: Int)
    suspend fun setDefaultAspect(aspect: OutputAspectRatio)
    suspend fun resetToDefaults()

    // Convenience aliases
    suspend fun updateAudioSource(source: AudioSourceOption) = setAudioSource(source)
    suspend fun updateAudioBitrate(kbps: Int) = setAudioBitrateKbps(kbps)
    suspend fun updateVideoCodec(codec: VideoCodecOption) = setVideoCodec(codec)
    suspend fun updateVideoQuality(quality: Int) = setVideoQuality(quality)
    suspend fun updateFps(fps: Int) = setFps(fps)
    suspend fun updateVideoBitrate(mbps: Int) = setVideoBitrateMbps(mbps)
    suspend fun updateDefaultAspect(aspect: OutputAspectRatio) = setDefaultAspect(aspect)
    suspend fun resetDefaults() = resetToDefaults()
}

open class DataStoreSettingsRepository(
    private val dataStore: DataStore<Preferences>,
) : SettingsRepository {

    constructor(context: Context) : this(context.recorderDataStore)

    private object Keys {
        val KEY_AUDIO_SOURCE = stringPreferencesKey("audio_source")
        val KEY_AUDIO_BITRATE = intPreferencesKey("audio_bitrate_kbps")
        val KEY_VIDEO_CODEC = stringPreferencesKey("video_codec")
        val KEY_VIDEO_QUALITY = intPreferencesKey("video_quality")
        val KEY_FPS = intPreferencesKey("video_fps")
        val KEY_VIDEO_BITRATE = intPreferencesKey("video_bitrate_mbps")
        val KEY_DEFAULT_ASPECT = stringPreferencesKey("default_aspect")
    }

    override val settingsFlow: Flow<RecorderSettings> = dataStore.data.map { prefs ->
        val audioSourceStr = prefs[Keys.KEY_AUDIO_SOURCE] ?: AudioSourceOption.MIC.name
        val audioSource = runCatching { AudioSourceOption.valueOf(audioSourceStr) }.getOrDefault(AudioSourceOption.MIC)

        val audioBitrate = prefs[Keys.KEY_AUDIO_BITRATE] ?: 128

        val videoCodecStr = prefs[Keys.KEY_VIDEO_CODEC] ?: VideoCodecOption.H264.name
        val videoCodec = runCatching { VideoCodecOption.valueOf(videoCodecStr) }.getOrDefault(VideoCodecOption.H264)

        val videoQuality = prefs[Keys.KEY_VIDEO_QUALITY] ?: 1080
        val fps = prefs[Keys.KEY_FPS] ?: 30
        val videoBitrate = prefs[Keys.KEY_VIDEO_BITRATE] ?: 4

        val defaultAspectStr = prefs[Keys.KEY_DEFAULT_ASPECT] ?: OutputAspectRatio.LANDSCAPE_16_9.name
        val defaultAspect = runCatching { OutputAspectRatio.valueOf(defaultAspectStr) }.getOrDefault(OutputAspectRatio.LANDSCAPE_16_9)

        RecorderSettings(
            audioSource = audioSource,
            audioBitrateKbps = audioBitrate,
            videoCodec = videoCodec,
            videoQuality = videoQuality,
            fps = fps,
            videoBitrateMbps = videoBitrate,
            defaultAspect = defaultAspect,
        )
    }

    override val defaultAspectFlow: Flow<OutputAspectRatio> = settingsFlow.map { it.defaultAspect }

    override suspend fun setAudioSource(source: AudioSourceOption) {
        dataStore.edit { prefs ->
            prefs[Keys.KEY_AUDIO_SOURCE] = source.name
        }
    }

    override suspend fun setAudioBitrateKbps(kbps: Int) {
        dataStore.edit { prefs ->
            prefs[Keys.KEY_AUDIO_BITRATE] = kbps
        }
    }

    override suspend fun setVideoCodec(codec: VideoCodecOption) {
        dataStore.edit { prefs ->
            prefs[Keys.KEY_VIDEO_CODEC] = codec.name
        }
    }

    override suspend fun setVideoQuality(shortSidePx: Int) {
        dataStore.edit { prefs ->
            prefs[Keys.KEY_VIDEO_QUALITY] = shortSidePx
        }
    }

    override suspend fun setFps(fps: Int) {
        dataStore.edit { prefs ->
            prefs[Keys.KEY_FPS] = fps
        }
    }

    override suspend fun setVideoBitrateMbps(mbps: Int) {
        dataStore.edit { prefs ->
            prefs[Keys.KEY_VIDEO_BITRATE] = mbps
        }
    }

    override suspend fun setDefaultAspect(aspect: OutputAspectRatio) {
        dataStore.edit { prefs ->
            prefs[Keys.KEY_DEFAULT_ASPECT] = aspect.name
        }
    }

    override suspend fun resetToDefaults() {
        dataStore.edit { prefs ->
            prefs.clear()
        }
    }
}

class SettingsRepositoryImpl(dataStore: DataStore<Preferences>) : DataStoreSettingsRepository(dataStore) {
    constructor(context: Context) : this(context.recorderDataStore)
}

@androidx.compose.runtime.Composable
fun rememberSettingsRepository(): SettingsRepository {
    val context = androidx.compose.ui.platform.LocalContext.current.applicationContext
    return androidx.compose.runtime.remember { DataStoreSettingsRepository(context) }
}
