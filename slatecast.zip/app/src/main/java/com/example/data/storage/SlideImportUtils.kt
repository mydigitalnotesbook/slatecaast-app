package com.example.data.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.example.data.settings.OutputAspectRatio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/**
 * Slide import helpers for PDF rendering and image conversions.
 */
object SlideImportUtils {

    /**
     * Renders EVERY page of a selected PDF into JPEG (quality 90).
     * Page width = 1920 for landscape projects or 1080 for portrait projects, keeping page ratio.
     * Runs strictly on Dispatchers.IO, notifies progress (pageIndex, totalPages), and frees each Bitmap immediately.
     */
    suspend fun importPdfPages(
        context: Context,
        pdfUri: Uri,
        projectId: String,
        aspect: OutputAspectRatio,
        onProgress: (current: Int, total: Int) -> Unit,
    ): List<File> = withContext(Dispatchers.IO) {
        val targetWidth = if (aspect == OutputAspectRatio.LANDSCAPE_16_9) 1920 else 1080
        val projectSlidesDir = File(File(context.filesDir, "projects/$projectId"), "slides").apply { mkdirs() }
        val generatedFiles = mutableListOf<File>()

        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null

        try {
            pfd = context.contentResolver.openFileDescriptor(pdfUri, "r")
                ?: return@withContext emptyList()
            renderer = PdfRenderer(pfd)
            val pageCount = renderer.pageCount

            for (i in 0 until pageCount) {
                val page = renderer.openPage(i)
                val origWidth = page.width
                val origHeight = page.height

                val renderWidth = targetWidth
                val renderHeight = if (origWidth > 0) {
                    ((renderWidth.toFloat() / origWidth.toFloat()) * origHeight).toInt().coerceAtLeast(100)
                } else {
                    if (aspect == OutputAspectRatio.LANDSCAPE_16_9) 1080 else 1920
                }

                val bitmap = Bitmap.createBitmap(renderWidth, renderHeight, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                canvas.drawColor(Color.WHITE) // PDF backgrounds are transparent by default

                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()

                val outFile = File(projectSlidesDir, "pdf_page_${System.currentTimeMillis()}_${i + 1}.jpg")
                FileOutputStream(outFile).use { fos ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
                }
                bitmap.recycle() // CRITICAL: Free each Bitmap after saving

                generatedFiles.add(outFile)
                withContext(Dispatchers.Main) {
                    onProgress(i + 1, pageCount)
                }
            }
        } catch (_: Exception) {
            // gracefully return whatever pages were processed
        } finally {
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
        }

        generatedFiles
    }

    /**
     * Imports user selected images from Photo Picker into project slides directory.
     * Scales to fit target width and saves as JPEG (quality 90).
     */
    suspend fun importImages(
        context: Context,
        imageUris: List<Uri>,
        projectId: String,
        aspect: OutputAspectRatio,
    ): List<File> = withContext(Dispatchers.IO) {
        val targetWidth = if (aspect == OutputAspectRatio.LANDSCAPE_16_9) 1920 else 1080
        val projectSlidesDir = File(File(context.filesDir, "projects/$projectId"), "slides").apply { mkdirs() }
        val importedFiles = mutableListOf<File>()

        for ((index, uri) in imageUris.withIndex()) {
            var inputStream: InputStream? = null
            try {
                inputStream = context.contentResolver.openInputStream(uri)
                val originalBitmap = BitmapFactory.decodeStream(inputStream)
                if (originalBitmap != null) {
                    val origWidth = originalBitmap.width
                    val origHeight = originalBitmap.height

                    val scaleFactor = targetWidth.toFloat() / origWidth.toFloat()
                    val targetHeight = (origHeight * scaleFactor).toInt().coerceAtLeast(100)

                    val scaledBitmap = Bitmap.createScaledBitmap(originalBitmap, targetWidth, targetHeight, true)
                    if (scaledBitmap != originalBitmap) {
                        originalBitmap.recycle()
                    }

                    val outFile = File(projectSlidesDir, "img_${System.currentTimeMillis()}_${index}.jpg")
                    FileOutputStream(outFile).use { fos ->
                        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
                    }
                    scaledBitmap.recycle()
                    importedFiles.add(outFile)
                }
            } catch (_: Exception) {
                // Ignore corrupt images
            } finally {
                try { inputStream?.close() } catch (_: Exception) {}
            }
        }

        importedFiles
    }

    /**
     * Copies and processes a camera captured photo into the project slides folder.
     */
    suspend fun importCameraPhoto(
        tempCameraFile: File,
        projectId: String,
        aspect: OutputAspectRatio,
    ): File? = withContext(Dispatchers.IO) {
        if (!tempCameraFile.exists() || tempCameraFile.length() == 0L) return@withContext null
        val targetWidth = if (aspect == OutputAspectRatio.LANDSCAPE_16_9) 1920 else 1080
        val projectSlidesDir = File(File(tempCameraFile.parentFile?.parentFile ?: return@withContext null, "projects/$projectId"), "slides").apply { mkdirs() }

        try {
            val originalBitmap = BitmapFactory.decodeFile(tempCameraFile.absolutePath) ?: return@withContext null
            val origWidth = originalBitmap.width
            val origHeight = originalBitmap.height
            val scaleFactor = targetWidth.toFloat() / origWidth.toFloat()
            val targetHeight = (origHeight * scaleFactor).toInt().coerceAtLeast(100)

            val scaledBitmap = Bitmap.createScaledBitmap(originalBitmap, targetWidth, targetHeight, true)
            if (scaledBitmap != originalBitmap) {
                originalBitmap.recycle()
            }

            val outFile = File(projectSlidesDir, "camera_${System.currentTimeMillis()}.jpg")
            FileOutputStream(outFile).use { fos ->
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
            }
            scaledBitmap.recycle()
            tempCameraFile.delete()
            outFile
        } catch (_: Exception) {
            null
        }
    }
}
