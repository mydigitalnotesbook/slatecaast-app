package com.example.data.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.example.data.settings.OutputAspectRatio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

/**
 * Slide model representing one slide inside a lecture project.
 */
data class SlideItem(
    val id: String = UUID.randomUUID().toString(),
    val filePath: String,
    val pageNumber: Int,
    val sourceType: String = "image", // image, pdf, camera, blank_white, blank_black
    val createdAt: Long = System.currentTimeMillis(),
)

/**
 * Project model representing a lecture presentation.
 */
data class ProjectInfo(
    val id: String,
    val title: String,
    val aspectRatio: OutputAspectRatio = OutputAspectRatio.LANDSCAPE_16_9,
    val createdAt: Long = System.currentTimeMillis(),
    val lastModified: Long = System.currentTimeMillis(),
    val slides: List<SlideItem> = emptyList(),
)

/**
 * Enhanced Project Repository for reading, creating, and modifying slide decks.
 */
interface SlideProjectRepository : ProjectRepository {
    fun getProjectFlow(projectId: String): Flow<ProjectInfo?>
    suspend fun getProject(projectId: String): ProjectInfo?
    suspend fun saveProject(project: ProjectInfo)
    suspend fun addSlidesToProject(projectId: String, newSlideFiles: List<File>, sourceType: String)
    suspend fun addBlankSlide(projectId: String, isWhite: Boolean): SlideItem
    suspend fun addWebSlide(projectId: String, initialUrl: String = "https://en.wikipedia.org"): SlideItem
    suspend fun deleteSlide(projectId: String, slideId: String)
    suspend fun reorderSlides(projectId: String, fromIndex: Int, toIndex: Int)
    suspend fun deleteProject(projectId: String)
    fun createTempCameraFile(): File
}

class SlideProjectRepositoryImpl(
    private val context: Context,
) : SlideProjectRepository {

    private val projectsDir = File(context.filesDir, "projects").apply { mkdirs() }

    private val _projectCount = MutableStateFlow(0)
    override val projectCountFlow: Flow<Int> = _projectCount.asStateFlow()

    private val _lastModified = MutableStateFlow<Long?>(null)
    override val lastModifiedFlow: Flow<Long?> = _lastModified.asStateFlow()

    private val projectFlows = mutableMapOf<String, MutableStateFlow<ProjectInfo?>>()

    init {
        refreshMetadata()
    }

    private fun refreshMetadata() {
        val dirs = projectsDir.listFiles()?.filter { it.isDirectory } ?: emptyList()
        _projectCount.value = dirs.size
        _lastModified.value = dirs.maxOfOrNull { it.lastModified() }
    }

    private fun getProjectDir(projectId: String): File {
        return File(projectsDir, projectId).apply { mkdirs() }
    }

    private fun getSlidesDir(projectId: String): File {
        return File(getProjectDir(projectId), "slides").apply { mkdirs() }
    }

    private fun getProjectJsonFile(projectId: String): File {
        return File(getProjectDir(projectId), "project.json")
    }

    @Synchronized
    private fun getOrCreateFlow(projectId: String): MutableStateFlow<ProjectInfo?> {
        return projectFlows.getOrPut(projectId) {
            MutableStateFlow(loadProjectSync(projectId))
        }
    }

    private fun loadProjectSync(projectId: String): ProjectInfo? {
        val jsonFile = getProjectJsonFile(projectId)
        if (!jsonFile.exists()) {
            // Check if aspect ratio is encoded in projectId
            val aspect = if (projectId.contains("9x16") || projectId.contains("PORTRAIT")) {
                OutputAspectRatio.PORTRAIT_9_16
            } else {
                OutputAspectRatio.LANDSCAPE_16_9
            }
            val title = projectId.replace('_', ' ').replaceFirstChar { it.uppercase() }
            val newProject = ProjectInfo(
                id = projectId,
                title = title,
                aspectRatio = aspect,
                createdAt = System.currentTimeMillis(),
                lastModified = System.currentTimeMillis(),
                slides = emptyList(),
            )
            saveProjectSync(newProject)
            return newProject
        }

        return try {
            val jsonStr = jsonFile.readText()
            val json = JSONObject(jsonStr)
            val aspectStr = json.optString("aspectRatio", OutputAspectRatio.LANDSCAPE_16_9.name)
            val aspect = runCatching { OutputAspectRatio.valueOf(aspectStr) }.getOrDefault(OutputAspectRatio.LANDSCAPE_16_9)

            val slidesArray = json.optJSONArray("slides") ?: JSONArray()
            val slides = mutableListOf<SlideItem>()
            for (i in 0 until slidesArray.length()) {
                val sObj = slidesArray.getJSONObject(i)
                val file = File(sObj.getString("filePath"))
                if (file.exists()) {
                    slides.add(
                        SlideItem(
                            id = sObj.optString("id", UUID.randomUUID().toString()),
                            filePath = sObj.getString("filePath"),
                            pageNumber = sObj.optInt("pageNumber", i + 1),
                            sourceType = sObj.optString("sourceType", "image"),
                            createdAt = sObj.optLong("createdAt", System.currentTimeMillis()),
                        )
                    )
                }
            }
            ProjectInfo(
                id = json.getString("id"),
                title = json.optString("title", projectId),
                aspectRatio = aspect,
                createdAt = json.optLong("createdAt", System.currentTimeMillis()),
                lastModified = json.optLong("lastModified", System.currentTimeMillis()),
                slides = slides,
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun saveProjectSync(project: ProjectInfo) {
        val jsonFile = getProjectJsonFile(project.id)
        val json = JSONObject().apply {
            put("id", project.id)
            put("title", project.title)
            put("aspectRatio", project.aspectRatio.name)
            put("createdAt", project.createdAt)
            put("lastModified", System.currentTimeMillis())

            val slidesArray = JSONArray()
            project.slides.forEachIndexed { index, slide ->
                val sObj = JSONObject().apply {
                    put("id", slide.id)
                    put("filePath", slide.filePath)
                    put("pageNumber", index + 1)
                    put("sourceType", slide.sourceType)
                    put("createdAt", slide.createdAt)
                }
                slidesArray.put(sObj)
            }
            put("slides", slidesArray)
        }
        jsonFile.writeText(json.toString(2))
        getProjectDir(project.id).setLastModified(System.currentTimeMillis())
        refreshMetadata()
    }

    override fun getProjectFlow(projectId: String): Flow<ProjectInfo?> {
        return getOrCreateFlow(projectId).asStateFlow()
    }

    override suspend fun getProject(projectId: String): ProjectInfo? = withContext(Dispatchers.IO) {
        loadProjectSync(projectId)
    }

    override suspend fun saveProject(project: ProjectInfo) = withContext(Dispatchers.IO) {
        saveProjectSync(project)
        getOrCreateFlow(project.id).value = project
    }

    override suspend fun addSlidesToProject(
        projectId: String,
        newSlideFiles: List<File>,
        sourceType: String,
    ) = withContext(Dispatchers.IO) {
        val current = loadProjectSync(projectId) ?: return@withContext
        val updatedSlides = current.slides.toMutableList()

        newSlideFiles.forEach { file ->
            val nextNumber = updatedSlides.size + 1
            updatedSlides.add(
                SlideItem(
                    id = UUID.randomUUID().toString(),
                    filePath = file.absolutePath,
                    pageNumber = nextNumber,
                    sourceType = sourceType,
                    createdAt = System.currentTimeMillis(),
                )
            )
        }

        val updated = current.copy(
            slides = updatedSlides,
            lastModified = System.currentTimeMillis(),
        )
        saveProjectSync(updated)
        getOrCreateFlow(projectId).value = updated
    }

    override suspend fun addBlankSlide(projectId: String, isWhite: Boolean): SlideItem = withContext(Dispatchers.IO) {
        val current = loadProjectSync(projectId) ?: ProjectInfo(id = projectId, title = "New Lecture")
        val isLandscape = current.aspectRatio == OutputAspectRatio.LANDSCAPE_16_9
        val width = if (isLandscape) 1920 else 1080
        val height = if (isLandscape) 1080 else 1920

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(if (isWhite) Color.WHITE else Color.BLACK)

        val slidesDir = getSlidesDir(projectId)
        val fileName = "blank_${if (isWhite) "white" else "black"}_${System.currentTimeMillis()}.jpg"
        val file = File(slidesDir, fileName)

        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        bitmap.recycle() // Free bitmap memory immediately

        val newSlide = SlideItem(
            id = UUID.randomUUID().toString(),
            filePath = file.absolutePath,
            pageNumber = current.slides.size + 1,
            sourceType = if (isWhite) "blank_white" else "blank_black",
        )

        val updated = current.copy(
            slides = current.slides + newSlide,
            lastModified = System.currentTimeMillis(),
        )
        saveProjectSync(updated)
        getOrCreateFlow(projectId).value = updated
        newSlide
    }

    override suspend fun addWebSlide(projectId: String, initialUrl: String): SlideItem = withContext(Dispatchers.IO) {
        val current = loadProjectSync(projectId) ?: ProjectInfo(id = projectId, title = "New Lecture")
        val isLandscape = current.aspectRatio == OutputAspectRatio.LANDSCAPE_16_9
        val width = if (isLandscape) 1920 else 1080
        val height = if (isLandscape) 1080 else 1920

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.parseColor("#14171E"))
        val paint = android.graphics.Paint().apply {
            color = Color.WHITE
            textSize = 50f
            textAlign = android.graphics.Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("Web Slide", width / 2f, height / 2f - 40f, paint)
        paint.textSize = 32f
        paint.color = Color.LTGRAY
        canvas.drawText(initialUrl, width / 2f, height / 2f + 40f, paint)

        val slidesDir = getSlidesDir(projectId)
        val fileName = "web_${System.currentTimeMillis()}.jpg"
        val file = File(slidesDir, fileName)

        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        bitmap.recycle()

        val newSlide = SlideItem(
            id = java.util.UUID.randomUUID().toString(),
            filePath = file.absolutePath,
            pageNumber = current.slides.size + 1,
            sourceType = "web",
        )

        val updated = current.copy(
            slides = current.slides + newSlide,
            lastModified = System.currentTimeMillis(),
        )
        saveProjectSync(updated)
        getOrCreateFlow(projectId).value = updated
        newSlide
    }

    override suspend fun deleteSlide(projectId: String, slideId: String) = withContext(Dispatchers.IO) {
        val current = loadProjectSync(projectId) ?: return@withContext
        val slideToDelete = current.slides.find { it.id == slideId }
        slideToDelete?.let {
            val f = File(it.filePath)
            if (f.exists()) f.delete()
        }

        val remaining = current.slides.filter { it.id != slideId }.mapIndexed { index, item ->
            item.copy(pageNumber = index + 1)
        }
        val updated = current.copy(slides = remaining, lastModified = System.currentTimeMillis())
        saveProjectSync(updated)
        getOrCreateFlow(projectId).value = updated
    }

    override suspend fun reorderSlides(projectId: String, fromIndex: Int, toIndex: Int) = withContext(Dispatchers.IO) {
        val current = loadProjectSync(projectId) ?: return@withContext
        if (fromIndex !in current.slides.indices || toIndex !in current.slides.indices || fromIndex == toIndex) {
            return@withContext
        }
        val list = current.slides.toMutableList()
        val item = list.removeAt(fromIndex)
        list.add(toIndex, item)

        val reindexed = list.mapIndexed { index, s -> s.copy(pageNumber = index + 1) }
        val updated = current.copy(slides = reindexed, lastModified = System.currentTimeMillis())
        saveProjectSync(updated)
        getOrCreateFlow(projectId).value = updated
    }

    override suspend fun deleteProject(projectId: String) = withContext(Dispatchers.IO) {
        val dir = getProjectDir(projectId)
        if (dir.exists()) {
            dir.deleteRecursively()
        }
        projectFlows.remove(projectId)
        refreshMetadata()
    }

    override fun createTempCameraFile(): File {
        val cameraDir = File(context.cacheDir, "camera_captures").apply { mkdirs() }
        return File(cameraDir, "photo_${System.currentTimeMillis()}.jpg")
    }
}
