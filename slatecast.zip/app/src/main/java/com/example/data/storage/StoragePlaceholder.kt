package com.example.data.storage

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Project repository providing counts and metadata for lecture slide projects.
 */
interface ProjectRepository {
    val projectCountFlow: Flow<Int>
    val lastModifiedFlow: Flow<Long?>
}

class ProjectRepositoryImpl(
    private val context: Context? = null,
) : ProjectRepository {
    private val _count = MutableStateFlow(0)
    override val projectCountFlow: Flow<Int> = _count.asStateFlow()

    private val _lastModified = MutableStateFlow<Long?>(null)
    override val lastModifiedFlow: Flow<Long?> = _lastModified.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        if (context != null) {
            val projectsDir = File(context.filesDir, "projects")
            if (projectsDir.exists() && projectsDir.isDirectory) {
                val list = projectsDir.listFiles()?.filter { it.isDirectory } ?: emptyList()
                _count.value = list.size
                _lastModified.value = list.maxOfOrNull { it.lastModified() }
                return
            }
        }
        _count.value = 0
        _lastModified.value = null
    }
}

data class VideoItem(
    val id: String,
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateAddedMs: Long,
    val width: Int,
    val height: Int,
    val filePath: String? = null,
) {
    val aspectBadge: String
        get() = if (width > 0 && height > 0) {
            if (width >= height) "16:9" else "9:16"
        } else {
            "16:9"
        }

    val formattedDuration: String
        get() {
            val totalSeconds = (durationMs / 1000).coerceAtLeast(0)
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            val hours = minutes / 60
            return if (hours > 0) {
                String.format(java.util.Locale.US, "%d:%02d:%02d", hours, minutes % 60, seconds)
            } else {
                String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds)
            }
        }

    val formattedSize: String
        get() {
            val mb = sizeBytes / (1024.0 * 1024.0)
            return if (mb >= 1.0) {
                String.format(java.util.Locale.US, "%.1f MB", mb)
            } else {
                val kb = sizeBytes / 1024.0
                String.format(java.util.Locale.US, "%.0f KB", kb)
            }
        }

    val formattedDate: String
        get() {
            return if (dateAddedMs > 0) {
                java.text.SimpleDateFormat("MMM d, yyyy • h:mm a", java.util.Locale.getDefault()).format(java.util.Date(dateAddedMs))
            } else {
                ""
            }
        }
}

/**
 * Video store providing counts, listVideos, rename, and delete for recorded MP4 lectures.
 */
interface VideoStore {
    val videoCountFlow: Flow<Int>
    val lastModifiedFlow: Flow<Long?>
    suspend fun listVideos(): List<VideoItem>
    suspend fun renameVideo(item: VideoItem, newNameWithoutExt: String): Boolean
    suspend fun deleteVideo(item: VideoItem): Boolean
}

class VideoStoreImpl(
    private val context: Context? = null,
) : VideoStore {
    private val _count = MutableStateFlow(0)
    override val videoCountFlow: Flow<Int> = _count.asStateFlow()

    private val _lastModified = MutableStateFlow<Long?>(null)
    override val lastModifiedFlow: Flow<Long?> = _lastModified.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        if (context != null) {
            val videos = listVideosInternal()
            _count.value = videos.size
            _lastModified.value = videos.maxOfOrNull { it.dateAddedMs }
            return
        }
        _count.value = 0
        _lastModified.value = null
    }

    override suspend fun listVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val list = listVideosInternal()
        _count.value = list.size
        _lastModified.value = list.maxOfOrNull { it.dateAddedMs }
        list
    }

    private fun listVideosInternal(): List<VideoItem> {
        val ctx = context ?: return emptyList()
        val items = mutableListOf<VideoItem>()
        val seenUris = mutableSetOf<String>()

        // 1. Query MediaStore
        try {
            val resolver = ctx.contentResolver
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.WIDTH,
                MediaStore.Video.Media.HEIGHT,
            )
            val appName = try { ctx.getString(com.example.R.string.app_name) } catch (_: Throwable) { "SlateCast" }
            val selection: String?
            val selectionArgs: Array<String>?
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                selection = "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ? OR ${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?"
                selectionArgs = arrayOf("%$appName%", "Lecture_%")
            } else {
                selection = "${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?"
                selectionArgs = arrayOf("Lecture_%")
            }

            resolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val contentUri = android.content.ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val name = cursor.getString(nameCol) ?: "Lecture_$id.mp4"
                    val duration = cursor.getLong(durCol)
                    val size = cursor.getLong(sizeCol)
                    val dateAddedSeconds = cursor.getLong(dateCol)
                    val width = cursor.getInt(widthCol)
                    val height = cursor.getInt(heightCol)

                    seenUris.add(contentUri.toString())
                    items.add(
                        VideoItem(
                            id = id.toString(),
                            uri = contentUri,
                            name = name,
                            durationMs = duration,
                            sizeBytes = size,
                            dateAddedMs = dateAddedSeconds * 1000L,
                            width = width,
                            height = height,
                        )
                    )
                }
            }
        } catch (_: Throwable) {
            // MediaStore query failed (e.g. permission or JVM test environment)
        }

        // 2. Query fallback local app files directory (context.filesDir/lectures)
        try {
            val fallbackDir = File(ctx.filesDir, "lectures")
            if (fallbackDir.exists() && fallbackDir.isDirectory) {
                val files = fallbackDir.listFiles()?.filter { it.extension.equals("mp4", ignoreCase = true) } ?: emptyList()
                for (file in files) {
                    val fileUri = Uri.fromFile(file)
                    if (fileUri.toString() !in seenUris) {
                        var durationMs = 0L
                        var width = 0
                        var height = 0
                        try {
                            val retriever = android.media.MediaMetadataRetriever()
                            retriever.setDataSource(file.absolutePath)
                            val durStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
                            val wStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                            val hStr = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                            durationMs = durStr?.toLongOrNull() ?: 0L
                            width = wStr?.toIntOrNull() ?: 0
                            height = hStr?.toIntOrNull() ?: 0
                            retriever.release()
                        } catch (_: Throwable) {}

                        items.add(
                            VideoItem(
                                id = file.name,
                                uri = fileUri,
                                name = file.name,
                                durationMs = durationMs,
                                sizeBytes = file.length(),
                                dateAddedMs = file.lastModified(),
                                width = width,
                                height = height,
                                filePath = file.absolutePath,
                            )
                        )
                    }
                }
            }
        } catch (_: Throwable) {}

        return items.sortedByDescending { it.dateAddedMs }
    }

    override suspend fun renameVideo(item: VideoItem, newNameWithoutExt: String): Boolean = withContext(Dispatchers.IO) {
        val cleanName = newNameWithoutExt.trim().removeSuffix(".mp4")
        if (cleanName.isBlank()) return@withContext false
        val newFullName = "$cleanName.mp4"
        val ctx = context ?: return@withContext false

        var success = false
        if (item.uri.scheme == "content") {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, newFullName)
                }
                val count = ctx.contentResolver.update(item.uri, values, null, null)
                success = count > 0
            } catch (_: Throwable) {}
        }

        if (!success && item.filePath != null) {
            val oldFile = File(item.filePath)
            if (oldFile.exists()) {
                val newFile = File(oldFile.parentFile, newFullName)
                success = oldFile.renameTo(newFile)
            }
        }

        refresh()
        success
    }

    override suspend fun deleteVideo(item: VideoItem): Boolean = withContext(Dispatchers.IO) {
        val ctx = context ?: return@withContext false
        var success = false

        if (item.uri.scheme == "content") {
            try {
                val count = ctx.contentResolver.delete(item.uri, null, null)
                success = count > 0
            } catch (_: Throwable) {}
        }

        if (!success && item.filePath != null) {
            val file = File(item.filePath)
            if (file.exists()) {
                success = file.delete()
            }
        }

        refresh()
        success
    }
}

interface StorageRepository {
    suspend fun getProjectSlideCount(projectId: String): Int
}

class StorageRepositoryImpl : StorageRepository {
    override suspend fun getProjectSlideCount(projectId: String): Int {
        return 0
    }
}
