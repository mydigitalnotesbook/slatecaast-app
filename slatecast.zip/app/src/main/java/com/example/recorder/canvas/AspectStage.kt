package com.example.recorder.canvas

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import com.example.data.settings.OutputAspectRatio

/**
 * AspectStage draws the largest rectangle of EXACTLY the project ratio (16:9 or 9:16)
 * centred on screen, with dark bars outside it.
 *
 * EVERYTHING that will be in the video lives inside this rectangle.
 * Everything outside it (toolbar, navigation controls, countdown) is NOT recorded.
 */
@Composable
fun AspectStage(
    aspect: OutputAspectRatio,
    modifier: Modifier = Modifier,
    stageBackground: Color = Color(0xFF101216),
    outerDarkBarsColor: Color = Color(0xFF000000),
    content: @Composable (stageWidth: Dp, stageHeight: Dp) -> Unit,
) {
    val targetRatio = if (aspect == OutputAspectRatio.LANDSCAPE_16_9) 16f / 9f else 9f / 16f

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(outerDarkBarsColor)
            .testTag("aspect_stage_container"),
        contentAlignment = Alignment.Center,
    ) {
        val availableWidth = maxWidth
        val availableHeight = maxHeight

        val availableRatio = availableWidth.value / availableHeight.value

        val stageWidth: Dp
        val stageHeight: Dp

        if (availableRatio > targetRatio) {
            // Container is wider than target ratio: bound by height
            stageHeight = availableHeight
            stageWidth = availableHeight * targetRatio
        } else {
            // Container is taller than target ratio: bound by width
            stageWidth = availableWidth
            stageHeight = availableWidth / targetRatio
        }

        Box(
            modifier = Modifier
                .size(width = stageWidth, height = stageHeight)
                .background(stageBackground)
                .clipToBounds()
                .testTag("aspect_stage_surface"),
            contentAlignment = Alignment.Center,
        ) {
            content(stageWidth, stageHeight)
        }
    }
}
