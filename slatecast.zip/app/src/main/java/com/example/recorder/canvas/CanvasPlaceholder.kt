package com.example.recorder.canvas

/**
 * Drawing canvas state and stroke models for pen and highlighter.
 * TODO(step 3): Implement touch path recording, stroke smoothing, and canvas render pass.
 */
enum class ToolType {
    PEN,
    HIGHLIGHTER,
    ERASER,
    LASER_POINTER,
}

data class StrokePoint(
    val x: Float,
    val y: Float,
    val timestamp: Long,
)

data class DrawingStroke(
    val points: List<StrokePoint>,
    val color: Long,
    val width: Float,
    val toolType: ToolType,
)
