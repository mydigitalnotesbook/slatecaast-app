package com.example.recorder.canvas

import android.graphics.PointF

enum class Tool {
    PEN,
    HIGHLIGHTER,
    ERASER,
}

/**
 * Normalized stroke data.
 * [points] and [widthNorm] are NORMALISED to the stage:
 * x, y in 0..1 and widthNorm as a fraction of stage width.
 * This ensures the drawing renders identically at any resolution.
 */
data class Stroke(
    val tool: Tool,
    val colorArgb: Int,
    val widthNorm: Float,
    val points: List<PointF>,
)
