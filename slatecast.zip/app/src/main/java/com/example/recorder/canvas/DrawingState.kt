package com.example.recorder.canvas

import android.graphics.Color
import android.graphics.PointF
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.hypot

/**
 * 6 preset drawing colors
 */
enum class PaletteColor(val displayName: String, val argb: Int) {
    RED("Red", Color.parseColor("#E53935")),
    ORANGE("Orange", Color.parseColor("#FB8C00")),
    GREEN("Green", Color.parseColor("#43A047")),
    BLUE("Blue", Color.parseColor("#1E88E5")),
    PURPLE("Purple", Color.parseColor("#8E24AA")),
    BLACK("Black", Color.parseColor("#212121")),
}

/**
 * Maintains stroke lists PER SLIDE with undo, redo, and clear-page.
 * Also holds current tool, color, and normalized width settings.
 */
class DrawingState {

    // Current tool settings
    private val _currentTool = MutableStateFlow(Tool.PEN)
    val currentTool: StateFlow<Tool> = _currentTool.asStateFlow()

    private val _currentColor = MutableStateFlow(PaletteColor.RED)
    val currentColor: StateFlow<PaletteColor> = _currentColor.asStateFlow()

    // Normalized width as fraction of stage width (default ~ 0.006f, range 0.002f..0.025f)
    private val _widthNorm = MutableStateFlow(0.006f)
    val widthNorm: StateFlow<Float> = _widthNorm.asStateFlow()

    // Map of slide index -> list of committed strokes
    private val slideStrokes = mutableMapOf<Int, MutableList<Stroke>>()

    // Map of slide index -> stack of undone strokes for redo
    private val slideRedoStacks = mutableMapOf<Int, MutableList<Stroke>>()

    // StateFlow holding a version number or snapshot map to trigger Compose recomposition
    private val _strokesVersion = MutableStateFlow(0L)
    val strokesVersion: StateFlow<Long> = _strokesVersion.asStateFlow()

    fun setTool(tool: Tool) {
        _currentTool.value = tool
    }

    fun setColor(color: PaletteColor) {
        _currentColor.value = color
    }

    fun setWidthNorm(width: Float) {
        _widthNorm.value = width.coerceIn(0.002f, 0.025f)
    }

    fun getStrokesForSlide(slideIndex: Int): List<Stroke> {
        return slideStrokes[slideIndex]?.toList() ?: emptyList()
    }

    fun canUndo(slideIndex: Int): Boolean {
        return !slideStrokes[slideIndex].isNullOrEmpty()
    }

    fun canRedo(slideIndex: Int): Boolean {
        return !slideRedoStacks[slideIndex].isNullOrEmpty()
    }

    fun addStroke(slideIndex: Int, stroke: Stroke) {
        val list = slideStrokes.getOrPut(slideIndex) { mutableListOf() }
        list.add(stroke)
        // Clear redo stack on new stroke
        slideRedoStacks[slideIndex]?.clear()
        _strokesVersion.value++
    }

    fun undo(slideIndex: Int) {
        val list = slideStrokes[slideIndex]
        if (!list.isNullOrEmpty()) {
            val removed = list.removeAt(list.size - 1)
            val redoList = slideRedoStacks.getOrPut(slideIndex) { mutableListOf() }
            redoList.add(removed)
            _strokesVersion.value++
        }
    }

    fun redo(slideIndex: Int) {
        val redoList = slideRedoStacks[slideIndex]
        if (!redoList.isNullOrEmpty()) {
            val restored = redoList.removeAt(redoList.size - 1)
            val list = slideStrokes.getOrPut(slideIndex) { mutableListOf() }
            list.add(restored)
            _strokesVersion.value++
        }
    }

    fun clearPage(slideIndex: Int) {
        val currentList = slideStrokes[slideIndex]
        if (!currentList.isNullOrEmpty()) {
            val redoList = slideRedoStacks.getOrPut(slideIndex) { mutableListOf() }
            redoList.clear()
            redoList.addAll(currentList)
            currentList.clear()
            _strokesVersion.value++
        }
    }

    /**
     * Erases any stroke touched by the given point (within threshold in normalized coords).
     */
    fun eraseStrokesAt(slideIndex: Int, normX: Float, normY: Float, radiusNorm: Float = 0.025f): Boolean {
        val list = slideStrokes[slideIndex] ?: return false
        var modified = false
        val iterator = list.iterator()
        while (iterator.hasNext()) {
            val stroke = iterator.next()
            if (isStrokeNearPoint(stroke, normX, normY, radiusNorm)) {
                iterator.remove()
                modified = true
            }
        }
        if (modified) {
            slideRedoStacks[slideIndex]?.clear()
            _strokesVersion.value++
        }
        return modified
    }

    private fun isStrokeNearPoint(stroke: Stroke, targetX: Float, targetY: Float, threshold: Float): Boolean {
        val strokeThreshold = threshold + (stroke.widthNorm / 2f)
        for (pt in stroke.points) {
            val dist = hypot(pt.x - targetX, pt.y - targetY)
            if (dist <= strokeThreshold) {
                return true
            }
        }
        return false
    }
}
