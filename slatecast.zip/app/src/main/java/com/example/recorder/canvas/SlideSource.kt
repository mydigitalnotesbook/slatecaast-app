package com.example.recorder.canvas

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.example.data.storage.SlideItem

/**
 * Step 17: SlideSource abstraction
 * Allows StageRenderer to seamlessly paint image slides and interactive web slides.
 */
sealed interface SlideSource {
    val id: String
    fun render(canvas: Canvas, stageWidth: Int, stageHeight: Int)
}

/**
 * SlideSource for standard image/photo and PDF-rendered slides.
 */
class ImageSlide(
    val slideItem: SlideItem,
    private val bitmapProvider: (filePath: String) -> Bitmap?,
) : SlideSource {
    override val id: String = slideItem.id

    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    override fun render(canvas: Canvas, stageWidth: Int, stageHeight: Int) {
        val bitmap = bitmapProvider(slideItem.filePath) ?: return
        if (bitmap.isRecycled) return

        val slideW = bitmap.width.toFloat()
        val slideH = bitmap.height.toFloat()
        if (slideW <= 0f || slideH <= 0f) return

        val scale = minOf(stageWidth.toFloat() / slideW, stageHeight.toFloat() / slideH)
        val drawW = slideW * scale
        val drawH = slideH * scale
        val left = (stageWidth - drawW) / 2f
        val top = (stageHeight - drawH) / 2f
        val destRect = RectF(left, top, left + drawW, top + drawH)
        canvas.drawBitmap(bitmap, null, destRect, bitmapPaint)
    }
}

/**
 * SlideSource for interactive web page slides.
 * Fetches the latest frame captured from the WebView on the main thread at 15-20 fps.
 */
class WebSlide(
    override val id: String,
    val initialUrl: String = "https://en.wikipedia.org",
    private val frameProvider: () -> Bitmap?,
) : SlideSource {
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    override fun render(canvas: Canvas, stageWidth: Int, stageHeight: Int) {
        val bitmap = frameProvider() ?: return
        if (bitmap.isRecycled) return

        val webW = bitmap.width.toFloat()
        val webH = bitmap.height.toFloat()
        if (webW <= 0f || webH <= 0f) return

        val scale = minOf(stageWidth.toFloat() / webW, stageHeight.toFloat() / webH)
        val drawW = webW * scale
        val drawH = webH * scale
        val left = (stageWidth - drawW) / 2f
        val top = (stageHeight - drawH) / 2f
        val destRect = RectF(left, top, left + drawW, top + drawH)
        canvas.drawBitmap(bitmap, null, destRect, bitmapPaint)
    }
}
