package com.example.recorder.canvas

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.LruCache
import com.example.R
import com.example.data.settings.OutputAspectRatio
import com.example.data.settings.outputSize
import com.example.data.storage.SlideItem
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Step 11: StageRenderer
 *
 * Renders the stage onto any Canvas of any width and height:
 * 1. Stage background colour
 * 2. Current slide scaled to FIT and centered
 * 3. drawStrokes(...) on top
 *
 * Used for both on-screen preview and video encoder surfaces.
 */
class StageRenderer(
    val slidesProvider: () -> List<SlideItem>,
    val drawingStateProvider: () -> DrawingState,
    val currentSlideIndexProvider: () -> Int = { 0 },
    val context: Context? = null,
    val backgroundColorArgb: Int = Color.parseColor("#101216"),
    var webFrameProvider: (() -> Bitmap?)? = null,
    var faceCamCompositor: ((canvas: Canvas, width: Int, height: Int) -> Unit)? = null,
) {

    companion object {
        fun fromCurrentSlide(
            currentSlideProvider: () -> SlideItem?,
            drawingStateProvider: () -> DrawingState,
            context: Context? = null,
        ): StageRenderer = StageRenderer(
            slidesProvider = { currentSlideProvider()?.let { listOf(it) } ?: emptyList() },
            drawingStateProvider = drawingStateProvider,
            currentSlideIndexProvider = { 0 },
            context = context,
        )
    }

    // Cache decoded slide bitmaps (max 4 slides in memory to prevent decoding disk I/O on every frame)
    private val bitmapCache = object : LruCache<String, Bitmap>(4) {
        override fun entryRemoved(evicted: Boolean, key: String?, oldValue: Bitmap?, newValue: Bitmap?) {
            if (evicted && oldValue != null && !oldValue.isRecycled) {
                oldValue.recycle()
            }
        }
    }

    private val bgPaint = Paint().apply {
        style = Paint.Style.FILL
        color = backgroundColorArgb
    }

    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    /**
     * Renders stage background, current slide (fit & centered), drawing strokes,
     * and optional face camera bubble onto [canvas].
     */
    fun render(canvas: Canvas, width: Int, height: Int) {
        if (width <= 0 || height <= 0) return

        // 1. Paint stage background colour
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // 2. Paint current slide (ImageSlide or WebSlide) scaled to FIT and centered
        val slides = slidesProvider()
        val index = currentSlideIndexProvider()
        val currentSlide = if (slides.isNotEmpty() && index in slides.indices) slides[index] else null

        if (currentSlide != null) {
            if (currentSlide.sourceType == "web" && webFrameProvider != null) {
                val webSlide = WebSlide(currentSlide.id, frameProvider = { webFrameProvider?.invoke() })
                webSlide.render(canvas, width, height)
            } else {
                val imageSlide = ImageSlide(currentSlide) { path -> getOrDecodeBitmap(path) }
                imageSlide.render(canvas, width, height)
            }
        }

        // 3. Draw strokes on top using StrokeRenderer.drawStrokes
        val drawingState = drawingStateProvider()
        val strokes = drawingState.getStrokesForSlide(index)
        StrokeRenderer.drawStrokes(canvas, strokes, width, height)

        // 4. Composite Face Camera bubble if active (Step 18)
        faceCamCompositor?.invoke(canvas, width, height)
    }

    @Synchronized
    private fun getOrDecodeBitmap(filePath: String): Bitmap? {
        val cached = bitmapCache.get(filePath)
        if (cached != null && !cached.isRecycled) {
            return cached
        }
        val file = File(filePath)
        if (!file.exists() || !file.canRead()) return null

        return try {
            val decoded = BitmapFactory.decodeFile(file.absolutePath)
            if (decoded != null) {
                bitmapCache.put(filePath, decoded)
            }
            decoded
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Renders one frame into a Bitmap of exactly the output size from outputSize(aspect, quality)
     * (e.g. 1920x1080 or 1080x1920) and saves a PNG to MediaStore Pictures/<APP_NAME>/.
     */
    fun saveScreenshot(
        aspect: OutputAspectRatio,
        quality: Int = 1080,
        targetContext: Context? = null,
    ): Uri {
        val ctx = targetContext ?: context
            ?: throw IllegalArgumentException("Context must be provided to save screenshot")

        val targetSize = outputSize(aspect, quality)
        val bitmap = Bitmap.createBitmap(targetSize.width, targetSize.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        render(canvas, targetSize.width, targetSize.height)

        val uri = saveBitmapToPictures(ctx, bitmap)
        bitmap.recycle()
        return uri
    }

    fun release() {
        bitmapCache.evictAll()
    }
}

/**
 * Saves [bitmap] as a PNG file to MediaStore Pictures/<APP_NAME>/.
 */
fun saveBitmapToPictures(context: Context, bitmap: Bitmap): Uri {
    val appName = try {
        context.getString(R.string.app_name)
    } catch (_: Throwable) {
        "Teaching Recorder"
    }
    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val fileName = "Screenshot_${timeStamp}.png"
    val relativePath = "Pictures/$appName"

    val contentValues = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
    }

    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

    if (uri != null) {
        try {
            resolver.openOutputStream(uri)?.use { outputStream ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)) {
                    throw IOException("Failed to compress bitmap to PNG")
                }
            } ?: throw IOException("Failed to open output stream for URI: $uri")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, contentValues, null, null)
            }
            return uri
        } catch (e: Throwable) {
            // Clean up entry on failure
            try {
                resolver.delete(uri, null, null)
            } catch (_: Throwable) {}
            throw e
        }
    } else {
        // Fallback for file system environments where MediaStore insert returns null (e.g. some test environments)
        val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        val appDir = File(picturesDir, appName).apply { mkdirs() }
        val file = File(appDir, fileName)
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return Uri.fromFile(file)
    }
}

/**
 * Top-level convenience function: saveScreenshot(aspect, quality).
 */
fun saveScreenshot(
    context: Context,
    stageRenderer: StageRenderer,
    aspect: OutputAspectRatio,
    quality: Int = 1080,
): Uri {
    return stageRenderer.saveScreenshot(aspect, quality, context)
}
