package com.example.recorder.canvas

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode

object StrokeRenderer {

    /**
     * Plain drawing function used by both on-screen Compose canvas overlay
     * and the background video encoder hardware surface.
     *
     * Points and widths in [strokes] are normalized in the 0..1 range relative to [width] & [height].
     */
    fun drawStrokes(canvas: Canvas, strokes: List<Stroke>, width: Int, height: Int) {
        if (width <= 0 || height <= 0 || strokes.isEmpty()) return

        val stageW = width.toFloat()
        val stageH = height.toFloat()

        for (stroke in strokes) {
            val pts = stroke.points
            if (pts.isEmpty()) continue

            // Eraser is a stroke-based eraser (erased at interaction time by removing from list),
            // but if an ERASER stroke is present we treat it as transparent/skip or clear
            if (stroke.tool == Tool.ERASER) {
                continue
            }

            val strokeWidthPx = (stroke.widthNorm * stageW).coerceAtLeast(1.5f)

            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                isDither = true
            }

            when (stroke.tool) {
                Tool.PEN -> {
                    paint.color = stroke.colorArgb
                    paint.strokeWidth = strokeWidthPx
                }
                Tool.HIGHLIGHTER -> {
                    // Highlighter: 3x width, 40% alpha (multiply-like feel)
                    paint.strokeWidth = strokeWidthPx * 3.0f
                    val alpha = (Color.alpha(stroke.colorArgb) * 0.40f).toInt().coerceIn(20, 110)
                    paint.color = Color.argb(
                        alpha,
                        Color.red(stroke.colorArgb),
                        Color.green(stroke.colorArgb),
                        Color.blue(stroke.colorArgb)
                    )
                }
                Tool.ERASER -> {
                    // Handled above
                }
            }

            val path = Path()
            if (pts.size == 1) {
                val p0 = pts[0]
                val x = p0.x * stageW
                val y = p0.y * stageH
                canvas.drawCircle(x, y, paint.strokeWidth / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL
                    color = paint.color
                })
                continue
            }

            val p0 = pts[0]
            var prevX = p0.x * stageW
            var prevY = p0.y * stageH
            path.moveTo(prevX, prevY)

            for (i in 1 until pts.size) {
                val curr = pts[i]
                val currX = curr.x * stageW
                val currY = curr.y * stageH
                // Smooth curve using quadratic Bezier between midpoints
                val midX = (prevX + currX) / 2f
                val midY = (prevY + currY) / 2f
                path.quadTo(prevX, prevY, midX, midY)
                prevX = currX
                prevY = currY
            }
            path.lineTo(prevX, prevY)

            canvas.drawPath(path, paint)
        }
    }
}
