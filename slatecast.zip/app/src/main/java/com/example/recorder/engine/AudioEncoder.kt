package com.example.recorder.engine

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaRecorder
import android.util.Log
import com.example.data.settings.AudioSourceOption
import java.util.concurrent.atomic.AtomicBoolean

sealed class AudioInitResult {
    data object Success : AudioInitResult()
    data class Failure(val error: String, val throwable: Throwable? = null) : AudioInitResult()
}

/**
 * Step 13: AudioEncoder
 *
 * Captures microphone/camcorder audio via AudioRecord (44100 Hz, mono, PCM 16-bit),
 * encodes it into AAC-LC (audio/mp4a-latm) using MediaCodec, and pipes sample packets to MuxerHub.
 *
 * Synchronized with VideoEncoder via the shared monotonic RecordingClock.
 */
class AudioEncoder(
    val outputSink: OutputSink,
    private val clock: RecordingClock,
) {
    constructor(
        muxerHub: MuxerHub,
        clock: RecordingClock,
    ) : this(FileSink(muxerHub), clock)

    private val isRunning = AtomicBoolean(false)
    private val isPaused = AtomicBoolean(false)
    private val isDraining = AtomicBoolean(false)
    val isMuted = AtomicBoolean(false)

    private var audioRecord: AudioRecord? = null
    private var codec: MediaCodec? = null

    private var recordThread: Thread? = null
    private var drainThread: Thread? = null

    @SuppressLint("MissingPermission")
    fun start(
        audioSourceOption: AudioSourceOption = AudioSourceOption.MIC,
        bitrateKbps: Int = 128,
        sampleRate: Int = 44100,
    ): AudioInitResult {
        if (isRunning.get()) return AudioInitResult.Success

        val audioSource = when (audioSourceOption) {
            AudioSourceOption.CAMCORDER -> MediaRecorder.AudioSource.CAMCORDER
            else -> MediaRecorder.AudioSource.MIC
        }

        val minBufferSize = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )

        if (minBufferSize <= 0) {
            return AudioInitResult.Failure("Invalid AudioRecord minBufferSize: $minBufferSize")
        }

        val bufferSize = maxOf(minBufferSize * 2, 8192)

        val record = try {
            AudioRecord(
                audioSource,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize,
            )
        } catch (e: Throwable) {
            return AudioInitResult.Failure("Failed to instantiate AudioRecord", e)
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            try {
                record.release()
            } catch (_: Throwable) {}
            return AudioInitResult.Failure("AudioRecord failed to initialize (permission denied or hardware unavailable)")
        }

        val audioFormat = MediaFormat.createAudioFormat(
            MediaFormat.MIMETYPE_AUDIO_AAC,
            sampleRate,
            1, // mono
        ).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrateKbps * 1000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }

        val encoder = try {
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            try {
                enc.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                enc.start()
                enc
            } catch (e: Throwable) {
                // Retry without AAC profile key if rejected by hardware/driver
                try {
                    audioFormat.removeKey(MediaFormat.KEY_AAC_PROFILE)
                    enc.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    enc.start()
                    enc
                } catch (e2: Throwable) {
                    try {
                        enc.release()
                    } catch (_: Throwable) {}
                    throw e2
                }
            }
        } catch (e: Throwable) {
            try {
                record.release()
            } catch (_: Throwable) {}
            return AudioInitResult.Failure("Failed to configure AAC audio MediaCodec: ${e.message}", e)
        }

        try {
            record.startRecording()
        } catch (e: Throwable) {
            try {
                record.release()
            } catch (_: Throwable) {}
            try {
                encoder.stop()
                encoder.release()
            } catch (_: Throwable) {}
            return AudioInitResult.Failure("Failed to start AudioRecord recording", e)
        }

        audioRecord = record
        codec = encoder
        isRunning.set(true)
        isPaused.set(false)
        isDraining.set(true)

        // 1. Dedicated Audio Recording and Input Queue Thread
        recordThread = Thread({
            val pcmBuffer = ByteArray(4096)
            while (isRunning.get()) {
                if (isPaused.get()) {
                    try {
                        Thread.sleep(20)
                    } catch (_: InterruptedException) {
                        break
                    }
                    continue
                }

                val rec = audioRecord ?: break
                val bytesRead = try {
                    rec.read(pcmBuffer, 0, pcmBuffer.size)
                } catch (e: Throwable) {
                    Log.w("AudioEncoder", "Error reading AudioRecord PCM bytes", e)
                    -1
                }

                if (bytesRead > 0) {
                    if (isMuted.get()) {
                        // Fill buffer with digital silence while keeping audio stream clock running
                        java.util.Arrays.fill(pcmBuffer, 0, bytesRead, 0.toByte())
                    }
                    val localCodec = codec ?: break
                    val inputBufferIndex = try {
                        localCodec.dequeueInputBuffer(10_000)
                    } catch (_: Throwable) {
                        -1
                    }

                    if (inputBufferIndex >= 0) {
                        val inputBuffer = localCodec.getInputBuffer(inputBufferIndex)
                        if (inputBuffer != null) {
                            inputBuffer.clear()
                            inputBuffer.put(pcmBuffer, 0, bytesRead)
                            val ptsUs = clock.currentPtsUs()
                            localCodec.queueInputBuffer(inputBufferIndex, 0, bytesRead, ptsUs, 0)
                        }
                    }
                }
            }
        }, "AudioRecordThread").apply { start() }

        // 2. Dedicated Audio Output Drain Thread
        drainThread = Thread({
            val bufferInfo = MediaCodec.BufferInfo()
            while (isDraining.get()) {
                val localCodec = codec ?: break
                val outputBufferIndex = try {
                    localCodec.dequeueOutputBuffer(bufferInfo, 10_000)
                } catch (e: Throwable) {
                    Log.w("AudioEncoder", "dequeueOutputBuffer failed", e)
                    break
                }

                when (outputBufferIndex) {
                    MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        // continue draining
                    }
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val newFormat = localCodec.outputFormat
                        outputSink.onAudioFormat(newFormat)
                    }
                    else -> {
                        if (outputBufferIndex >= 0) {
                            val outputBuffer = localCodec.getOutputBuffer(outputBufferIndex)
                            if (outputBuffer != null) {
                                outputSink.writeAudio(outputBuffer, bufferInfo)
                            }
                            localCodec.releaseOutputBuffer(outputBufferIndex, false)

                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                break
                            }
                        }
                    }
                }
            }
        }, "AudioDrainThread").apply { start() }

        return AudioInitResult.Success
    }

    fun pause() {
        isPaused.set(true)
    }

    fun resume() {
        isPaused.set(false)
    }

    fun stop() {
        isRunning.set(false)
        try {
            recordThread?.join(500)
        } catch (_: Throwable) {}

        try {
            audioRecord?.stop()
        } catch (_: Throwable) {}
        try {
            audioRecord?.release()
        } catch (_: Throwable) {}

        // Send EOS to audio codec
        try {
            val localCodec = codec
            if (localCodec != null) {
                val inputIndex = localCodec.dequeueInputBuffer(10_000)
                if (inputIndex >= 0) {
                    localCodec.queueInputBuffer(inputIndex, 0, 0, clock.currentPtsUs(), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                }
            }
        } catch (_: Throwable) {}

        isDraining.set(false)
        try {
            drainThread?.join(500)
        } catch (_: Throwable) {}

        try {
            codec?.stop()
        } catch (_: Throwable) {}
        try {
            codec?.release()
        } catch (_: Throwable) {}

        audioRecord = null
        codec = null
        recordThread = null
        drainThread = null
    }
}
