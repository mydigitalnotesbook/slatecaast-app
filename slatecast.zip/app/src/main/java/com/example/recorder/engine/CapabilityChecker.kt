package com.example.recorder.engine

import android.media.MediaCodecList
import android.media.MediaFormat
import android.util.Log
import com.example.data.settings.OutputAspectRatio
import com.example.data.settings.RecorderSettings
import com.example.data.settings.VideoCodecOption
import com.example.data.settings.outputSize

/**
 * Step 16: CapabilityChecker
 *
 * Uses MediaCodecList and VideoCapabilities to verify hardware encoder support
 * for codec, size, fps, and bitrate combinations, and returns the nearest working fallback.
 */
object CapabilityChecker {

    const val TAG = "RecorderEngine"

    // In-memory cache of remembered working configuration
    var rememberedWorkingSettings: RecorderSettings? = null

    data class CompatibilityResult(
        val isSupported: Boolean,
        val workingSettings: RecorderSettings,
        val workingWidth: Int,
        val workingHeight: Int,
        val fallbackReason: String? = null,
    )

    /**
     * Checks if a specific encoder configuration is supported by device hardware.
     */
    fun isConfigSupported(
        codec: VideoCodecOption,
        width: Int,
        height: Int,
        fps: Int,
        bitrateMbps: Int,
    ): Boolean {
        return try {
            val codecList = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            for (info in codecList.codecInfos) {
                if (!info.isEncoder) continue
                for (type in info.supportedTypes) {
                    if (type.equals(codec.mimeType, ignoreCase = true)) {
                        val caps = info.getCapabilitiesForType(type)
                        val vCaps = caps?.videoCapabilities ?: continue

                        val sizeSupported = vCaps.isSizeSupported(width, height) ||
                                vCaps.isSizeSupported(height, width)
                        if (!sizeSupported) continue

                        if (fps > 0) {
                            val rateSupported = vCaps.areSizeAndRateSupported(width, height, fps.toDouble()) ||
                                    vCaps.areSizeAndRateSupported(height, width, fps.toDouble())
                            if (!rateSupported) continue
                        }

                        val bps = bitrateMbps * 1_000_000
                        val bRange = vCaps.bitrateRange
                        if (bRange != null && !bRange.contains(bps)) {
                            continue
                        }

                        return true
                    }
                }
            }
            false
        } catch (e: Throwable) {
            Log.w(TAG, "Capability query failed: ${e.message}")
            false
        }
    }

    /**
     * Finds the nearest supported working configuration, applying fallbacks in order:
     * 1. HEVC -> H264
     * 2. 60 fps -> 30 fps
     * 3. 1080 -> 720
     * 4. bitrate -> 4 Mbps
     */
    fun findWorkingConfig(
        aspect: OutputAspectRatio,
        settings: RecorderSettings,
    ): CompatibilityResult {
        // First check if the device previously remembered a working configuration
        val base = rememberedWorkingSettings ?: settings
        val originalSize = outputSize(aspect, base.videoQuality)

        if (isConfigSupported(base.videoCodec, originalSize.width, originalSize.height, base.fps, base.videoBitrateMbps)) {
            return CompatibilityResult(
                isSupported = true,
                workingSettings = base,
                workingWidth = originalSize.width,
                workingHeight = originalSize.height,
            )
        }

        var candidate = base

        // Fallback 1: HEVC -> H264
        if (candidate.videoCodec == VideoCodecOption.HEVC) {
            candidate = candidate.copy(videoCodec = VideoCodecOption.H264)
            val s = outputSize(aspect, candidate.videoQuality)
            if (isConfigSupported(candidate.videoCodec, s.width, s.height, candidate.fps, candidate.videoBitrateMbps)) {
                rememberWorkingConfig(candidate)
                return CompatibilityResult(
                    isSupported = false,
                    workingSettings = candidate,
                    workingWidth = s.width,
                    workingHeight = s.height,
                    fallbackReason = "HEVC not supported, switched to H.264",
                )
            }
        }

        // Fallback 2: 60 fps -> 30 fps
        if (candidate.fps > 30) {
            candidate = candidate.copy(fps = 30)
            val s = outputSize(aspect, candidate.videoQuality)
            if (isConfigSupported(candidate.videoCodec, s.width, s.height, candidate.fps, candidate.videoBitrateMbps)) {
                rememberWorkingConfig(candidate)
                return CompatibilityResult(
                    isSupported = false,
                    workingSettings = candidate,
                    workingWidth = s.width,
                    workingHeight = s.height,
                    fallbackReason = "High frame rate not supported, lowered to 30 fps",
                )
            }
        }

        // Fallback 3: 1080 -> 720
        if (candidate.videoQuality > 720) {
            candidate = candidate.copy(videoQuality = 720)
            val s = outputSize(aspect, candidate.videoQuality)
            if (isConfigSupported(candidate.videoCodec, s.width, s.height, candidate.fps, candidate.videoBitrateMbps)) {
                rememberWorkingConfig(candidate)
                return CompatibilityResult(
                    isSupported = false,
                    workingSettings = candidate,
                    workingWidth = s.width,
                    workingHeight = s.height,
                    fallbackReason = "1080p not supported, lowered to 720p",
                )
            }
        }

        // Fallback 4: bitrate -> 4 Mbps
        if (candidate.videoBitrateMbps > 4) {
            candidate = candidate.copy(videoBitrateMbps = 4)
            val s = outputSize(aspect, candidate.videoQuality)
            if (isConfigSupported(candidate.videoCodec, s.width, s.height, candidate.fps, candidate.videoBitrateMbps)) {
                rememberWorkingConfig(candidate)
                return CompatibilityResult(
                    isSupported = false,
                    workingSettings = candidate,
                    workingWidth = s.width,
                    workingHeight = s.height,
                    fallbackReason = "High bitrate not supported, lowered to 4 Mbps",
                )
            }
        }

        // Safe baseline fallback
        val baseline = candidate.copy(
            videoCodec = VideoCodecOption.H264,
            fps = 30,
            videoQuality = 720,
            videoBitrateMbps = 4,
        )
        val s = outputSize(aspect, 720)
        rememberWorkingConfig(baseline)
        return CompatibilityResult(
            isSupported = false,
            workingSettings = baseline,
            workingWidth = s.width,
            workingHeight = s.height,
            fallbackReason = "Defaulting to baseline H.264 720p 30fps 4Mbps",
        )
    }

    fun rememberWorkingConfig(settings: RecorderSettings) {
        rememberedWorkingSettings = settings
        Log.i(TAG, "Remembered working encoder configuration: ${settings.videoCodec.name}, ${settings.videoQuality}p, ${settings.fps}fps, ${settings.videoBitrateMbps}Mbps")
    }

    /**
     * Executes sequential retry steps when starting or configuring encoder throws:
     * 1. HEVC -> H264
     * 2. 60 fps -> 30 fps
     * 3. 1080 -> 720
     * 4. bitrate -> 4 Mbps
     */
    fun getNextRetrySettings(current: RecorderSettings): RecorderSettings? {
        if (current.videoCodec == VideoCodecOption.HEVC) {
            Log.w(TAG, "Retrying encoder configuration: HEVC -> H264")
            return current.copy(videoCodec = VideoCodecOption.H264)
        }
        if (current.fps > 30) {
            Log.w(TAG, "Retrying encoder configuration: ${current.fps}fps -> 30fps")
            return current.copy(fps = 30)
        }
        if (current.videoQuality > 720) {
            Log.w(TAG, "Retrying encoder configuration: 1080p -> 720p")
            return current.copy(videoQuality = 720)
        }
        if (current.videoBitrateMbps > 4) {
            Log.w(TAG, "Retrying encoder configuration: ${current.videoBitrateMbps}Mbps -> 4Mbps")
            return current.copy(videoBitrateMbps = 4)
        }
        return null // All retries exhausted
    }
}
