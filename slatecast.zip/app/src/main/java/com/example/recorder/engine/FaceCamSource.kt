package com.example.recorder.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class FaceCamSize(val fraction: Float, val dpSize: Int) {
    SMALL(0.12f, 100),
    MEDIUM(0.18f, 150),
}

/**
 * Step 18: FaceCamSource
 *
 * Manages front-facing camera frame capture and composites the round camera bubble
 * onto the recording canvas at the exact normalized position and size seen on stage.
 */
class FaceCamSource {

    private val _isEnabled = MutableStateFlow(false)
    val isEnabled: StateFlow<Boolean> = _isEnabled.asStateFlow()

    private val _size = MutableStateFlow(FaceCamSize.SMALL)
    val size: StateFlow<FaceCamSize> = _size.asStateFlow()

    // Normalized center coordinates within stage bounds (0..1)
    private val _xNorm = MutableStateFlow(0.85f)
    val xNorm: StateFlow<Float> = _xNorm.asStateFlow()

    private val _yNorm = MutableStateFlow(0.85f)
    val yNorm: StateFlow<Float> = _yNorm.asStateFlow()

    @Volatile
    var latestFrameBitmap: Bitmap? = null

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = android.graphics.Color.WHITE
    }

    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val clipPath = Path()

    fun setEnabled(enabled: Boolean) {
        _isEnabled.value = enabled
        if (!enabled) {
            latestFrameBitmap?.recycle()
            latestFrameBitmap = null
        }
    }

    fun setSize(newSize: FaceCamSize) {
        _size.value = newSize
    }

    fun updatePosition(xNormalized: Float, yNormalized: Float) {
        _xNorm.value = xNormalized.coerceIn(0.08f, 0.92f)
        _yNorm.value = yNormalized.coerceIn(0.08f, 0.92f)
    }

    fun updateFrame(bitmap: Bitmap) {
        if (!_isEnabled.value) return
        latestFrameBitmap = bitmap
    }

    /**
     * Composites the camera bubble onto [canvas] at the exact normalized position.
     */
    fun composite(canvas: Canvas, stageWidth: Int, stageHeight: Int) {
        if (!_isEnabled.value) return
        val bmp = latestFrameBitmap ?: return
        if (bmp.isRecycled) return

        val minDim = minOf(stageWidth, stageHeight)
        val diameter = minDim * _size.value.fraction * 2f
        val radius = diameter / 2f

        val cx = _xNorm.value * stageWidth
        val cy = _yNorm.value * stageHeight

        val left = cx - radius
        val top = cy - radius
        val right = cx + radius
        val bottom = cy + radius

        val destRect = RectF(left, top, right, bottom)

        canvas.save()
        clipPath.reset()
        clipPath.addCircle(cx, cy, radius, Path.Direction.CW)
        canvas.clipPath(clipPath)

        canvas.drawBitmap(bmp, null, destRect, bitmapPaint)
        canvas.restore()

        // Draw white border ring
        canvas.drawCircle(cx, cy, radius, borderPaint)
    }

    fun release() {
        _isEnabled.value = false
        latestFrameBitmap?.recycle()
        latestFrameBitmap = null
    }
}
