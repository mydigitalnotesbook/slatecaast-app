package com.example.recorder.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Log
import java.nio.ByteBuffer

enum class TrackType {
    VIDEO,
    AUDIO,
}

/**
 * Thread-safe MediaMuxer coordinator.
 *
 * Waits until all expected tracks (VIDEO and/or AUDIO) have registered their MediaFormat,
 * starts the muxer, routes sample buffers safely across threads, and publishes the final
 * video in MediaStore upon completion.
 */
class MuxerHub(
    val context: Context,
    val output: VideoOutput = VideoStoreHelper.createOutputUri(context),
    val expectedTracks: Set<TrackType> = setOf(TrackType.VIDEO, TrackType.AUDIO),
) {

    val outputUri: Uri = output.uri
    private val pfd: ParcelFileDescriptor = output.pfd

    private val mediaMuxer: MediaMuxer = MediaMuxer(
        pfd.fileDescriptor,
        MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4,
    )

    private val expectedTracksMutable = expectedTracks.toMutableSet()
    private val trackIndices = mutableMapOf<TrackType, Int>()
    private var isStarted = false
    private var isStopped = false

    @Synchronized
    fun abandonTrack(type: TrackType) {
        if (isStopped) return
        expectedTracksMutable.remove(type)
        Log.i("MuxerHub", "Track $type abandoned, remaining expected: $expectedTracksMutable")
        if (trackIndices.keys.containsAll(expectedTracksMutable) && !isStarted && trackIndices.isNotEmpty()) {
            try {
                mediaMuxer.start()
                isStarted = true
                Log.i("MuxerHub", "MediaMuxer started after track abandonment with tracks: ${trackIndices.keys}")
                @Suppress("PLATFORM_CLASS_MAPPED_TO_KOTLIN")
                (this as java.lang.Object).notifyAll()
            } catch (e: Throwable) {
                Log.e("MuxerHub", "Failed to start MediaMuxer after track abandonment", e)
            }
        }
    }

    @Synchronized
    fun addTrack(type: TrackType, format: MediaFormat): Int {
        if (isStopped) {
            throw IllegalStateException("MuxerHub is already stopped")
        }
        val existing = trackIndices[type]
        if (existing != null) {
            return existing
        }

        val trackIndex = mediaMuxer.addTrack(format)
        trackIndices[type] = trackIndex

        if (trackIndices.keys.containsAll(expectedTracksMutable) && !isStarted) {
            try {
                mediaMuxer.start()
                isStarted = true
                @Suppress("PLATFORM_CLASS_MAPPED_TO_KOTLIN")
                (this as java.lang.Object).notifyAll()
            } catch (e: Throwable) {
                Log.e("MuxerHub", "Failed to start MediaMuxer", e)
            }
        }
        return trackIndex
    }

    @Synchronized
    fun writeSampleData(trackIndex: Int, byteBuffer: ByteBuffer, bufferInfo: MediaCodec.BufferInfo) {
        if (isStopped) return

        if (!isStarted) {
            // Wait briefly for the other track to format
            try {
                @Suppress("PLATFORM_CLASS_MAPPED_TO_KOTLIN")
                (this as java.lang.Object).wait(1500)
            } catch (_: InterruptedException) {}
        }

        if (isStarted && !isStopped) {
            if (bufferInfo.size > 0 && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                try {
                    mediaMuxer.writeSampleData(trackIndex, byteBuffer, bufferInfo)
                } catch (e: Throwable) {
                    Log.w("MuxerHub", "writeSampleData failed for track $trackIndex", e)
                }
            }
        }
    }

    @Synchronized
    fun isReady(): Boolean = isStarted && !isStopped

    @Synchronized
    fun stop(): Uri {
        if (isStopped) return outputUri
        isStopped = true

        try {
            if (isStarted) {
                mediaMuxer.stop()
            }
        } catch (e: Throwable) {
            Log.w("MuxerHub", "Exception while stopping MediaMuxer", e)
        } finally {
            try {
                mediaMuxer.release()
            } catch (_: Throwable) {}
            try {
                pfd.close()
            } catch (_: Throwable) {}
            VideoStoreHelper.publishOutputUri(context, outputUri)
        }
        return outputUri
    }
}
