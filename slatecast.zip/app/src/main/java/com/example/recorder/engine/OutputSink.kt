package com.example.recorder.engine

import android.media.MediaCodec
import android.media.MediaFormat
import android.util.Log
import java.nio.ByteBuffer

/**
 * Common sink interface for encoded video and audio streams.
 * Allows simultaneous file recording (FileSink) and live RTMP streaming (RtmpSink).
 */
interface OutputSink {
    fun onVideoFormat(format: MediaFormat)
    fun onAudioFormat(format: MediaFormat)
    fun writeVideo(buffer: ByteBuffer, info: MediaCodec.BufferInfo)
    fun writeAudio(buffer: ByteBuffer, info: MediaCodec.BufferInfo)
    fun close()
}

/**
 * File recording sink wrapping MuxerHub.
 */
class FileSink(
    val muxerHub: MuxerHub,
) : OutputSink {

    private var videoTrackIndex: Int = -1
    private var audioTrackIndex: Int = -1

    override fun onVideoFormat(format: MediaFormat) {
        try {
            videoTrackIndex = muxerHub.addTrack(TrackType.VIDEO, format)
        } catch (e: Throwable) {
            Log.e("FileSink", "Failed to add video track to MuxerHub", e)
        }
    }

    override fun onAudioFormat(format: MediaFormat) {
        try {
            audioTrackIndex = muxerHub.addTrack(TrackType.AUDIO, format)
        } catch (e: Throwable) {
            Log.e("FileSink", "Failed to add audio track to MuxerHub", e)
        }
    }

    override fun writeVideo(buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (videoTrackIndex != -1) {
            muxerHub.writeSampleData(videoTrackIndex, buffer, info)
        }
    }

    override fun writeAudio(buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (audioTrackIndex != -1) {
            muxerHub.writeSampleData(audioTrackIndex, buffer, info)
        }
    }

    override fun close() {
        try {
            muxerHub.stop()
        } catch (e: Throwable) {
            Log.w("FileSink", "Error closing MuxerHub", e)
        }
    }
}

/**
 * Composite sink multiplexing encoded buffers across multiple sinks.
 * Employs buffer.duplicate() so downstream sinks maintain independent positions.
 */
class CompositeOutputSink(
    private val sinks: List<OutputSink>,
) : OutputSink {

    override fun onVideoFormat(format: MediaFormat) {
        for (sink in sinks) {
            try {
                sink.onVideoFormat(format)
            } catch (e: Throwable) {
                Log.e("CompositeSink", "Error routing onVideoFormat", e)
            }
        }
    }

    override fun onAudioFormat(format: MediaFormat) {
        for (sink in sinks) {
            try {
                sink.onAudioFormat(format)
            } catch (e: Throwable) {
                Log.e("CompositeSink", "Error routing onAudioFormat", e)
            }
        }
    }

    override fun writeVideo(buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        for (sink in sinks) {
            try {
                val dup = buffer.duplicate()
                sink.writeVideo(dup, info)
            } catch (e: Throwable) {
                Log.w("CompositeSink", "Error writing video buffer to sink", e)
            }
        }
    }

    override fun writeAudio(buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        for (sink in sinks) {
            try {
                val dup = buffer.duplicate()
                sink.writeAudio(dup, info)
            } catch (e: Throwable) {
                Log.w("CompositeSink", "Error writing audio buffer to sink", e)
            }
        }
    }

    override fun close() {
        for (sink in sinks) {
            try {
                sink.close()
            } catch (e: Throwable) {
                Log.w("CompositeSink", "Error closing sink", e)
            }
        }
    }
}
