package com.example.recorder.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.util.Log
import com.example.data.settings.LiveStreamConfig
import com.example.data.settings.OutputAspectRatio
import com.example.data.settings.RecorderSettings
import com.example.data.settings.VideoCodecOption
import com.example.recorder.canvas.StageRenderer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Controller orchestrating RecordingEngine, OutputSinks (File & RTMP), and Android system listeners.
 *
 * Coordinates:
 * - 3-2-1 countdown
 * - Monotonic elapsed timer
 * - Foreground RecordingService with ongoing notification
 * - Automatic pause / mute on audio focus loss (incoming calls)
 * - Battery monitoring (< 15% warning)
 * - Low storage monitor (< 200 MB)
 * - YouTube Live streaming with RtmpSink and adaptive bitrate
 */
class RecorderController(
    private val context: Context,
    private val coroutineScope: CoroutineScope,
) : RecordingService.ServiceActionListener {

    val engine = RecorderEngine(context)
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val _sessionState = MutableStateFlow<RecordingSessionState>(RecordingSessionState.Idle)
    val sessionState: StateFlow<RecordingSessionState> = _sessionState.asStateFlow()

    private val _elapsedTimeSeconds = MutableStateFlow(0L)
    val elapsedTimeSeconds: StateFlow<Long> = _elapsedTimeSeconds.asStateFlow()

    // Live Streaming Specific State
    private var rtmpSink: RtmpSink? = null

    private val _isLiveMode = MutableStateFlow(false)
    val isLiveMode: StateFlow<Boolean> = _isLiveMode.asStateFlow()

    private val _liveStreamState = MutableStateFlow<LiveStreamState>(LiveStreamState.Idle)
    val liveStreamState: StateFlow<LiveStreamState> = _liveStreamState.asStateFlow()

    private val _liveBitrateBps = MutableStateFlow(0L)
    val liveBitrateBps: StateFlow<Long> = _liveBitrateBps.asStateFlow()

    private val _droppedFrames = MutableStateFlow(0L)
    val droppedFrames: StateFlow<Long> = _droppedFrames.asStateFlow()

    private val _isMicMuted = MutableStateFlow(false)
    val isMicMuted: StateFlow<Boolean> = _isMicMuted.asStateFlow()

    private val _isBeRightBack = MutableStateFlow(false)
    val isBeRightBack: StateFlow<Boolean> = _isBeRightBack.asStateFlow()

    private val _systemMessage = MutableStateFlow<String?>(null)
    val systemMessage: StateFlow<String?> = _systemMessage.asStateFlow()

    private var timerJob: Job? = null
    private var countdownJob: Job? = null
    private var storageCheckJob: Job? = null
    private var batteryReceiver: BroadcastReceiver? = null
    private var hasWarnedBattery = false

    private var audioFocusRequest: AudioFocusRequest? = null
    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (_isLiveMode.value) {
                    Log.i("RecorderController", "Audio focus lost during live stream -> muting microphone")
                    engine.setAudioMuted(true)
                    _isMicMuted.value = true
                    _systemMessage.value = "Phone call detected: microphone muted automatically during live broadcast."
                } else {
                    Log.i("RecorderController", "Audio focus lost ($focusChange) -> pausing automatically")
                    pause()
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                // Do not auto-unmute or auto-resume without explicit user confirmation
            }
        }
    }

    init {
        RecordingService.serviceListener = this
    }

    fun startSession(
        stageRenderer: StageRenderer,
        settings: RecorderSettings = RecorderSettings(),
        aspect: OutputAspectRatio = OutputAspectRatio.LANDSCAPE_16_9,
        enableAudio: Boolean = true,
        onSessionSaved: ((Uri) -> Unit)? = null,
    ) {
        if (_sessionState.value !is RecordingSessionState.Idle) return

        countdownJob?.cancel()
        countdownJob = coroutineScope.launch(Dispatchers.Main) {
            _isLiveMode.value = false
            _isMicMuted.value = false
            _isBeRightBack.value = false
            _systemMessage.value = null

            // Countdown 3, 2, 1
            for (count in 3 downTo 1) {
                _sessionState.value = RecordingSessionState.Counting(count)
                delay(1000)
            }

            // Start recording
            _sessionState.value = RecordingSessionState.Recording
            _elapsedTimeSeconds.value = 0L

            requestAudioFocus()
            startStorageMonitor()
            startTimer()

            // Start foreground service with notification
            RecordingService.start(context, isLive = false)

            var candidateSettings: RecorderSettings? = CapabilityChecker.rememberedWorkingSettings ?: settings
            var startedSuccessfully = false
            var lastErrorMessage: String? = null

            while (candidateSettings != null && !startedSuccessfully) {
                try {
                    engine.start(
                        stageRenderer = stageRenderer,
                        settings = candidateSettings,
                        aspect = aspect,
                        enableAudio = enableAudio,
                    )
                    CapabilityChecker.rememberWorkingConfig(candidateSettings)
                    startedSuccessfully = true
                    Log.i("RecorderEngine", "Encoder started successfully with ${candidateSettings.videoCodec.name}, ${candidateSettings.videoQuality}p, ${candidateSettings.fps}fps, ${candidateSettings.videoBitrateMbps}Mbps")
                } catch (e: Throwable) {
                    lastErrorMessage = e.message ?: "Encoder initialization failure"
                    Log.w("RecorderEngine", "Encoder start failed with ${candidateSettings.videoCodec.name}: $lastErrorMessage")
                    candidateSettings = CapabilityChecker.getNextRetrySettings(candidateSettings)
                }
            }

            if (!startedSuccessfully) {
                Log.e("RecorderEngine", "All encoder retry fallbacks failed: $lastErrorMessage")
                abandonAudioFocus()
                timerJob?.cancel()
                storageCheckJob?.cancel()
                RecordingService.stop(context)
                _sessionState.value = RecordingSessionState.Failed(
                    lastErrorMessage ?: "Video encoder configuration failed. Your device could not start with the current resolution or codec settings."
                )
            }
        }
    }

    fun startLiveSession(
        stageRenderer: StageRenderer,
        liveConfig: LiveStreamConfig,
        aspect: OutputAspectRatio = OutputAspectRatio.LANDSCAPE_16_9,
        onSessionSaved: ((Uri) -> Unit)? = null,
    ) {
        if (_sessionState.value !is RecordingSessionState.Idle) return

        countdownJob?.cancel()
        countdownJob = coroutineScope.launch(Dispatchers.Main) {
            _isLiveMode.value = true
            _isMicMuted.value = false
            _isBeRightBack.value = false
            _liveStreamState.value = LiveStreamState.Connecting
            _systemMessage.value = null

            // Countdown 3, 2, 1
            for (count in 3 downTo 1) {
                _sessionState.value = RecordingSessionState.Counting(count)
                delay(1000)
            }

            _sessionState.value = RecordingSessionState.Recording
            _elapsedTimeSeconds.value = 0L

            requestAudioFocus()
            startTimer()
            startBatteryMonitor()

            val initialBitrateBps = (liveConfig.bitrate.mbps * 1_000_000).toInt()
            val rtmp = RtmpSink(
                streamUrl = liveConfig.streamUrl,
                streamKey = liveConfig.streamKey,
                initialBitrateBps = initialBitrateBps,
                scope = coroutineScope,
                onAdaptiveBitrateChanged = { newBps ->
                    engine.updateBitrate(newBps)
                },
            )
            rtmpSink = rtmp

            // Forward RTMP state flows
            coroutineScope.launch {
                rtmp.streamState.collect { state ->
                    _liveStreamState.value = state
                    if (state is LiveStreamState.Failed) {
                        _systemMessage.value = state.reason
                    }
                }
            }
            coroutineScope.launch {
                rtmp.currentBitrateBps.collect { bps ->
                    _liveBitrateBps.value = bps
                }
            }
            coroutineScope.launch {
                rtmp.droppedFramesCount.collect { drops ->
                    _droppedFrames.value = drops
                }
            }

            // Start foreground service with live notification
            RecordingService.start(context, isLive = true)

            // Sink setup: composite if local copy requested
            val sink: OutputSink
            if (liveConfig.alsoSaveLocalCopy) {
                val muxer = MuxerHub(context = context, expectedTracks = setOf(TrackType.VIDEO, TrackType.AUDIO))
                val fileSink = FileSink(muxer)
                sink = CompositeOutputSink(listOf(fileSink, rtmp))
            } else {
                sink = rtmp
            }

            // Fixed live settings per requirements: H.264, 30fps, 128kbps AAC
            val liveSettings = RecorderSettings(
                videoCodec = VideoCodecOption.H264,
                fps = 30,
                videoQuality = liveConfig.quality.shortSide,
                videoBitrateMbps = liveConfig.bitrate.mbps.toInt().coerceAtLeast(1),
                audioBitrateKbps = 128,
            )

            // Validate against CapabilityChecker
            val workingConfig = CapabilityChecker.findWorkingConfig(aspect, liveSettings)
            val finalSettings = workingConfig.workingSettings

            try {
                engine.start(
                    stageRenderer = stageRenderer,
                    settings = finalSettings,
                    aspect = aspect,
                    enableAudio = true,
                    customSink = sink,
                )
                // Start RTMP connection to YouTube
                rtmp.start()
                Log.i("RecorderController", "Live streaming successfully started to YouTube")
            } catch (e: Throwable) {
                val err = e.message ?: "Failed to start live stream encoder"
                Log.e("RecorderController", "Failed to start live stream", e)
                try { rtmp.close() } catch (_: Throwable) {}
                stopBatteryMonitor()
                abandonAudioFocus()
                timerJob?.cancel()
                RecordingService.stop(context)
                _sessionState.value = RecordingSessionState.Failed(err)
                _isLiveMode.value = false
            }
        }
    }

    fun toggleMuteMic(): Boolean {
        val target = !_isMicMuted.value
        engine.setAudioMuted(target)
        _isMicMuted.value = target
        return target
    }

    fun toggleBeRightBack(): Boolean {
        val target = !_isBeRightBack.value
        _isBeRightBack.value = target
        return target
    }

    fun clearSystemMessage() {
        _systemMessage.value = null
    }

    fun dismissFailure() {
        if (_sessionState.value is RecordingSessionState.Failed) {
            _sessionState.value = RecordingSessionState.Idle
        }
    }

    fun pause() {
        // Pausing is only permitted during local file recording, not while broadcasting live
        if (_isLiveMode.value) return
        if (_sessionState.value is RecordingSessionState.Recording) {
            _sessionState.value = RecordingSessionState.Paused
            engine.pause()
        }
    }

    fun resume() {
        if (_isLiveMode.value) return
        if (_sessionState.value is RecordingSessionState.Paused) {
            requestAudioFocus()
            _sessionState.value = RecordingSessionState.Recording
            engine.resume()
        }
    }

    fun stop(onSaved: ((Uri) -> Unit)? = null) {
        if (_sessionState.value is RecordingSessionState.Idle || _sessionState.value is RecordingSessionState.Saving) {
            return
        }

        countdownJob?.cancel()
        timerJob?.cancel()
        storageCheckJob?.cancel()
        stopBatteryMonitor()
        abandonAudioFocus()

        coroutineScope.launch(Dispatchers.Main) {
            _sessionState.value = RecordingSessionState.Saving
            try {
                rtmpSink?.close()
            } catch (_: Throwable) {}
            rtmpSink = null

            val savedUri = engine.stop()
            RecordingService.stop(context)

            _isLiveMode.value = false
            _isMicMuted.value = false
            _isBeRightBack.value = false
            _liveStreamState.value = LiveStreamState.Idle
            _sessionState.value = RecordingSessionState.Idle
            _elapsedTimeSeconds.value = 0L
            onSaved?.invoke(savedUri)
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = coroutineScope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(1000)
                if (_sessionState.value is RecordingSessionState.Recording) {
                    _elapsedTimeSeconds.value += 1
                }
            }
        }
    }

    private fun startStorageMonitor() {
        storageCheckJob?.cancel()
        storageCheckJob = coroutineScope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(2000)
                val availableBytes = getAvailableStorageBytes()
                val minThresholdBytes = 200L * 1024L * 1024L // 200 MB
                if (availableBytes in 1 until minThresholdBytes) {
                    Log.w("RecorderController", "Low storage ($availableBytes bytes) -> auto-stopping and saving")
                    launch(Dispatchers.Main) {
                        stop()
                    }
                    break
                }
            }
        }
    }

    private fun startBatteryMonitor() {
        try {
            hasWarnedBattery = false
            batteryReceiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                    val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
                    if (level >= 0 && scale > 0) {
                        val pct = (level * 100) / scale
                        if (pct <= 15 && !hasWarnedBattery) {
                            hasWarnedBattery = true
                            _systemMessage.value = "Battery is below 15%! Please connect a charger to prevent your live stream from disconnecting."
                        }
                    }
                }
            }
            context.registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (e: Throwable) {
            Log.w("RecorderController", "Could not register battery monitor receiver", e)
        }
    }

    private fun stopBatteryMonitor() {
        try {
            batteryReceiver?.let { context.unregisterReceiver(it) }
        } catch (_: Throwable) {}
        batteryReceiver = null
    }

    private fun getAvailableStorageBytes(): Long {
        return try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            stat.availableBlocksLong * stat.blockSizeLong
        } catch (_: Throwable) {
            Long.MAX_VALUE
        }
    }

    private fun requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playbackAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()

            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(playbackAttributes)
                .setOnAudioFocusChangeListener(audioFocusListener)
                .build()
            audioFocusRequest = request
            audioManager?.requestAudioFocus(request)
        } else {
            @Suppress("DEPRECATION")
            audioManager?.requestAudioFocus(
                audioFocusListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT,
            )
        }
    }

    private fun abandonAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { audioManager?.abandonAudioFocusRequest(it) }
            audioFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            audioManager?.abandonAudioFocus(audioFocusListener)
        }
    }

    fun isSessionActive(): Boolean {
        val state = _sessionState.value
        return state is RecordingSessionState.Recording ||
            state is RecordingSessionState.Paused ||
            state is RecordingSessionState.Counting
    }

    // ServiceActionListener callbacks from ongoing notification
    override fun onPauseRequested() {
        pause()
    }

    override fun onResumeRequested() {
        resume()
    }

    override fun onStopRequested() {
        stop()
    }
}
