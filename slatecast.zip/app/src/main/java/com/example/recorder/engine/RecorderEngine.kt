package com.example.recorder.engine

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.settings.OutputAspectRatio
import com.example.data.settings.RecorderSettings
import com.example.data.settings.outputSize
import com.example.recorder.canvas.StageRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * High-level recorder engine orchestrating VideoEncoder, AudioEncoder, MuxerHub, and RecordingClock.
 */
class RecorderEngine(
    val context: Context,
) {

    private val clock = RecordingClock()
    private var muxerHub: MuxerHub? = null
    private var videoEncoder: VideoEncoder? = null
    private var audioEncoder: AudioEncoder? = null

    var isRecording: Boolean = false
        private set

    var isPaused: Boolean = false
        private set

    var lastAudioInitResult: AudioInitResult? = null
        private set

    private val mutex = kotlinx.coroutines.sync.Mutex()

    private var activeSink: OutputSink? = null

    fun updateBitrate(newBitrateBps: Int) {
        videoEncoder?.updateBitrate(newBitrateBps)
    }

    fun setAudioMuted(muted: Boolean) {
        audioEncoder?.isMuted?.set(muted)
    }

    fun isAudioMuted(): Boolean {
        return audioEncoder?.isMuted?.get() ?: false
    }

    var customFrameHook: ((android.graphics.Canvas, Int, Int) -> Unit)? = null

    suspend fun start(
        stageRenderer: StageRenderer,
        settings: RecorderSettings = RecorderSettings(),
        aspect: OutputAspectRatio = OutputAspectRatio.LANDSCAPE_16_9,
        enableAudio: Boolean = true,
        customSink: OutputSink? = null,
    ): Uri = withContext(Dispatchers.IO) {
        mutex.lock()
        try {
            if (isRecording) {
                return@withContext muxerHub?.outputUri ?: Uri.EMPTY
            }

            val targetSize = outputSize(aspect, settings.videoQuality)
            clock.reset()

            val sink: OutputSink
            if (customSink != null) {
                sink = customSink
                muxerHub = null
            } else {
                val expectedTracks = if (enableAudio) {
                    setOf(TrackType.VIDEO, TrackType.AUDIO)
                } else {
                    setOf(TrackType.VIDEO)
                }
                val muxer = MuxerHub(context = context, expectedTracks = expectedTracks)
                muxerHub = muxer
                sink = FileSink(muxer)
            }
            activeSink = sink

            val vEncoder = VideoEncoder(stageRenderer, sink, clock, customFrameHook)
            videoEncoder = vEncoder

            clock.start()

            vEncoder.start(
                width = targetSize.width,
                height = targetSize.height,
                fps = settings.fps,
                bitrate = settings.videoBitrateMbps * 1_000_000,
                codecOption = settings.videoCodec,
            )

            if (enableAudio) {
                val aEncoder = AudioEncoder(sink, clock)
                audioEncoder = aEncoder
                val audioResult = aEncoder.start(
                    audioSourceOption = settings.audioSource,
                    bitrateKbps = settings.audioBitrateKbps,
                )
                lastAudioInitResult = audioResult
                if (audioResult is AudioInitResult.Failure) {
                    Log.w("RecorderEngine", "Audio initialization failed: ${audioResult.error}")
                    muxerHub?.abandonTrack(TrackType.AUDIO)
                }
            }

            isRecording = true
            isPaused = false
            muxerHub?.outputUri ?: Uri.EMPTY
        } finally {
            mutex.unlock()
        }
    }

    @Synchronized
    fun pause() {
        if (isRecording && !isPaused) {
            clock.pause()
            videoEncoder?.pause()
            audioEncoder?.pause()
            isPaused = true
        }
    }

    @Synchronized
    fun resume() {
        if (isRecording && isPaused) {
            clock.resume()
            videoEncoder?.resume()
            audioEncoder?.resume()
            isPaused = false
        }
    }

    suspend fun stop(): Uri = withContext(Dispatchers.IO) {
        mutex.lock()
        try {
            if (!isRecording) {
                return@withContext muxerHub?.outputUri ?: Uri.EMPTY
            }

            videoEncoder?.stop()
            audioEncoder?.stop()
            try {
                activeSink?.close()
            } catch (e: Throwable) {
                Log.w("RecorderEngine", "Error closing active sink", e)
            }
            val uri = muxerHub?.outputUri ?: Uri.EMPTY

            videoEncoder = null
            audioEncoder = null
            activeSink = null
            muxerHub = null
            clock.reset()

            isRecording = false
            isPaused = false
            uri
        } finally {
            mutex.unlock()
        }
    }

    /**
     * Records a test video for [durationSeconds] with current settings and returns the published URI.
     */
    suspend fun recordTest(
        stageRenderer: StageRenderer,
        settings: RecorderSettings = RecorderSettings(),
        aspect: OutputAspectRatio = OutputAspectRatio.LANDSCAPE_16_9,
        durationSeconds: Int = 5,
        enableAudio: Boolean = true,
        onProgress: ((secondsLeft: Int) -> Unit)? = null,
    ): Uri = withContext(Dispatchers.IO) {
        try {
            val uri = start(stageRenderer, settings, aspect, enableAudio)

            for (sec in durationSeconds downTo 1) {
                onProgress?.invoke(sec)
                delay(1000)
            }

            stop()
        } catch (e: Throwable) {
            Log.e("RecorderEngine", "recordTest failed: ${e.message}", e)
            try {
                stop()
            } catch (_: Throwable) {}
            throw e
        }
    }
}
