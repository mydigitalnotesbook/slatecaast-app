package com.example.recorder.engine

/**
 * Single monotonic clock for synchronizing video and audio tracks.
 *
 * Presentation timestamps (PTS in microseconds) are computed from System.nanoTime(),
 * minus the total paused time.
 */
class RecordingClock {

    private var startNanoTime: Long = 0L
    private var totalPausedNanoTime: Long = 0L
    private var pauseStartNanoTime: Long = 0L
    private var isStarted: Boolean = false
    private var isPaused: Boolean = false

    @Synchronized
    fun start() {
        startNanoTime = System.nanoTime()
        totalPausedNanoTime = 0L
        pauseStartNanoTime = 0L
        isStarted = true
        isPaused = false
    }

    @Synchronized
    fun pause() {
        if (isStarted && !isPaused) {
            pauseStartNanoTime = System.nanoTime()
            isPaused = true
        }
    }

    @Synchronized
    fun resume() {
        if (isStarted && isPaused) {
            totalPausedNanoTime += (System.nanoTime() - pauseStartNanoTime)
            pauseStartNanoTime = 0L
            isPaused = false
        }
    }

    @Synchronized
    fun reset() {
        startNanoTime = 0L
        totalPausedNanoTime = 0L
        pauseStartNanoTime = 0L
        isStarted = false
        isPaused = false
    }

    @Synchronized
    fun currentPtsUs(): Long {
        if (!isStarted) return 0L
        val now = if (isPaused) pauseStartNanoTime else System.nanoTime()
        val elapsedNano = (now - startNanoTime - totalPausedNanoTime).coerceAtLeast(0L)
        return elapsedNano / 1000L
    }

    @Synchronized
    fun isPaused(): Boolean = isPaused

    @Synchronized
    fun isStarted(): Boolean = isStarted
}
