package com.example.recorder.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class RecordingService : Service() {

    companion object {
        const val CHANNEL_ID = "slatecast_recording_channel"
        const val NOTIFICATION_ID = 4041

        const val ACTION_START = "com.example.recorder.ACTION_START"
        const val ACTION_PAUSE = "com.example.recorder.ACTION_PAUSE"
        const val ACTION_RESUME = "com.example.recorder.ACTION_RESUME"
        const val ACTION_STOP = "com.example.recorder.ACTION_STOP"

        const val EXTRA_IS_LIVE = "com.example.recorder.EXTRA_IS_LIVE"
        var serviceListener: ServiceActionListener? = null

        fun start(context: Context, isLive: Boolean = false) {
            val intent = Intent(context, RecordingService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_IS_LIVE, isLive)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, RecordingService::class.java)
            context.stopService(intent)
        }
    }

    interface ServiceActionListener {
        fun onPauseRequested()
        fun onResumeRequested()
        fun onStopRequested()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private var isLiveStreaming = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.hasExtra(EXTRA_IS_LIVE) == true) {
            isLiveStreaming = intent.getBooleanExtra(EXTRA_IS_LIVE, false)
        }
        when (intent?.action) {
            ACTION_PAUSE -> {
                serviceListener?.onPauseRequested()
                updateNotification(isPaused = true)
            }
            ACTION_RESUME -> {
                serviceListener?.onResumeRequested()
                updateNotification(isPaused = false)
            }
            ACTION_STOP -> {
                serviceListener?.onStopRequested()
                stopSelf()
            }
            else -> {
                startForegroundWithNotification(isPaused = false)
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundWithNotification(isPaused: Boolean) {
        val notification = buildNotification(isPaused)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val foregroundServiceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_NONE
            }
            startForeground(NOTIFICATION_ID, notification, foregroundServiceType)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    fun updateNotification(isPaused: Boolean) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, buildNotification(isPaused))
    }

    private fun buildNotification(isPaused: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val stopIntent = Intent(this, RecordingService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this,
            3,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val stopAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_close_clear_cancel,
            if (isLiveStreaming) "Stop Stream" else "Stop",
            stopPendingIntent,
        ).build()

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .addAction(stopAction)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (isLiveStreaming) {
            builder.setContentTitle("🔴 LIVE on YouTube")
            builder.setContentText("Broadcasting live • Tap Stop to disconnect")
        } else {
            builder.setContentTitle("Teaching Recorder (9:16)")
            builder.setContentText(if (isPaused) "Recording paused" else "Recording in progress...")

            val pauseResumeAction = if (isPaused) {
                val resumeIntent = Intent(this, RecordingService::class.java).apply { action = ACTION_RESUME }
                val resumePendingIntent = PendingIntent.getService(
                    this,
                    1,
                    resumeIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                NotificationCompat.Action.Builder(
                    android.R.drawable.ic_media_play,
                    "Resume",
                    resumePendingIntent,
                ).build()
            } else {
                val pauseIntent = Intent(this, RecordingService::class.java).apply { action = ACTION_PAUSE }
                val pausePendingIntent = PendingIntent.getService(
                    this,
                    2,
                    pauseIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                NotificationCompat.Action.Builder(
                    android.R.drawable.ic_media_pause,
                    "Pause",
                    pausePendingIntent,
                ).build()
            }
            builder.addAction(pauseResumeAction)
        }

        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Lecture Recording Service",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Ongoing notification with pause and stop controls while recording."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }
}
