package com.example.recorder.engine

/**
 * Step 14: State machine states for recording sessions.
 * Idle -> Counting(3,2,1) -> Recording -> Paused -> Saving -> Idle
 */
sealed class RecordingSessionState {
    data object Idle : RecordingSessionState()
    data class Counting(val count: Int) : RecordingSessionState()
    data object Recording : RecordingSessionState()
    data object Paused : RecordingSessionState()
    data object Saving : RecordingSessionState()
    data class Failed(val reason: String) : RecordingSessionState()
}
