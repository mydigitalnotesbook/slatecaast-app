package com.example.recorder.engine

import android.media.MediaCodec
import android.media.MediaFormat
import android.util.Log
import com.pedro.common.AudioCodec
import com.pedro.common.ConnectChecker
import com.pedro.common.VideoCodec
import com.pedro.rtmp.rtmp.RtmpClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

sealed class LiveStreamState {
    object Idle : LiveStreamState()
    object Connecting : LiveStreamState()
    object Live : LiveStreamState()
    data class Reconnecting(val attempt: Int, val maxAttempts: Int, val nextRetrySec: Int) : LiveStreamState()
    data class Failed(val reason: String) : LiveStreamState()
    object Disconnected : LiveStreamState()
}

/**
 * OutputSink sending encoded H.264 and AAC frames to YouTube Live via RTMP/RTMPS.
 * Integrates Pedro's RootEncoder rtmp client with:
 * - Exponential backoff auto-reconnect (2, 4, 8, 16s, up to 5 tries)
 * - Adaptive bitrate and non-keyframe dropping under congestion
 * - Live state reporting and dropped-frame telemetry
 */
class RtmpSink(
    val streamUrl: String,
    val streamKey: String,
    val initialBitrateBps: Int = 2_500_000,
    val minBitrateBps: Int = 800_000,
    val maxBitrateBps: Int = 6_000_000,
    val scope: CoroutineScope = CoroutineScope(Dispatchers.IO),
    val onAdaptiveBitrateChanged: ((Int) -> Unit)? = null,
) : OutputSink {

    companion object {
        private const val TAG = "RtmpSink"
        const val MAX_RECONNECT_ATTEMPTS = 5

        /**
         * Standalone connection handshake tester without publishing.
         */
        fun checkConnection(
            streamUrl: String,
            streamKey: String,
            onResult: (success: Boolean, message: String) -> Unit,
        ) {
            val cleanUrl = streamUrl.trim().trimEnd('/')
            val cleanKey = streamKey.trim()
            if (!cleanUrl.startsWith("rtmp://") && !cleanUrl.startsWith("rtmps://")) {
                onResult(false, "Invalid URL scheme. Must start with rtmp:// or rtmps://")
                return
            }
            if (cleanKey.isEmpty() || cleanKey.contains(" ")) {
                onResult(false, "Stream key cannot be empty or contain spaces.")
                return
            }

            val fullUrl = "$cleanUrl/$cleanKey"
            var checker: ConnectChecker? = null
            var client: RtmpClient? = null
            val completed = AtomicBoolean(false)

            checker = object : ConnectChecker {
                override fun onConnectionStarted(url: String) {
                    Log.i(TAG, "Test connection started: $cleanUrl")
                }

                override fun onConnectionSuccess() {
                    if (completed.compareAndSet(false, true)) {
                        Log.i(TAG, "Test connection success to $cleanUrl")
                        try { client?.disconnect() } catch (_: Throwable) {}
                        onResult(true, "Handshake successful! Connected to YouTube server.")
                    }
                }

                override fun onConnectionFailed(reason: String) {
                    if (completed.compareAndSet(false, true)) {
                        Log.w(TAG, "Test connection failed: $reason")
                        try { client?.disconnect() } catch (_: Throwable) {}
                        onResult(false, "Connection failed: $reason")
                    }
                }

                override fun onDisconnect() {
                    Log.i(TAG, "Test connection disconnected")
                }

                override fun onAuthError() {
                    if (completed.compareAndSet(false, true)) {
                        try { client?.disconnect() } catch (_: Throwable) {}
                        onResult(false, "Authentication error: Invalid stream key.")
                    }
                }

                override fun onAuthSuccess() {
                    Log.i(TAG, "Test connection auth success")
                }

                override fun onNewBitrate(bitrate: Long) {}
            }

            client = RtmpClient(checker)
            try {
                // Connect in non-publish mode for handshake test only
                client.connect(fullUrl, false)
            } catch (e: Throwable) {
                if (completed.compareAndSet(false, true)) {
                    onResult(false, "Connection error: ${e.message}")
                }
            }
        }
    }

    private val _streamState = MutableStateFlow<LiveStreamState>(LiveStreamState.Idle)
    val streamState: StateFlow<LiveStreamState> = _streamState.asStateFlow()

    private val _currentBitrateBps = MutableStateFlow(initialBitrateBps.toLong())
    val currentBitrateBps: StateFlow<Long> = _currentBitrateBps.asStateFlow()

    private val _droppedFramesCount = MutableStateFlow(0L)
    val droppedFramesCount: StateFlow<Long> = _droppedFramesCount.asStateFlow()

    private val fullEndpointUrl = "${streamUrl.trim().trimEnd('/')}/${streamKey.trim()}"
    private var isClosed = false
    private var isStreamingActive = false

    private var cachedSps: ByteBuffer? = null
    private var cachedPps: ByteBuffer? = null
    private var cachedSampleRate = 44100
    private var cachedIsStereo = false
    private var videoWidth = 1280
    private var videoHeight = 720
    private var videoFps = 30

    private var reconnectAttempt = 0
    private var reconnectJob: Job? = null

    // Adaptive bitrate variables
    private var currentEncoderBitrate = initialBitrateBps
    private var consecutiveCleanFrames = 0
    private var consecutiveCongestedFrames = 0

    private val connectChecker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) {
            Log.i(TAG, "RTMP connection started to: $streamUrl")
            _streamState.value = LiveStreamState.Connecting
        }

        override fun onConnectionSuccess() {
            Log.i(TAG, "RTMP connection established successfully with YouTube!")
            reconnectAttempt = 0
            isStreamingActive = true
            _streamState.value = LiveStreamState.Live

            // Re-apply video info & audio info once connected
            applyFormatParameters()
        }

        override fun onConnectionFailed(reason: String) {
            Log.w(TAG, "RTMP connection failed: $reason")
            isStreamingActive = false
            handleDisconnection(reason)
        }

        override fun onDisconnect() {
            Log.i(TAG, "RTMP disconnected from YouTube")
            if (isStreamingActive && !isClosed) {
                handleDisconnection("Disconnected by remote server")
            } else {
                _streamState.value = LiveStreamState.Disconnected
            }
        }

        override fun onAuthError() {
            Log.e(TAG, "RTMP Authentication error with YouTube Stream Key")
            isStreamingActive = false
            _streamState.value = LiveStreamState.Failed("Stream key authentication rejected by YouTube.")
        }

        override fun onAuthSuccess() {
            Log.i(TAG, "RTMP auth successful")
        }

        override fun onNewBitrate(bitrate: Long) {
            _currentBitrateBps.value = bitrate
        }
    }

    private val rtmpClient = RtmpClient(connectChecker).apply {
        setLogs(false)
        setVideoCodec(VideoCodec.H264)
        setAudioCodec(AudioCodec.AAC)
    }

    fun start() {
        if (isClosed) return
        _streamState.value = LiveStreamState.Connecting
        try {
            rtmpClient.connect(fullEndpointUrl, true)
        } catch (e: Throwable) {
            Log.e(TAG, "Error starting RTMP connection", e)
            handleDisconnection(e.message ?: "Failed to initiate RTMP connection")
        }
    }

    private fun applyFormatParameters() {
        try {
            val sps = cachedSps
            val pps = cachedPps
            if (sps != null && pps != null) {
                rtmpClient.setVideoResolution(videoWidth, videoHeight)
                rtmpClient.setFps(videoFps)
                rtmpClient.setVideoInfo(sps.duplicate(), pps.duplicate(), null)
            }
            rtmpClient.setAudioInfo(cachedSampleRate, cachedIsStereo)
        } catch (e: Throwable) {
            Log.w(TAG, "Error applying format parameters to RtmpClient", e)
        }
    }

    private fun handleDisconnection(reason: String) {
        if (isClosed) return

        if (reconnectAttempt < MAX_RECONNECT_ATTEMPTS) {
            reconnectAttempt++
            // Exponential backoff: 2s, 4s, 8s, 16s...
            val backoffSec = (1 shl reconnectAttempt).coerceIn(2, 16)
            Log.w(TAG, "Scheduling reconnect attempt $reconnectAttempt/$MAX_RECONNECT_ATTEMPTS in ${backoffSec}s due to: $reason")
            _streamState.value = LiveStreamState.Reconnecting(reconnectAttempt, MAX_RECONNECT_ATTEMPTS, backoffSec)

            reconnectJob?.cancel()
            reconnectJob = scope.launch {
                delay(backoffSec * 1000L)
                if (!isClosed) {
                    try {
                        rtmpClient.reConnect(0L)
                    } catch (e: Throwable) {
                        Log.w(TAG, "reConnect attempt failed: ${e.message}")
                    }
                }
            }
        } else {
            Log.e(TAG, "All $MAX_RECONNECT_ATTEMPTS reconnect attempts failed.")
            _streamState.value = LiveStreamState.Failed("Connection lost. All $MAX_RECONNECT_ATTEMPTS reconnect attempts failed: $reason")
        }
    }

    override fun onVideoFormat(format: MediaFormat) {
        try {
            videoWidth = format.getInteger(MediaFormat.KEY_WIDTH, 1280)
            videoHeight = format.getInteger(MediaFormat.KEY_HEIGHT, 720)
            videoFps = format.getInteger(MediaFormat.KEY_FRAME_RATE, 30)

            val csd0 = format.getByteBuffer("csd-0") // SPS
            val csd1 = format.getByteBuffer("csd-1") // PPS

            if (csd0 != null && csd1 != null) {
                cachedSps = csd0.duplicate()
                cachedPps = csd1.duplicate()
                rtmpClient.setVideoResolution(videoWidth, videoHeight)
                rtmpClient.setFps(videoFps)
                rtmpClient.setVideoInfo(csd0, csd1, null)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error parsing onVideoFormat in RtmpSink", e)
        }
    }

    override fun onAudioFormat(format: MediaFormat) {
        try {
            cachedSampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE, 44100)
            val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT, 1)
            cachedIsStereo = (channels > 1)
            rtmpClient.setAudioInfo(cachedSampleRate, cachedIsStereo)
        } catch (e: Throwable) {
            Log.e(TAG, "Error parsing onAudioFormat in RtmpSink", e)
        }
    }

    override fun writeVideo(buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (isClosed || !rtmpClient.isStreaming) return

        // Update telemetry
        _droppedFramesCount.value = rtmpClient.droppedVideoFrames

        // Adaptive Bitrate & Frame Dropping Check
        val isKeyFrame = (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
        val hasCongestion = try { rtmpClient.hasCongestion() } catch (_: Throwable) { false }

        if (hasCongestion) {
            consecutiveCongestedFrames++
            consecutiveCleanFrames = 0

            // Drop non-key video frames under severe congestion, never audio
            if (!isKeyFrame && consecutiveCongestedFrames > 15) {
                return
            }

            // Step down video bitrate
            if (consecutiveCongestedFrames % 60 == 0 && currentEncoderBitrate > minBitrateBps) {
                val newRate = (currentEncoderBitrate * 0.75f).toInt().coerceAtLeast(minBitrateBps)
                currentEncoderBitrate = newRate
                Log.i(TAG, "Network congestion detected: Stepping encoder bitrate down to ${newRate / 1000} kbps")
                onAdaptiveBitrateChanged?.invoke(newRate)
            }
        } else {
            consecutiveCleanFrames++
            consecutiveCongestedFrames = 0

            // Gradually recover bitrate after 150 consecutive clean frames (~5 seconds at 30fps)
            if (consecutiveCleanFrames >= 150 && currentEncoderBitrate < initialBitrateBps) {
                consecutiveCleanFrames = 0
                val newRate = (currentEncoderBitrate * 1.25f).toInt().coerceAtMost(initialBitrateBps)
                currentEncoderBitrate = newRate
                Log.i(TAG, "Network recovered: Stepping encoder bitrate up to ${newRate / 1000} kbps")
                onAdaptiveBitrateChanged?.invoke(newRate)
            }
        }

        try {
            rtmpClient.sendVideo(buffer, info)
        } catch (e: Throwable) {
            Log.w(TAG, "sendVideo exception in RtmpSink", e)
        }
    }

    override fun writeAudio(buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (isClosed || !rtmpClient.isStreaming) return
        try {
            // Audio is never dropped
            rtmpClient.sendAudio(buffer, info)
        } catch (e: Throwable) {
            Log.w(TAG, "sendAudio exception in RtmpSink", e)
        }
    }

    override fun close() {
        if (isClosed) return
        isClosed = true
        isStreamingActive = false
        reconnectJob?.cancel()
        try {
            rtmpClient.disconnect()
        } catch (e: Throwable) {
            Log.w(TAG, "Error disconnecting RtmpClient", e)
        }
        _streamState.value = LiveStreamState.Disconnected
    }
}
