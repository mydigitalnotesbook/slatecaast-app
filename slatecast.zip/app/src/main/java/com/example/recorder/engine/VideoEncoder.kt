package com.example.recorder.engine

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Build
import android.util.Log
import android.view.Surface
import com.example.data.settings.VideoCodecOption
import com.example.recorder.canvas.StageRenderer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Step 12: VideoEncoder
 *
 * Configures MediaCodec (AVC or HEVC) with COLOR_FormatSurface, KEY_I_FRAME_INTERVAL = 1,
 * and constant bitrate mode.
 *
 * - Renders frames on a dedicated thread every 1000/fps ms using StageRenderer.render
 * - Drains encoded video packets on a dedicated output thread into MuxerHub
 * - Uses shared RecordingClock for monotonic timestamps
 */
class VideoEncoder(
    private val stageRenderer: StageRenderer,
    val outputSink: OutputSink,
    private val clock: RecordingClock,
    var customFrameHook: ((android.graphics.Canvas, Int, Int) -> Unit)? = null,
) {
    constructor(
        stageRenderer: StageRenderer,
        muxerHub: MuxerHub,
        clock: RecordingClock,
        customFrameHook: ((android.graphics.Canvas, Int, Int) -> Unit)? = null,
    ) : this(stageRenderer, FileSink(muxerHub), clock, customFrameHook)

    private val isRunning = AtomicBoolean(false)
    private val isPaused = AtomicBoolean(false)
    private val isDraining = AtomicBoolean(false)

    private var codec: MediaCodec? = null
    private var inputSurface: Surface? = null

    private var renderThread: Thread? = null
    private var drainThread: Thread? = null

    fun updateBitrate(newBitrateBps: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                val params = android.os.Bundle().apply {
                    putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, newBitrateBps)
                }
                codec?.setParameters(params)
                Log.i("VideoEncoder", "Dynamically updated video bitrate to ${newBitrateBps / 1000} kbps")
            }
        } catch (e: Throwable) {
            Log.w("VideoEncoder", "updateBitrate failed: ${e.message}")
        }
    }

    fun start(
        width: Int,
        height: Int,
        fps: Int = 30,
        bitrate: Int = 4_000_000,
        codecOption: VideoCodecOption = VideoCodecOption.H264,
    ) {
        if (isRunning.get()) return

        val primaryMime = if (codecOption == VideoCodecOption.HEVC) {
            MediaFormat.MIMETYPE_VIDEO_HEVC
        } else {
            MediaFormat.MIMETYPE_VIDEO_AVC
        }

        // Resolution must be even
        var validWidth = if (width % 2 != 0) width - 1 else width
        var validHeight = if (height % 2 != 0) height - 1 else height

        // Configuration attempt helper
        fun attemptConfigure(
            mime: String,
            w: Int,
            h: Int,
            bitrateMode: Int?,
        ): Pair<MediaCodec, Surface> {
            val format = MediaFormat.createVideoFormat(mime, w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                if (bitrateMode != null) {
                    setInteger(MediaFormat.KEY_BITRATE_MODE, bitrateMode)
                }
            }

            val enc = MediaCodec.createEncoderByType(mime)
            try {
                enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val s = enc.createInputSurface()
                enc.start()
                return Pair(enc, s)
            } catch (e: Throwable) {
                try { enc.release() } catch (_: Throwable) {}
                throw e
            }
        }

        // Try configurations with graceful fallbacks
        var configured: Pair<MediaCodec, Surface>? = null
        val mimesToTry = if (primaryMime == MediaFormat.MIMETYPE_VIDEO_HEVC) {
            listOf(MediaFormat.MIMETYPE_VIDEO_HEVC, MediaFormat.MIMETYPE_VIDEO_AVC)
        } else {
            listOf(MediaFormat.MIMETYPE_VIDEO_AVC)
        }

        var lastError: Throwable? = null
        for (mime in mimesToTry) {
            // 1. Try VBR (most universally compatible)
            try {
                configured = attemptConfigure(mime, validWidth, validHeight, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                break
            } catch (e: Throwable) {
                lastError = e
                Log.w("VideoEncoder", "Failed to configure $mime at ${validWidth}x${validHeight} with VBR: ${e.message}")
            }

            // 2. Try default (no bitrate mode key)
            try {
                configured = attemptConfigure(mime, validWidth, validHeight, null)
                break
            } catch (e: Throwable) {
                lastError = e
                Log.w("VideoEncoder", "Failed to configure $mime at ${validWidth}x${validHeight} with default mode: ${e.message}")
            }

            // 3. If high resolution, try 720p fallback
            if (validWidth > 1280 || validHeight > 1280) {
                val fbWidth = if (validWidth >= validHeight) 1280 else 720
                val fbHeight = if (validWidth >= validHeight) 720 else 1280
                try {
                    configured = attemptConfigure(mime, fbWidth, fbHeight, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                    validWidth = fbWidth
                    validHeight = fbHeight
                    break
                } catch (e: Throwable) {
                    lastError = e
                    Log.w("VideoEncoder", "Failed to configure $mime at 720p fallback: ${e.message}")
                }
            }
        }

        if (configured == null) {
            throw lastError ?: IllegalStateException("Unable to initialize video encoder on this device")
        }

        val (encoder, surface) = configured
        codec = encoder
        inputSurface = surface
        isRunning.set(true)
        isPaused.set(false)
        isDraining.set(true)

        // 1. Dedicated Surface Rendering Thread
        renderThread = Thread({
            val frameIntervalMs = 1000L / fps.coerceAtLeast(1)
            while (isRunning.get()) {
                val loopStartTime = System.currentTimeMillis()

                if (!isPaused.get()) {
                    val canvas = try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            try {
                                surface.lockHardwareCanvas()
                            } catch (_: Throwable) {
                                @Suppress("DEPRECATION")
                                surface.lockCanvas(null)
                            }
                        } else {
                            @Suppress("DEPRECATION")
                            surface.lockCanvas(null)
                        }
                    } catch (e: Throwable) {
                        Log.w("VideoEncoder", "Error locking surface canvas: ${e.message}")
                        null
                    }

                    if (canvas != null) {
                        try {
                            stageRenderer.render(canvas, validWidth, validHeight)
                            customFrameHook?.invoke(canvas, validWidth, validHeight)
                        } finally {
                            try {
                                surface.unlockCanvasAndPost(canvas)
                            } catch (e: Throwable) {
                                Log.w("VideoEncoder", "Error unlocking surface canvas: ${e.message}")
                            }
                        }
                    }
                }

                val elapsed = System.currentTimeMillis() - loopStartTime
                val sleepTime = frameIntervalMs - elapsed
                if (sleepTime > 0) {
                    try {
                        Thread.sleep(sleepTime)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }
        }, "VideoRenderThread").apply { start() }

        // 2. Dedicated Output Drain Thread
        drainThread = Thread({
            val bufferInfo = MediaCodec.BufferInfo()
            while (isDraining.get()) {
                val localCodec = codec ?: break
                val outputBufferIndex = try {
                    localCodec.dequeueOutputBuffer(bufferInfo, 10_000)
                } catch (e: Throwable) {
                    Log.w("VideoEncoder", "dequeueOutputBuffer failed", e)
                    break
                }

                when (outputBufferIndex) {
                    MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        // continue draining
                    }
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val newFormat = localCodec.outputFormat
                        outputSink.onVideoFormat(newFormat)
                    }
                    else -> {
                        if (outputBufferIndex >= 0) {
                            val outputBuffer = localCodec.getOutputBuffer(outputBufferIndex)
                            if (outputBuffer != null) {
                                // Adjust presentation timestamp according to monotonic clock
                                val ptsUs = clock.currentPtsUs()
                                if (bufferInfo.presentationTimeUs < ptsUs) {
                                    bufferInfo.presentationTimeUs = ptsUs
                                }
                                outputSink.writeVideo(outputBuffer, bufferInfo)
                            }
                            localCodec.releaseOutputBuffer(outputBufferIndex, false)

                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                break
                            }
                        }
                    }
                }
            }
        }, "VideoDrainThread").apply { start() }
    }

    fun pause() {
        isPaused.set(true)
    }

    fun resume() {
        isPaused.set(false)
    }

    fun stop() {
        isRunning.set(false)
        try {
            renderThread?.join(500)
        } catch (_: Throwable) {}

        try {
            codec?.signalEndOfInputStream()
        } catch (e: Throwable) {
            Log.w("VideoEncoder", "signalEndOfInputStream failed", e)
        }

        isDraining.set(false)
        try {
            drainThread?.join(500)
        } catch (_: Throwable) {}

        try {
            codec?.stop()
        } catch (_: Throwable) {}
        try {
            codec?.release()
        } catch (_: Throwable) {}
        try {
            inputSurface?.release()
        } catch (_: Throwable) {}

        codec = null
        inputSurface = null
        renderThread = null
        drainThread = null
    }
}
