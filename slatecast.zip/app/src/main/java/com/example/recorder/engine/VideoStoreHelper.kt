package com.example.recorder.engine

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import com.example.R
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class VideoOutput(
    val uri: Uri,
    val pfd: ParcelFileDescriptor,
    val filePath: String? = null,
)

/**
 * Helper object providing createOutputUri and MediaStore publishing for VideoStore.
 */
object VideoStoreHelper {

    fun createOutputUri(context: Context, title: String? = null): VideoOutput {
        val appName = try {
            context.getString(R.string.app_name)
        } catch (_: Throwable) {
            "Teaching Recorder"
        }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val defaultTitle = title?.takeIf { it.isNotBlank() } ?: "Lecture_${timeStamp}"
        val fileName = "${defaultTitle}.mp4"
        val relativePath = "Movies/$appName"

        val contentValues = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, relativePath)
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val resolver = context.contentResolver
        try {
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
            if (uri != null) {
                val pfd = resolver.openFileDescriptor(uri, "rw")
                if (pfd != null) {
                    return VideoOutput(uri = uri, pfd = pfd)
                }
            }
        } catch (e: Throwable) {
            Log.w("VideoStoreHelper", "MediaStore insert/open failed: ${e.message}, falling back to local files")
        }

        // Fallback for JVM test environments where MediaStore openFileDescriptor is not available
        val lecturesDir = File(context.filesDir, "lectures").apply { mkdirs() }
        val fallbackFile = File(lecturesDir, fileName)
        if (!fallbackFile.exists()) {
            fallbackFile.createNewFile()
        }
        val pfd = ParcelFileDescriptor.open(fallbackFile, ParcelFileDescriptor.MODE_READ_WRITE)
        val fileUri = Uri.fromFile(fallbackFile)
        return VideoOutput(uri = fileUri, pfd = pfd, filePath = fallbackFile.absolutePath)
    }

    fun publishOutputUri(context: Context, uri: Uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && uri.scheme == "content") {
            try {
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.IS_PENDING, 0)
                }
                context.contentResolver.update(uri, contentValues, null, null)
            } catch (_: Throwable) {}
        }
    }
}
