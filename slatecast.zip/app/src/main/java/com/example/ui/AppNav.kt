package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.settings.DataStoreSettingsRepository
import com.example.data.settings.OutputAspectRatio
import com.example.data.storage.ProjectRepositoryImpl
import com.example.data.storage.VideoStoreImpl
import com.example.ui.about.AboutScreen
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.lecture.SlidesScreen
import com.example.ui.live.YouTubeLiveScreen
import com.example.ui.recorder.StageScreen
import com.example.ui.library.LibraryScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.settings.SettingsViewModel

object AppRoutes {
    const val HOME = "home"
    const val SLIDES_LIST = "slides-list"
    const val SLIDES_DETAIL = "slides/{projectId}"
    const val STAGE = "stage/{projectId}?autoLive={autoLive}"
    const val LIBRARY = "library"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
    const val YOUTUBE_LIVE = "youtube-live"

    fun slidesDetailRoute(projectId: String) = "slides/$projectId"
    fun stageRoute(projectId: String, autoLive: Boolean = false) =
        "stage/$projectId?autoLive=$autoLive"
}

@Composable
fun AppNav(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val navController = rememberNavController()

    // Instantiate repositories and ViewModels with remember
    val settingsRepo = remember { DataStoreSettingsRepository(context) }
    val projectRepo = remember { ProjectRepositoryImpl(context) }
    val videoStore = remember { VideoStoreImpl(context) }

    val homeViewModel = remember { HomeViewModel(projectRepo, videoStore, settingsRepo) }
    val settingsViewModel = remember { SettingsViewModel(settingsRepo) }

    NavHost(
        navController = navController,
        startDestination = AppRoutes.HOME,
        modifier = modifier,
    ) {
        composable(AppRoutes.HOME) {
            HomeScreen(
                viewModel = homeViewModel,
                onNavigateToSlidesList = {
                    navController.navigate(AppRoutes.SLIDES_LIST)
                },
                onNavigateToLibrary = {
                    navController.navigate(AppRoutes.LIBRARY)
                },
                onNavigateToSettings = {
                    navController.navigate(AppRoutes.SETTINGS)
                },
                onNavigateToAbout = {
                    navController.navigate(AppRoutes.ABOUT)
                },
                onNavigateToLive = {
                    navController.navigate(AppRoutes.YOUTUBE_LIVE)
                },
                onCreateLecture = { sourceType: String, aspect: OutputAspectRatio ->
                    val aspectSuffix = if (aspect == OutputAspectRatio.LANDSCAPE_16_9) "16x9" else "9x16"
                    val newProjectId = "lecture_${sourceType}_${aspectSuffix}_${System.currentTimeMillis() % 10000}"
                    navController.navigate(AppRoutes.slidesDetailRoute(newProjectId))
                },
            )
        }

        composable(AppRoutes.YOUTUBE_LIVE) {
            YouTubeLiveScreen(
                onNavigateBack = { navController.popBackStack() },
                onStartLive = { config ->
                    val liveProjectId = "live_stream_project"
                    navController.navigate(AppRoutes.stageRoute(liveProjectId, autoLive = true))
                },
            )
        }

        composable(AppRoutes.SLIDES_LIST) {
            SlidesScreen(
                projectId = "all_projects",
                onNavigateToStage = { id ->
                    navController.navigate(AppRoutes.stageRoute(id))
                },
                onNavigateBack = { navController.popBackStack() },
            )
        }

        composable(
            route = AppRoutes.SLIDES_DETAIL,
            arguments = listOf(
                navArgument("projectId") {
                    type = NavType.StringType
                    defaultValue = "default_project"
                },
            ),
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId") ?: "default_project"
            SlidesScreen(
                projectId = projectId,
                onNavigateToStage = { id ->
                    navController.navigate(AppRoutes.stageRoute(id))
                },
                onNavigateBack = { navController.popBackStack() },
            )
        }

        composable(
            route = AppRoutes.STAGE,
            arguments = listOf(
                navArgument("projectId") {
                    type = NavType.StringType
                    defaultValue = "default_project"
                },
                navArgument("autoLive") {
                    type = NavType.BoolType
                    defaultValue = false
                },
            ),
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId") ?: "default_project"
            val autoLive = backStackEntry.arguments?.getBoolean("autoLive") ?: false
            StageScreen(
                projectId = projectId,
                autoStartLive = autoLive,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToLibrary = { navController.navigate(AppRoutes.LIBRARY) },
                onNavigateToSettings = { navController.navigate(AppRoutes.SETTINGS) },
            )
        }

        composable(AppRoutes.LIBRARY) {
            LibraryScreen(
                videoStore = videoStore,
                onNavigateBack = { navController.popBackStack() },
            )
        }

        composable(AppRoutes.SETTINGS) {
            SettingsScreen(
                viewModel = settingsViewModel,
                onNavigateBack = { navController.popBackStack() },
            )
        }

        composable(AppRoutes.ABOUT) {
            AboutScreen(
                onNavigateBack = { navController.popBackStack() },
            )
        }
    }
}
