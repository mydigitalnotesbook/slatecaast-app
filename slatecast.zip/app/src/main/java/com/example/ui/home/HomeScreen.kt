package com.example.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Web
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.settings.OutputAspectRatio
import com.example.data.settings.SettingsRepository
import com.example.data.settings.DataStoreSettingsRepository
import com.example.data.storage.ProjectRepository
import com.example.data.storage.ProjectRepositoryImpl
import com.example.data.storage.VideoStore
import com.example.data.storage.VideoStoreImpl
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Home screen for SlateCast per Step 4.
 * Displays:
 * 1. TopAppBar with app name and 3-dot overflow menu ("Recorder settings", "About")
 * 2. Two folder rows: "Slides" and "Lectures" reading counts from ProjectRepository and VideoStore
 * 3. Floating "+" button opening bottom sheet "Create lecture using" with aspect ratio selector and 3 sources
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel? = null,
    onNavigateToSlidesList: () -> Unit = {},
    onNavigateToLibrary: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {},
    onNavigateToAbout: () -> Unit = {},
    onNavigateToLive: () -> Unit = {},
    onCreateLecture: (sourceType: String, aspect: OutputAspectRatio) -> Unit = { _, _ -> },
    onNavigateToSlides: (String) -> Unit = {},
    onNavigateToStage: (String) -> Unit = {},
    projectRepository: ProjectRepository = rememberProjectRepository(),
    videoStore: VideoStore = rememberVideoStore(),
    settingsRepository: SettingsRepository = rememberSettingsRepository(),
) {
    val uiStateFromVm by viewModel?.uiState?.collectAsState() ?: remember { mutableStateOf(null) }

    val projectCountState by projectRepository.projectCountFlow.collectAsState(initial = 0)
    val projectLastModifiedState by projectRepository.lastModifiedFlow.collectAsState(initial = null)

    val videoCountState by videoStore.videoCountFlow.collectAsState(initial = 0)
    val videoLastModifiedState by videoStore.lastModifiedFlow.collectAsState(initial = null)

    val defaultAspectSettingState by settingsRepository.defaultAspectFlow.collectAsState(initial = OutputAspectRatio.LANDSCAPE_16_9)

    val projectCount = uiStateFromVm?.projectCount ?: projectCountState
    val projectLastModified = uiStateFromVm?.projectLastModified ?: projectLastModifiedState
    val videoCount = uiStateFromVm?.videoCount ?: videoCountState
    val videoLastModified = uiStateFromVm?.videoLastModified ?: videoLastModifiedState
    val defaultAspectSetting = uiStateFromVm?.defaultAspect ?: defaultAspectSettingState

    var showMenu by remember { mutableStateOf(false) }
    var showCreateSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        modifier = modifier.testTag("home_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(R.drawable.ic_app_logo),
                            contentDescription = stringResource(R.string.app_name),
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp)),
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = stringResource(R.string.app_tagline),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.testTag("home_overflow_menu_btn"),
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = stringResource(R.string.home_menu_settings),
                        )
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                    ) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.home_menu_settings)) },
                            onClick = {
                                showMenu = false
                                onNavigateToSettings()
                            },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Settings, contentDescription = null)
                            },
                            modifier = Modifier.testTag("menu_item_settings"),
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.home_menu_about)) },
                            onClick = {
                                showMenu = false
                                onNavigateToAbout()
                            },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Info, contentDescription = null)
                            },
                            modifier = Modifier.testTag("menu_item_about"),
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                ),
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateSheet = true },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary,
                modifier = Modifier.testTag("fab_create_lecture"),
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = stringResource(R.string.bottom_sheet_create_title),
                )
            }
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Live Stream Card: Go Live to YouTube
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onNavigateToLive)
                        .testTag("home_go_live_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFE50914).copy(alpha = 0.5f)),
                ) {
                    Row(
                        modifier = Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Surface(
                            color = Color(0xFFE50914).copy(alpha = 0.14f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(52.dp),
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Videocam,
                                    contentDescription = stringResource(R.string.btn_go_live),
                                    tint = Color(0xFFE50914),
                                    modifier = Modifier.size(30.dp),
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = stringResource(R.string.live_title),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    color = Color(0xFFE50914),
                                    shape = RoundedCornerShape(4.dp),
                                ) {
                                    Text(
                                        text = "LIVE",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Stream slides + drawing + microphone live to YouTube",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = onNavigateToLive,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFE50914),
                                contentColor = Color.White,
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("btn_go_live_home"),
                        ) {
                            Text(stringResource(R.string.btn_go_live), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Folder Row 1: Slides
            item {
                FolderRowCard(
                    title = stringResource(R.string.folder_slides_title),
                    subtitle = if (projectCount > 0) {
                        stringResource(
                            R.string.folder_slides_subtitle,
                            projectCount,
                            formatDate(projectLastModified),
                        )
                    } else {
                        stringResource(R.string.folder_slides_empty)
                    },
                    icon = Icons.Default.Folder,
                    iconTint = MaterialTheme.colorScheme.primary,
                    testTag = "folder_slides_card",
                    onClick = onNavigateToSlidesList,
                )
            }

            // Folder Row 2: Lectures
            item {
                FolderRowCard(
                    title = stringResource(R.string.folder_lectures_title),
                    subtitle = if (videoCount > 0) {
                        stringResource(
                            R.string.folder_lectures_subtitle,
                            videoCount,
                            formatDate(videoLastModified),
                        )
                    } else {
                        stringResource(R.string.folder_lectures_empty)
                    },
                    icon = Icons.Default.VideoLibrary,
                    iconTint = MaterialTheme.colorScheme.secondary,
                    testTag = "folder_lectures_card",
                    onClick = onNavigateToLibrary,
                )
            }
        }
    }

    // Bottom Sheet: "Create lecture using"
    if (showCreateSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCreateSheet = false },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface,
        ) {
            CreateLectureBottomSheetContent(
                initialAspect = defaultAspectSetting,
                onSelectSource = { source, aspect ->
                    coroutineScope.launch { sheetState.hide() }.invokeOnCompletion {
                        showCreateSheet = false
                        onCreateLecture(source, aspect)
                    }
                },
            )
        }
    }
}

@Composable
private fun FolderRowCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    testTag: String,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
        ),
        border = CardDefaults.outlinedCardBorder(),
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Surface(
                color = iconTint.copy(alpha = 0.12f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(52.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(30.dp),
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
private fun CreateLectureBottomSheetContent(
    initialAspect: OutputAspectRatio,
    onSelectSource: (sourceType: String, aspect: OutputAspectRatio) -> Unit,
) {
    var selectedAspect by remember(initialAspect) { mutableStateOf(initialAspect) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp)
            .padding(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(
            text = stringResource(R.string.bottom_sheet_create_title),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )

        // 1. Aspect Ratio Selector at top of sheet
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AspectRatio,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = MaterialTheme.colorScheme.primary,
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.aspect_ratio_title),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                FilterChip(
                    selected = (selectedAspect == OutputAspectRatio.LANDSCAPE_16_9),
                    onClick = { selectedAspect = OutputAspectRatio.LANDSCAPE_16_9 },
                    label = { Text(stringResource(R.string.aspect_16_9_label)) },
                    modifier = Modifier.weight(1f),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    ),
                )
                FilterChip(
                    selected = (selectedAspect == OutputAspectRatio.PORTRAIT_9_16),
                    onClick = { selectedAspect = OutputAspectRatio.PORTRAIT_9_16 },
                    label = { Text(stringResource(R.string.aspect_9_16_label)) },
                    modifier = Modifier.weight(1f),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    ),
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 2. Three choices
        CreateSourceChoiceRow(
            icon = Icons.Default.Image,
            title = stringResource(R.string.create_option_slides),
            subtitle = stringResource(R.string.create_option_slides_desc),
            onClick = { onSelectSource("images", selectedAspect) },
        )

        CreateSourceChoiceRow(
            icon = Icons.Default.PictureAsPdf,
            title = stringResource(R.string.create_option_pdf),
            subtitle = stringResource(R.string.create_option_pdf_desc),
            onClick = { onSelectSource("pdf", selectedAspect) },
        )

        CreateSourceChoiceRow(
            icon = Icons.Default.Web,
            title = stringResource(R.string.create_option_web),
            subtitle = stringResource(R.string.create_option_web_desc),
            onClick = { onSelectSource("web", selectedAspect) },
        )
    }
}

@Composable
private fun CreateSourceChoiceRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        ),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp),
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

private fun formatDate(timestamp: Long?): String {
    if (timestamp == null || timestamp <= 0L) return "Recently"
    return SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(timestamp))
}

@Composable
fun rememberProjectRepository(): ProjectRepository {
    val context = LocalContext.current.applicationContext
    return remember { ProjectRepositoryImpl(context) }
}

@Composable
fun rememberVideoStore(): VideoStore {
    val context = LocalContext.current.applicationContext
    return remember { VideoStoreImpl(context) }
}

@Composable
fun rememberSettingsRepository(): SettingsRepository {
    val context = LocalContext.current.applicationContext
    return remember { DataStoreSettingsRepository(context) }
}
