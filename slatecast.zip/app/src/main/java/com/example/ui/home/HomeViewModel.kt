package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.settings.OutputAspectRatio
import com.example.data.settings.SettingsRepository
import com.example.data.storage.ProjectRepository
import com.example.data.storage.VideoStore
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class HomeUiState(
    val projectCount: Int = 0,
    val projectLastModified: Long? = null,
    val videoCount: Int = 0,
    val videoLastModified: Long? = null,
    val defaultAspect: OutputAspectRatio = OutputAspectRatio.LANDSCAPE_16_9,
)

class HomeViewModel(
    projectRepository: ProjectRepository,
    videoStore: VideoStore,
    settingsRepository: SettingsRepository,
) : ViewModel() {

    val uiState: StateFlow<HomeUiState> = combine(
        projectRepository.projectCountFlow,
        projectRepository.lastModifiedFlow,
        videoStore.videoCountFlow,
        videoStore.lastModifiedFlow,
        settingsRepository.settingsFlow,
    ) { pCount, pMod, vCount, vMod, settings ->
        HomeUiState(
            projectCount = pCount,
            projectLastModified = pMod,
            videoCount = vCount,
            videoLastModified = vMod,
            defaultAspect = settings.defaultAspect,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState(),
    )
}
