package com.example.ui.lecture

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowBackIos
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CropLandscape
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Square
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.data.settings.OutputAspectRatio
import com.example.data.storage.SlideItem
import com.example.data.storage.SlideProjectRepositoryImpl
import com.example.ui.theme.EmptySlidesArt
import kotlinx.coroutines.launch
import java.io.File

/**
 * Slide import and slide list screen per Step 7.
 * Features:
 * - Grid of slide thumbnails with page numbers
 * - Empty state showing EmptySlidesArt and "Add images or PDF pages"
 * - "+" button offering:
 *     1. Images (Photo Picker, multiple selection)
 *     2. Camera (take photo via TakePicture)
 *     3. PDF (PdfRenderer into JPEG quality 90, progress bar, IO thread, bitmap recycled)
 *     4. Blank board (plain white slide / plain black slide)
 * - Long-press to delete, reorder buttons (earlier/later)
 * - "Start recording" button opening stage/{projectId}
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SlidesScreen(
    projectId: String,
    onNavigateToStage: (String) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: SlidesViewModel = rememberSlidesViewModel(projectId),
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val project by viewModel.projectState.collectAsStateWithLifecycle()
    val isImporting by viewModel.isImporting.collectAsStateWithLifecycle()
    val importProgress by viewModel.importProgress.collectAsStateWithLifecycle()

    var showAddSheet by remember { mutableStateOf(false) }
    var slideToDelete by remember { mutableStateOf<SlideItem?>(null) }
    var hasAutoTriggered by remember { mutableStateOf(false) }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // 1. Android Photo Picker (Multiple Selection)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(),
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.importImages(context, uris)
        }
    }

    // 2. Camera TakePicture Launcher
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture(),
    ) { success: Boolean ->
        viewModel.onCameraPhotoTaken(success)
        pendingCameraUri = null
    }

    // 3. PDF Document Picker Launcher
    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importPdf(context, uri)
        }
    }

    // Auto-launch flow if project was just created from Home choice
    LaunchedEffect(projectId) {
        if (!hasAutoTriggered) {
            hasAutoTriggered = true
            when {
                projectId.contains("lecture_images_") -> {
                    photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                projectId.contains("lecture_pdf_") -> {
                    pdfPickerLauncher.launch(arrayOf("application/pdf"))
                }
            }
        }
    }

    val isLandscape = (project?.aspectRatio ?: OutputAspectRatio.LANDSCAPE_16_9) == OutputAspectRatio.LANDSCAPE_16_9
    val ratioFloat = if (isLandscape) 16f / 9f else 9f / 16f

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("slides_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = project?.title ?: stringResource(R.string.screen_slides_title),
                            style = MaterialTheme.typography.titleLarge,
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isLandscape) "16:9 Landscape" else "9:16 Portrait",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                            )
                            val count = project?.slides?.size ?: 0
                            Text(
                                text = " • $count slides",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("slides_back_btn")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.btn_back),
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = { viewModel.loadSampleSlides(context) },
                        enabled = !isImporting,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("load_sample_slides_btn"),
                        colors = ButtonDefaults.outlinedButtonColors(),
                        border = ButtonDefaults.outlinedButtonBorder(),
                    ) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.btn_load_sample_slides))
                    }

                    Button(
                        onClick = { onNavigateToStage(projectId) },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("slides_start_recording_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = MaterialTheme.colorScheme.onSecondary,
                        ),
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.btn_start_recording))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                ),
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddSheet = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_add_slide"),
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = stringResource(R.string.btn_add_slide),
                )
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            val slides = project?.slides ?: emptyList()

            if (slides.isEmpty()) {
                // Empty state per Step 7: show EmptySlidesArt and "Add images or PDF pages"
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    EmptySlidesArt(modifier = Modifier.size(180.dp))
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = stringResource(R.string.slides_empty_callout),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Button(
                            onClick = { showAddSheet = true },
                            modifier = Modifier.testTag("btn_empty_add_slide"),
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.btn_add_slide))
                        }

                        Button(
                            onClick = { viewModel.loadSampleSlides(context) },
                            enabled = !isImporting,
                            modifier = Modifier.testTag("empty_load_sample_slides_btn"),
                            colors = ButtonDefaults.outlinedButtonColors(),
                            border = ButtonDefaults.outlinedButtonBorder(),
                        ) {
                            Icon(imageVector = Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.btn_load_sample_slides))
                        }
                    }
                }
            } else {
                // Grid of slide thumbnails with page numbers
                val columns = if (isLandscape) 2 else 3
                LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .testTag("slides_grid"),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    itemsIndexed(slides, key = { _, item -> item.id }) { index, slide ->
                        SlideThumbnailCard(
                            slide = slide,
                            aspectRatioFloat = ratioFloat,
                            isFirst = index == 0,
                            isLast = index == slides.size - 1,
                            onMoveEarlier = { viewModel.moveSlide(index, index - 1) },
                            onMoveLater = { viewModel.moveSlide(index, index + 1) },
                            onLongPress = { slideToDelete = slide },
                            onDelete = { slideToDelete = slide },
                        )
                    }
                }
            }

            // PDF/Image importing progress overlay
            if (isImporting) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black.copy(alpha = 0.5f),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.padding(32.dp),
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                val progress = importProgress
                                if (progress != null && progress.second > 0) {
                                    Text(
                                        text = stringResource(R.string.pdf_rendering_title),
                                        style = MaterialTheme.typography.titleMedium,
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    LinearProgressIndicator(
                                        progress = { progress.first.toFloat() / progress.second.toFloat() },
                                        modifier = Modifier.fillMaxWidth().height(8.dp),
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = stringResource(R.string.pdf_rendering_progress, progress.first, progress.second),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                } else {
                                    CircularProgressIndicator()
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = stringResource(R.string.pdf_rendering_title),
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Bottom Sheet: 4 Add Slide Choices
    if (showAddSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAddSheet = false },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    text = stringResource(R.string.btn_add_slide),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )

                // 1. Images
                AddSlideOptionRow(
                    icon = Icons.Default.Image,
                    title = stringResource(R.string.add_slide_choice_images),
                    subtitle = "Pick from gallery (multiple selection)",
                    onClick = {
                        coroutineScope.launch { sheetState.hide() }.invokeOnCompletion {
                            showAddSheet = false
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    },
                )

                // 2. Camera
                AddSlideOptionRow(
                    icon = Icons.Default.CameraAlt,
                    title = stringResource(R.string.add_slide_choice_camera),
                    subtitle = "Capture document or whiteboard",
                    onClick = {
                        coroutineScope.launch { sheetState.hide() }.invokeOnCompletion {
                            showAddSheet = false
                            val uri = viewModel.prepareCameraCaptureUri(context)
                            pendingCameraUri = uri
                            cameraLauncher.launch(uri)
                        }
                    },
                )

                // 3. PDF
                AddSlideOptionRow(
                    icon = Icons.Default.PictureAsPdf,
                    title = stringResource(R.string.add_slide_choice_pdf),
                    subtitle = "Render all pages at high resolution",
                    onClick = {
                        coroutineScope.launch { sheetState.hide() }.invokeOnCompletion {
                            showAddSheet = false
                            pdfPickerLauncher.launch(arrayOf("application/pdf"))
                        }
                    },
                )

                // 4. Blank Board
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                coroutineScope.launch { sheetState.hide() }.invokeOnCompletion {
                                    showAddSheet = false
                                    viewModel.addBlankSlide(isWhite = true)
                                }
                            },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White,
                                border = ButtonDefaults.outlinedButtonBorder(),
                                modifier = Modifier.size(24.dp),
                            ) {}
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = stringResource(R.string.add_slide_choice_white),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                coroutineScope.launch { sheetState.hide() }.invokeOnCompletion {
                                    showAddSheet = false
                                    viewModel.addBlankSlide(isWhite = false)
                                }
                            },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.Black,
                                modifier = Modifier.size(24.dp),
                            ) {}
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = stringResource(R.string.add_slide_choice_black),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }

                    // 5. Interactive Web Page Slide (Step 17)
                    Card(
                        onClick = {
                            showAddSheet = false
                            viewModel.addWebSlide("https://en.wikipedia.org")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_slide_web_btn"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp),
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = stringResource(R.string.add_slide_choice_web),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }

                    // 6. Temporary Debug: Load Sample Slides
                    Card(
                        onClick = {
                            coroutineScope.launch { sheetState.hide() }.invokeOnCompletion {
                                showAddSheet = false
                                viewModel.loadSampleSlides(context)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sheet_load_sample_slides_btn"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp),
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = stringResource(R.string.btn_load_sample_slides),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Text(
                                    text = "3 Canvas images + 1 sample PDF (3 pages)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Delete Confirmation Dialog
    slideToDelete?.let { slide ->
        AlertDialog(
            onDismissRequest = { slideToDelete = null },
            title = { Text(stringResource(R.string.slide_delete_title)) },
            text = { Text(stringResource(R.string.slide_delete_msg, slide.pageNumber)) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSlide(slide.id)
                        slideToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) {
                    Text(stringResource(R.string.btn_delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { slideToDelete = null }) {
                    Text(stringResource(R.string.btn_cancel))
                }
            },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SlideThumbnailCard(
    slide: SlideItem,
    aspectRatioFloat: Float,
    isFirst: Boolean,
    isLast: Boolean,
    onMoveEarlier: () -> Unit,
    onMoveLater: () -> Unit,
    onLongPress: () -> Unit,
    onDelete: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = {},
                onLongClick = onLongPress,
            )
            .testTag("slide_thumbnail_${slide.pageNumber}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(aspectRatioFloat)
                    .background(Color(0xFF1E222A)),
            ) {
                AsyncImage(
                    model = File(slide.filePath),
                    contentDescription = "Slide ${slide.pageNumber}",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit,
                )

                // Page number chip in upper corner
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(bottomEnd = 8.dp),
                    modifier = Modifier.align(Alignment.TopStart),
                ) {
                    Text(
                        text = "#${slide.pageNumber}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    )
                }

                // Delete quick icon
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(2.dp)
                        .size(32.dp),
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = stringResource(R.string.slide_action_delete),
                                tint = Color.White,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                    }
                }
            }

            // Bottom bar with reorder controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(
                    onClick = onMoveEarlier,
                    enabled = !isFirst,
                    modifier = Modifier.size(32.dp),
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBackIos,
                        contentDescription = stringResource(R.string.slide_move_left),
                        modifier = Modifier.size(14.dp),
                        tint = if (!isFirst) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                    )
                }

                Text(
                    text = stringResource(R.string.slide_page_badge, slide.pageNumber),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                IconButton(
                    onClick = onMoveLater,
                    enabled = !isLast,
                    modifier = Modifier.size(32.dp),
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                        contentDescription = stringResource(R.string.slide_move_right),
                        modifier = Modifier.size(14.dp),
                        tint = if (!isLast) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                    )
                }
            }
        }
    }
}

@Composable
private fun AddSlideOptionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp),
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun rememberSlidesViewModel(projectId: String): SlidesViewModel {
    val context = LocalContext.current.applicationContext
    return remember(projectId) {
        val repo = SlideProjectRepositoryImpl(context)
        SlidesViewModel(projectId, repo)
    }
}
