package com.example.ui.lecture

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.settings.OutputAspectRatio
import com.example.data.storage.ProjectInfo
import com.example.data.storage.SlideImportUtils
import com.example.data.storage.SlideProjectRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class SlidesViewModel(
    val projectId: String,
    private val repository: SlideProjectRepository,
) : ViewModel() {

    val projectState: StateFlow<ProjectInfo?> = repository.getProjectFlow(projectId)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null,
        )

    private val _isImporting = MutableStateFlow(false)
    val isImporting: StateFlow<Boolean> = _isImporting.asStateFlow()

    private val _importProgress = MutableStateFlow<Pair<Int, Int>?>(null)
    val importProgress: StateFlow<Pair<Int, Int>?> = _importProgress.asStateFlow()

    private var currentCameraTempFile: File? = null

    fun prepareCameraCaptureUri(context: Context): Uri {
        val file = repository.createTempCameraFile()
        currentCameraTempFile = file
        val authority = "${context.packageName}.fileprovider"
        return FileProvider.getUriForFile(context, authority, file)
    }

    fun onCameraPhotoTaken(success: Boolean) {
        val tempFile = currentCameraTempFile ?: return
        if (!success) {
            tempFile.delete()
            currentCameraTempFile = null
            return
        }

        viewModelScope.launch {
            _isImporting.value = true
            try {
                val current = repository.getProject(projectId)
                val aspect = current?.aspectRatio ?: OutputAspectRatio.LANDSCAPE_16_9
                val finalFile = SlideImportUtils.importCameraPhoto(tempFile, projectId, aspect)
                if (finalFile != null) {
                    repository.addSlidesToProject(projectId, listOf(finalFile), "camera")
                }
            } finally {
                currentCameraTempFile = null
                _isImporting.value = false
            }
        }
    }

    fun importImages(context: Context, uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _isImporting.value = true
            try {
                val current = repository.getProject(projectId)
                val aspect = current?.aspectRatio ?: OutputAspectRatio.LANDSCAPE_16_9
                val files = SlideImportUtils.importImages(context, uris, projectId, aspect)
                if (files.isNotEmpty()) {
                    repository.addSlidesToProject(projectId, files, "image")
                }
            } finally {
                _isImporting.value = false
            }
        }
    }

    fun importPdf(context: Context, pdfUri: Uri) {
        viewModelScope.launch {
            _isImporting.value = true
            _importProgress.value = Pair(0, 1)
            try {
                val current = repository.getProject(projectId)
                val aspect = current?.aspectRatio ?: OutputAspectRatio.LANDSCAPE_16_9
                val files = SlideImportUtils.importPdfPages(
                    context = context,
                    pdfUri = pdfUri,
                    projectId = projectId,
                    aspect = aspect,
                    onProgress = { currentIdx, total ->
                        _importProgress.value = Pair(currentIdx, total)
                    },
                )
                if (files.isNotEmpty()) {
                    repository.addSlidesToProject(projectId, files, "pdf")
                }
            } finally {
                _isImporting.value = false
                _importProgress.value = null
            }
        }
    }

    fun addBlankSlide(isWhite: Boolean) {
        viewModelScope.launch {
            repository.addBlankSlide(projectId, isWhite)
        }
    }

    fun addWebSlide(url: String = "https://en.wikipedia.org") {
        viewModelScope.launch {
            repository.addWebSlide(projectId, url)
        }
    }

    fun deleteSlide(slideId: String) {
        viewModelScope.launch {
            repository.deleteSlide(projectId, slideId)
        }
    }

    fun moveSlide(fromIndex: Int, toIndex: Int) {
        viewModelScope.launch {
            repository.reorderSlides(projectId, fromIndex, toIndex)
        }
    }

    /**
     * Temporary debug helper to create sample slides:
     * - 3 plain image slides drawn with Canvas and saved as JPEG at the project's ratio
     * - 1 sample PDF generated with PdfDocument (3 pages), imported through the normal PDF import path
     */
    fun loadSampleSlides(context: Context): kotlinx.coroutines.Job {
        return viewModelScope.launch {
            _isImporting.value = true
            try {
                val current = repository.getProject(projectId)
                val aspect = current?.aspectRatio ?: OutputAspectRatio.LANDSCAPE_16_9
                val targetWidth = if (aspect == OutputAspectRatio.LANDSCAPE_16_9) 1920 else 1080
                val targetHeight = if (aspect == OutputAspectRatio.LANDSCAPE_16_9) 1080 else 1920

                val slidesDir = File(File(context.filesDir, "projects/$projectId"), "slides").apply { mkdirs() }
                val imageFiles = mutableListOf<File>()

                // 1. Generate 3 plain image slides with Canvas
                val slideConfigs = listOf(
                    Triple(
                        "Introduction to Computing",
                        android.graphics.Color.rgb(24, 32, 54),
                        listOf(
                            android.graphics.Color.rgb(79, 110, 247),
                            android.graphics.Color.rgb(255, 179, 0),
                            android.graphics.Color.rgb(0, 200, 83),
                        ),
                    ),
                    Triple(
                        "Algorithm Architecture",
                        android.graphics.Color.rgb(38, 50, 56),
                        listOf(
                            android.graphics.Color.rgb(255, 87, 34),
                            android.graphics.Color.rgb(3, 169, 244),
                            android.graphics.Color.rgb(233, 30, 99),
                        ),
                    ),
                    Triple(
                        "Data Flow & Processing",
                        android.graphics.Color.rgb(27, 42, 34),
                        listOf(
                            android.graphics.Color.rgb(0, 230, 118),
                            android.graphics.Color.rgb(255, 214, 0),
                            android.graphics.Color.rgb(171, 71, 188),
                        ),
                    ),
                )

                for ((idx, config) in slideConfigs.withIndex()) {
                    val (title, bgColor, shapeColors) = config
                    val bitmap = android.graphics.Bitmap.createBitmap(targetWidth, targetHeight, android.graphics.Bitmap.Config.ARGB_8888)
                    val canvas = android.graphics.Canvas(bitmap)

                    // Draw Background
                    canvas.drawColor(bgColor)

                    // Draw Title Text
                    val textPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = android.graphics.Color.WHITE
                        textSize = if (targetWidth > targetHeight) 64f else 52f
                        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                        textAlign = android.graphics.Paint.Align.CENTER
                    }
                    canvas.drawText(title, targetWidth / 2f, targetHeight * 0.22f, textPaint)

                    val subPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = android.graphics.Color.argb(190, 255, 255, 255)
                        textSize = if (targetWidth > targetHeight) 36f else 28f
                        textAlign = android.graphics.Paint.Align.CENTER
                    }
                    canvas.drawText("Sample Slide ${idx + 1} • Teaching Recorder Engine", targetWidth / 2f, targetHeight * 0.30f, subPaint)

                    // Draw shapes with different colors
                    val shapePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        style = android.graphics.Paint.Style.FILL
                    }

                    when (idx) {
                        0 -> {
                            // Rounded cards & circle
                            shapePaint.color = shapeColors[0]
                            canvas.drawRoundRect(targetWidth * 0.15f, targetHeight * 0.42f, targetWidth * 0.45f, targetHeight * 0.72f, 24f, 24f, shapePaint)
                            shapePaint.color = shapeColors[1]
                            canvas.drawRoundRect(targetWidth * 0.55f, targetHeight * 0.42f, targetWidth * 0.85f, targetHeight * 0.72f, 24f, 24f, shapePaint)
                            shapePaint.color = shapeColors[2]
                            canvas.drawCircle(targetWidth * 0.5f, targetHeight * 0.84f, targetHeight * 0.08f, shapePaint)
                        }
                        1 -> {
                            // Concentric & distinct circles
                            shapePaint.color = shapeColors[0]
                            canvas.drawCircle(targetWidth * 0.32f, targetHeight * 0.56f, targetHeight * 0.18f, shapePaint)
                            shapePaint.color = shapeColors[1]
                            canvas.drawCircle(targetWidth * 0.68f, targetHeight * 0.56f, targetHeight * 0.18f, shapePaint)
                            shapePaint.color = shapeColors[2]
                            canvas.drawRoundRect(targetWidth * 0.2f, targetHeight * 0.82f, targetWidth * 0.8f, targetHeight * 0.88f, 16f, 16f, shapePaint)
                        }
                        2 -> {
                            // Connected block nodes
                            shapePaint.color = shapeColors[0]
                            canvas.drawRoundRect(targetWidth * 0.15f, targetHeight * 0.45f, targetWidth * 0.35f, targetHeight * 0.68f, 20f, 20f, shapePaint)
                            shapePaint.color = shapeColors[1]
                            canvas.drawRoundRect(targetWidth * 0.40f, targetHeight * 0.45f, targetWidth * 0.60f, targetHeight * 0.68f, 20f, 20f, shapePaint)
                            shapePaint.color = shapeColors[2]
                            canvas.drawRoundRect(targetWidth * 0.65f, targetHeight * 0.45f, targetWidth * 0.85f, targetHeight * 0.68f, 20f, 20f, shapePaint)

                            val linePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                                color = android.graphics.Color.WHITE
                                strokeWidth = 8f
                                style = android.graphics.Paint.Style.STROKE
                            }
                            canvas.drawLine(targetWidth * 0.35f, targetHeight * 0.565f, targetWidth * 0.40f, targetHeight * 0.565f, linePaint)
                            canvas.drawLine(targetWidth * 0.60f, targetHeight * 0.565f, targetWidth * 0.65f, targetHeight * 0.565f, linePaint)
                        }
                    }

                    val outFile = File(slidesDir, "sample_img_${System.currentTimeMillis()}_${idx + 1}.jpg")
                    withContext(kotlinx.coroutines.Dispatchers.IO) {
                        java.io.FileOutputStream(outFile).use { fos ->
                            bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, fos)
                        }
                    }
                    bitmap.recycle()
                    imageFiles.add(outFile)
                }

                // Add the 3 image slides to the project
                repository.addSlidesToProject(projectId, imageFiles, "image")

                // 2. Generate 1 sample PDF with android.graphics.pdf.PdfDocument (3 pages with text and shapes)
                val pdfDocument = android.graphics.pdf.PdfDocument()
                val pdfPages = listOf(
                    Pair("PDF Section 1: Foundations", android.graphics.Color.rgb(240, 244, 248)),
                    Pair("PDF Section 2: Architecture", android.graphics.Color.rgb(253, 242, 242)),
                    Pair("PDF Section 3: Summary", android.graphics.Color.rgb(240, 253, 244)),
                )

                for ((pIdx, pageData) in pdfPages.withIndex()) {
                    val (pTitle, pBg) = pageData
                    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(targetWidth, targetHeight, pIdx + 1).create()
                    val page = pdfDocument.startPage(pageInfo)
                    val pCanvas = page.canvas

                    pCanvas.drawColor(pBg)

                    val pTextPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = android.graphics.Color.rgb(30, 41, 59)
                        textSize = if (targetWidth > targetHeight) 56f else 44f
                        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                        textAlign = android.graphics.Paint.Align.CENTER
                    }
                    pCanvas.drawText(pTitle, targetWidth / 2f, targetHeight * 0.22f, pTextPaint)

                    val pSubPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        color = android.graphics.Color.rgb(100, 116, 139)
                        textSize = if (targetWidth > targetHeight) 32f else 26f
                        textAlign = android.graphics.Paint.Align.CENTER
                    }
                    pCanvas.drawText("Generated via PdfDocument • Page ${pIdx + 1} of 3", targetWidth / 2f, targetHeight * 0.30f, pSubPaint)

                    val pShapePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                        style = android.graphics.Paint.Style.FILL
                    }
                    when (pIdx) {
                        0 -> {
                            pShapePaint.color = android.graphics.Color.rgb(59, 130, 246)
                            pCanvas.drawRoundRect(targetWidth * 0.2f, targetHeight * 0.42f, targetWidth * 0.8f, targetHeight * 0.72f, 24f, 24f, pShapePaint)
                        }
                        1 -> {
                            pShapePaint.color = android.graphics.Color.rgb(239, 68, 68)
                            pCanvas.drawCircle(targetWidth * 0.35f, targetHeight * 0.55f, targetHeight * 0.16f, pShapePaint)
                            pShapePaint.color = android.graphics.Color.rgb(249, 115, 22)
                            pCanvas.drawCircle(targetWidth * 0.65f, targetHeight * 0.55f, targetHeight * 0.16f, pShapePaint)
                        }
                        2 -> {
                            pShapePaint.color = android.graphics.Color.rgb(16, 185, 129)
                            pCanvas.drawRoundRect(targetWidth * 0.25f, targetHeight * 0.45f, targetWidth * 0.75f, targetHeight * 0.65f, 24f, 24f, pShapePaint)
                        }
                    }

                    pdfDocument.finishPage(page)
                }

                val tempPdfFile = File(context.cacheDir, "sample_doc_${System.currentTimeMillis()}.pdf")
                withContext(kotlinx.coroutines.Dispatchers.IO) {
                    java.io.FileOutputStream(tempPdfFile).use { fos ->
                        pdfDocument.writeTo(fos)
                    }
                }
                pdfDocument.close()

                // 3. Import through the normal PDF import path to test the PDF rendering pipeline
                val authority = "${context.packageName}.fileprovider"
                val pdfUri = FileProvider.getUriForFile(context, authority, tempPdfFile)

                _importProgress.value = Pair(0, 3)
                val pdfSlideFiles = SlideImportUtils.importPdfPages(
                    context = context,
                    pdfUri = pdfUri,
                    projectId = projectId,
                    aspect = aspect,
                    onProgress = { currentIdx, total ->
                        _importProgress.value = Pair(currentIdx, total)
                    },
                )
                if (pdfSlideFiles.isNotEmpty()) {
                    repository.addSlidesToProject(projectId, pdfSlideFiles, "pdf")
                }
                tempPdfFile.delete()
            } finally {
                _isImporting.value = false
                _importProgress.value = null
            }
        }
    }
}
