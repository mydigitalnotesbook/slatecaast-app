package com.example.ui.lecture

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

enum class StageTouchMode {
    DRAW,
    BROWSE,
}

/**
 * Step 17: WebStage
 *
 * Provides live web page presentation within the stage rectangle:
 * - Address bar and back/forward navigation controls outside the stage rectangle
 * - "Draw / Browse" touch mode toggle
 * - WebView configured securely: file:// blocked, JS-bridges disabled
 * - Main-thread frame capture at 15-20 fps into a single reusable Bitmap (zero per-frame allocations)
 * - Warning that protected / DRM video pages cannot be recorded
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebStageControls(
    urlInput: String,
    onUrlChange: (String) -> Unit,
    onNavigateUrl: (String) -> Unit,
    canGoBack: Boolean,
    onGoBack: () -> Unit,
    canGoForward: Boolean,
    onGoForward: () -> Unit,
    onReload: () -> Unit,
    touchMode: StageTouchMode,
    onTouchModeChange: (StageTouchMode) -> Unit,
    modifier: Modifier = Modifier,
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF14171D))
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("web_stage_controls"),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        // Warning notification banner regarding DRM media
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = Color(0xFFFFB74D),
                modifier = Modifier.size(14.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Note: DRM / protected video streaming sites cannot be captured by the canvas recorder.",
                style = MaterialTheme.typography.bodySmall,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.7f),
            )
        }

        // Navigation Row: Back, Forward, Address Bar, Refresh, and Mode Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            IconButton(
                onClick = onGoBack,
                enabled = canGoBack,
                modifier = Modifier.size(36.dp).testTag("web_back_btn"),
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Web Back",
                    tint = if (canGoBack) Color.White else Color.White.copy(alpha = 0.3f),
                )
            }

            IconButton(
                onClick = onGoForward,
                enabled = canGoForward,
                modifier = Modifier.size(36.dp).testTag("web_forward_btn"),
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Web Forward",
                    tint = if (canGoForward) Color.White else Color.White.copy(alpha = 0.3f),
                )
            }

            IconButton(
                onClick = onReload,
                modifier = Modifier.size(36.dp).testTag("web_reload_btn"),
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reload Page",
                    tint = Color.White,
                )
            }

            // Address bar
            OutlinedTextField(
                value = urlInput,
                onValueChange = onUrlChange,
                singleLine = true,
                placeholder = { Text("https://...", fontSize = 12.sp, color = Color.White.copy(alpha = 0.4f)) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Public,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color.White.copy(alpha = 0.5f),
                    )
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = {
                        keyboardController?.hide()
                        onNavigateUrl(urlInput)
                    }
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("web_url_input"),
                textStyle = MaterialTheme.typography.bodySmall.copy(color = Color.White, fontSize = 12.sp),
            )

            // Touch Mode Chips: "Draw" vs "Browse"
            FilterChip(
                selected = touchMode == StageTouchMode.DRAW,
                onClick = { onTouchModeChange(StageTouchMode.DRAW) },
                label = { Text("Draw", fontSize = 11.sp) },
                leadingIcon = {
                    Icon(Icons.Default.Brush, contentDescription = null, modifier = Modifier.size(14.dp))
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                ),
                modifier = Modifier.testTag("toggle_draw_mode"),
            )

            FilterChip(
                selected = touchMode == StageTouchMode.BROWSE,
                onClick = { onTouchModeChange(StageTouchMode.BROWSE) },
                label = { Text("Browse", fontSize = 11.sp) },
                leadingIcon = {
                    Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(14.dp))
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.secondary,
                    selectedLabelColor = MaterialTheme.colorScheme.onSecondary,
                ),
                modifier = Modifier.testTag("toggle_browse_mode"),
            )
        }
    }
}

/**
 * Embedded secure WebView inside the stage rectangle with continuous frame capture
 * at 15-20 fps into [onFrameCaptured].
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebStageView(
    url: String,
    onWebViewCreated: (WebView) -> Unit,
    onFrameCaptured: (Bitmap) -> Unit,
    modifier: Modifier = Modifier,
) {
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    // Reusable single Bitmap to prevent GC thrashing and allocation per frame
    var reusableBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var reusableCanvas by remember { mutableStateOf<Canvas?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            reusableBitmap?.recycle()
            reusableBitmap = null
            reusableCanvas = null
            webViewRef?.destroy()
        }
    }

    // 15-20 fps frame capture loop on Main Thread
    LaunchedEffect(webViewRef) {
        val wv = webViewRef ?: return@LaunchedEffect
        while (isActive) {
            delay(55) // ~18 fps capture rate
            val w = wv.width
            val h = wv.height
            if (w > 0 && h > 0) {
                if (reusableBitmap == null || reusableBitmap?.width != w || reusableBitmap?.height != h) {
                    reusableBitmap?.recycle()
                    val newBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    reusableBitmap = newBmp
                    reusableCanvas = Canvas(newBmp)
                }

                val targetCanvas = reusableCanvas
                val targetBmp = reusableBitmap
                if (targetCanvas != null && targetBmp != null && !targetBmp.isRecycled) {
                    try {
                        wv.draw(targetCanvas)
                        onFrameCaptured(targetBmp)
                    } catch (_: Throwable) {}
                }
            }
        }
    }

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val requestUrl = request?.url?.toString() ?: ""
                        // Security: strictly block file:// and content:// access
                        if (requestUrl.startsWith("file:", ignoreCase = true) ||
                            requestUrl.startsWith("content:", ignoreCase = true)) {
                            return true
                        }
                        return false
                    }
                }

                settings.apply {
                    javaScriptEnabled = true
                    // Security restrictions: Block local file access and bridge interfaces
                    allowFileAccess = false
                    allowContentAccess = false
                    allowFileAccessFromFileURLs = false
                    allowUniversalAccessFromFileURLs = false
                    javaScriptCanOpenWindowsAutomatically = false
                    domStorageEnabled = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                }

                removeJavascriptInterface("accessibility")
                removeJavascriptInterface("accessibilityTraversal")

                loadUrl(url)
                webViewRef = this
                onWebViewCreated(this)
            }
        },
        modifier = modifier.fillMaxSize().testTag("web_stage_view"),
    )
}
