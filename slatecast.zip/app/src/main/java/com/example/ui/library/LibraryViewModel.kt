package com.example.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.storage.VideoItem
import com.example.data.storage.VideoStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LibraryViewModel(
    private val videoStore: VideoStore,
) : ViewModel() {

    private val _videos = MutableStateFlow<List<VideoItem>>(emptyList())
    val videos: StateFlow<List<VideoItem>> = _videos.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _selectedVideo = MutableStateFlow<VideoItem?>(null)
    val selectedVideo: StateFlow<VideoItem?> = _selectedVideo.asStateFlow()

    init {
        loadVideos()
    }

    fun loadVideos() {
        viewModelScope.launch {
            _isLoading.value = true
            val list = videoStore.listVideos()
            _videos.value = list
            _isLoading.value = false
        }
    }

    fun selectVideo(video: VideoItem?) {
        _selectedVideo.value = video
    }

    fun renameVideo(video: VideoItem, newNameWithoutExt: String) {
        viewModelScope.launch {
            val success = videoStore.renameVideo(video, newNameWithoutExt)
            if (success) {
                loadVideos()
            }
        }
    }

    fun deleteVideo(video: VideoItem) {
        viewModelScope.launch {
            val success = videoStore.deleteVideo(video)
            if (success) {
                if (_selectedVideo.value?.id == video.id) {
                    _selectedVideo.value = null
                }
                loadVideos()
            }
        }
    }
}
