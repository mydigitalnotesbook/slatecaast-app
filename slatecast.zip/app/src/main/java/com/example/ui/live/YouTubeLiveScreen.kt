package com.example.ui.live

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.settings.LiveBitrate
import com.example.data.settings.LiveQuality
import com.example.data.settings.LiveStreamConfig
import com.example.data.settings.LiveStreamConfigStore
import com.example.recorder.engine.RtmpSink

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YouTubeLiveScreen(
    onNavigateBack: () -> Unit,
    onStartLive: (LiveStreamConfig) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val configStore = remember { LiveStreamConfigStore(context) }
    var config by remember { mutableStateOf(configStore.loadConfig()) }

    var isKeyVisible by remember { mutableStateOf(false) }
    var urlError by remember { mutableStateOf<String?>(null) }
    var keyError by remember { mutableStateOf<String?>(null) }

    // Handshake check state
    var isCheckingConnection by remember { mutableStateOf(false) }
    var connectionCheckResult by remember { mutableStateOf<Pair<Boolean, String>?>(null) }

    // Connectivity info
    val isCellular = remember { isMobileDataActive(context) }
    val isInternetAvailable = remember { isNetworkOnline(context) }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("youtube_live_screen"),
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.live_title)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("live_back_btn")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.btn_back),
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                ),
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            // 1. YouTube Live Help Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().testTag("live_help_card"),
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp),
                    )
                    Text(
                        text = stringResource(R.string.live_help_text),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
            }

            // 2. Stream URL Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    OutlinedTextField(
                        value = config.streamUrl,
                        onValueChange = {
                            config = config.copy(streamUrl = it)
                            urlError = null
                        },
                        label = { Text(stringResource(R.string.live_stream_url_label)) },
                        singleLine = true,
                        isError = urlError != null,
                        supportingText = urlError?.let { { Text(it, color = MaterialTheme.colorScheme.error) } },
                        modifier = Modifier.fillMaxWidth().testTag("live_url_input"),
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.live_use_rtmps),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                        Switch(
                            checked = config.useSecureRtmps,
                            onCheckedChange = { useSecure ->
                                val newUrl = if (useSecure) {
                                    LiveStreamConfig.DEFAULT_RTMPS_URL
                                } else {
                                    LiveStreamConfig.DEFAULT_RTMP_URL
                                }
                                config = config.copy(useSecureRtmps = useSecure, streamUrl = newUrl)
                                urlError = null
                            },
                            modifier = Modifier.testTag("live_rtmps_switch"),
                        )
                    }
                }
            }

            // 3. Stream Key Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    OutlinedTextField(
                        value = config.streamKey,
                        onValueChange = {
                            config = config.copy(streamKey = it)
                            keyError = null
                        },
                        label = { Text(stringResource(R.string.live_stream_key_label)) },
                        singleLine = true,
                        isError = keyError != null,
                        visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { isKeyVisible = !isKeyVisible }) {
                                    Icon(
                                        imageVector = if (isKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (isKeyVisible) "Hide key" else "Show key",
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                        val clip = clipboard?.primaryClip
                                        if (clip != null && clip.itemCount > 0) {
                                            val text = clip.getItemAt(0).text?.toString() ?: ""
                                            if (text.isNotBlank()) {
                                                config = config.copy(streamKey = text.trim())
                                                keyError = null
                                            }
                                        }
                                    },
                                    modifier = Modifier.testTag("live_paste_key_btn"),
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentPaste,
                                        contentDescription = stringResource(R.string.live_paste_key),
                                    )
                                }
                            }
                        },
                        supportingText = keyError?.let { { Text(it, color = MaterialTheme.colorScheme.error) } },
                        modifier = Modifier.fillMaxWidth().testTag("live_key_input"),
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = stringResource(R.string.live_save_key_on_device),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Switch(
                            checked = config.saveKeyOnDevice,
                            onCheckedChange = { config = config.copy(saveKeyOnDevice = it) },
                            modifier = Modifier.testTag("live_save_key_switch"),
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = stringResource(R.string.live_save_local_copy),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Switch(
                            checked = config.alsoSaveLocalCopy,
                            onCheckedChange = { config = config.copy(alsoSaveLocalCopy = it) },
                            modifier = Modifier.testTag("live_local_copy_switch"),
                        )
                    }
                }
            }

            // 4. Quality & Bitrate Settings
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Text(
                        text = stringResource(R.string.live_quality_label),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        LiveQuality.entries.forEach { q ->
                            FilterChip(
                                selected = config.quality == q,
                                onClick = { config = config.copy(quality = q) },
                                label = { Text(q.label) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(),
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = stringResource(R.string.live_bitrate_label),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            listOf(LiveBitrate.MBPS_1_5, LiveBitrate.MBPS_2_5).forEach { b ->
                                FilterChip(
                                    selected = config.bitrate == b,
                                    onClick = { config = config.copy(bitrate = b) },
                                    label = { Text(b.label) },
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            listOf(LiveBitrate.MBPS_4_0, LiveBitrate.MBPS_6_0).forEach { b ->
                                FilterChip(
                                    selected = config.bitrate == b,
                                    onClick = { config = config.copy(bitrate = b) },
                                    label = { Text(b.label) },
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                    }
                }
            }

            // 5. Mobile Data & Copyright Warnings
            if (isCellular) {
                val dataFormatted = String.format("%.1f GB", config.expectedDataUsePerHourGb)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.6f),
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary,
                        )
                        Text(
                            text = stringResource(R.string.live_data_warning, dataFormatted),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                        )
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(18.dp),
                    )
                    Text(
                        text = stringResource(R.string.live_copyright_warning),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Connection Check Status
            connectionCheckResult?.let { (success, message) ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (success) Color(0xFF1E3A24) else Color(0xFF3B1E1E),
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = if (success) Icons.Default.CheckCircle else Icons.Default.Error,
                            contentDescription = null,
                            tint = if (success) Color(0xFF4CAF50) else Color(0xFFE57373),
                        )
                        Text(
                            text = message,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White,
                        )
                    }
                }
            }

            // 6. Action Buttons: Check Connection & Go Live
            OutlinedButton(
                onClick = {
                    val cleanUrl = config.streamUrl.trim()
                    val cleanKey = config.streamKey.trim()
                    if (!cleanUrl.startsWith("rtmp://") && !cleanUrl.startsWith("rtmps://")) {
                        urlError = context.getString(R.string.live_invalid_url)
                        return@OutlinedButton
                    }
                    if (cleanKey.isEmpty() || cleanKey.contains(" ")) {
                        keyError = context.getString(R.string.live_invalid_key)
                        return@OutlinedButton
                    }
                    isCheckingConnection = true
                    connectionCheckResult = null
                    RtmpSink.checkConnection(cleanUrl, cleanKey) { success, msg ->
                        isCheckingConnection = false
                        connectionCheckResult = Pair(success, msg)
                    }
                },
                enabled = !isCheckingConnection,
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("live_check_connection_btn"),
            ) {
                if (isCheckingConnection) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(stringResource(R.string.live_checking_connection))
                } else {
                    Icon(imageVector = Icons.Default.NetworkCheck, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(stringResource(R.string.live_check_connection))
                }
            }

            Button(
                onClick = {
                    val cleanUrl = config.streamUrl.trim()
                    val cleanKey = config.streamKey.trim()

                    var hasError = false
                    if (!cleanUrl.startsWith("rtmp://") && !cleanUrl.startsWith("rtmps://")) {
                        urlError = context.getString(R.string.live_invalid_url)
                        hasError = true
                    }
                    if (cleanKey.isEmpty() || cleanKey.contains(" ")) {
                        keyError = context.getString(R.string.live_invalid_key)
                        hasError = true
                    }
                    if (hasError) return@Button

                    if (!isInternetAvailable) {
                        connectionCheckResult = Pair(false, context.getString(R.string.live_no_internet))
                        return@Button
                    }

                    // Save settings encrypted
                    configStore.saveConfig(config)
                    onStartLive(config)
                },
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("live_start_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFE50914), // Red live color
                    contentColor = Color.White,
                ),
                shape = RoundedCornerShape(14.dp),
            ) {
                Icon(imageVector = Icons.Default.Videocam, contentDescription = null)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.live_start_streaming),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

private fun isMobileDataActive(context: Context): Boolean {
    return try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
    } catch (_: Throwable) {
        false
    }
}

private fun isNetworkOnline(context: Context): Boolean {
    return try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Throwable) {
        true
    }
}
