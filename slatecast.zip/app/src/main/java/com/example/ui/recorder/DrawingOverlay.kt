package com.example.ui.recorder

import android.graphics.PointF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import com.example.recorder.canvas.DrawingState
import com.example.recorder.canvas.Stroke
import com.example.recorder.canvas.StrokeRenderer
import com.example.recorder.canvas.Tool

/**
 * Overlay composable placed inside the Stage rectangle.
 * Receives touch only inside the stage bounds and normalizes points (0..1).
 * Supports stylus pressure if available, scaling width accordingly.
 */
@Composable
fun DrawingOverlay(
    slideIndex: Int,
    drawingState: DrawingState,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    // Collect state triggers to redraw when strokes change
    val strokesVersion by drawingState.strokesVersion.collectAsState()
    val currentTool by drawingState.currentTool.collectAsState()
    val currentColor by drawingState.currentColor.collectAsState()
    val currentWidthNorm by drawingState.widthNorm.collectAsState()

    // Transient in-progress stroke points
    val livePoints = remember { mutableStateListOf<PointF>() }
    var liveWidthNorm by remember { mutableStateOf(currentWidthNorm) }

    val pointerModifier = if (enabled) {
        Modifier.pointerInput(slideIndex, currentTool, currentColor, currentWidthNorm) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val stageW = size.width.toFloat()
                val stageH = size.height.toFloat()

                if (stageW <= 0f || stageH <= 0f) return@awaitEachGesture

                val startX = (down.position.x / stageW).coerceIn(0f, 1f)
                val startY = (down.position.y / stageH).coerceIn(0f, 1f)

                // Stylus pressure handling: if pressure is reported and > 0, adjust width proportionally
                val pressureFactor = if (down.type == PointerType.Stylus && down.pressure > 0.05f) {
                    (down.pressure * 1.5f).coerceIn(0.5f, 2.0f)
                } else {
                    1.0f
                }
                val effectiveWidth = currentWidthNorm * pressureFactor

                if (currentTool == Tool.ERASER) {
                    // Stroke eraser: remove strokes touched
                    drawingState.eraseStrokesAt(slideIndex, startX, startY)
                } else {
                    livePoints.clear()
                    livePoints.add(PointF(startX, startY))
                    liveWidthNorm = effectiveWidth
                }

                do {
                    val event = awaitPointerEvent()
                    val change = event.changes.firstOrNull { it.id == down.id } ?: break

                    if (change.pressed) {
                        val currX = (change.position.x / stageW).coerceIn(0f, 1f)
                        val currY = (change.position.y / stageH).coerceIn(0f, 1f)

                        if (currentTool == Tool.ERASER) {
                            drawingState.eraseStrokesAt(slideIndex, currX, currY)
                        } else {
                            val lastPt = livePoints.lastOrNull()
                            if (lastPt == null || kotlin.math.hypot(currX - lastPt.x, currY - lastPt.y) > 0.002f) {
                                livePoints.add(PointF(currX, currY))
                            }
                        }
                        change.consume()
                    }
                } while (event.changes.any { it.pressed })

                // Gesture finished: commit stroke if tool is pen or highlighter
                if (currentTool != Tool.ERASER && livePoints.isNotEmpty()) {
                    val stroke = Stroke(
                        tool = currentTool,
                        colorArgb = currentColor.argb,
                        widthNorm = liveWidthNorm,
                        points = livePoints.toList(),
                    )
                    drawingState.addStroke(slideIndex, stroke)
                    livePoints.clear()
                }
            }
        }
    } else {
        Modifier
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .testTag("drawing_overlay_canvas")
            .then(pointerModifier)
    ) {
        // Access strokesVersion to ensure recomposition on undo/redo/clear
        val currentVersion = strokesVersion
        val width = size.width.toInt()
        val height = size.height.toInt()
        if (width <= 0 || height <= 0) return@Canvas

        val committedStrokes = drawingState.getStrokesForSlide(slideIndex)

        // Draw committed strokes using StrokeRenderer
        StrokeRenderer.drawStrokes(
            canvas = drawContext.canvas.nativeCanvas,
            strokes = committedStrokes,
            width = width,
            height = height,
        )

        // Draw transient in-progress stroke if drawing
        if (livePoints.isNotEmpty()) {
            val liveStroke = Stroke(
                tool = currentTool,
                colorArgb = currentColor.argb,
                widthNorm = liveWidthNorm,
                points = livePoints.toList(),
            )
            StrokeRenderer.drawStrokes(
                canvas = drawContext.canvas.nativeCanvas,
                strokes = listOf(liveStroke),
                width = width,
                height = height,
            )
        }
    }
}
