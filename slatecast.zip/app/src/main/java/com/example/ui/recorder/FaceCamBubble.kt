package com.example.ui.recorder

import android.Manifest
import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.recorder.engine.FaceCamSize
import com.example.recorder.engine.FaceCamSource
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.roundToInt

/**
 * Step 18: FaceCamBubble
 *
 * Draggable circular front camera preview inside the stage.
 * Captures frames continuously into [faceCamSource] for recording compositing.
 */
@Composable
fun FaceCamBubble(
    faceCamSource: FaceCamSource,
    stageWidthPx: Float,
    stageHeightPx: Float,
    onCameraFailure: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val sizeOption by faceCamSource.size.collectAsStateWithLifecycle()
    val diameterDp = sizeOption.dpSize.dp

    var previewViewRef by remember { mutableStateOf<PreviewView?>(null) }
    var cameraProviderRef by remember { mutableStateOf<ProcessCameraProvider?>(null) }

    // Position tracking in pixel offsets
    var offsetX by remember { mutableFloatStateOf(stageWidthPx * 0.75f) }
    var offsetY by remember { mutableFloatStateOf(stageHeightPx * 0.75f) }

    // Frame capture loop for encoder compositing
    LaunchedEffect(previewViewRef) {
        val pv = previewViewRef ?: return@LaunchedEffect
        while (isActive) {
            delay(66) // ~15 fps compositing
            try {
                val bmp = pv.bitmap
                if (bmp != null) {
                    faceCamSource.updateFrame(bmp)
                }
            } catch (_: Throwable) {}
        }
    }

    DisposableEffect(lifecycleOwner) {
        onDispose {
            try {
                cameraProviderRef?.unbindAll()
            } catch (_: Throwable) {}
        }
    }

    Box(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .size(diameterDp)
            .clip(CircleShape)
            .background(Color.DarkGray)
            .border(2.dp, Color.White, CircleShape)
            .pointerInput(stageWidthPx, stageHeightPx) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    val newX = (offsetX + dragAmount.x).coerceIn(0f, stageWidthPx - diameterDp.toPx())
                    val newY = (offsetY + dragAmount.y).coerceIn(0f, stageHeightPx - diameterDp.toPx())
                    offsetX = newX
                    offsetY = newY

                    // Update normalized center for StageRenderer
                    val cxNorm = (newX + diameterDp.toPx() / 2f) / stageWidthPx.coerceAtLeast(1f)
                    val cyNorm = (newY + diameterDp.toPx() / 2f) / stageHeightPx.coerceAtLeast(1f)
                    faceCamSource.updatePosition(cxNorm, cyNorm)
                }
            }
            .testTag("face_cam_bubble"),
        contentAlignment = Alignment.Center,
    ) {
        AndroidView(
            factory = { ctx ->
                PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE

                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        try {
                            val cameraProvider = cameraProviderFuture.get()
                            cameraProviderRef = cameraProvider
                            val preview = Preview.Builder().build().also {
                                it.surfaceProvider = this.surfaceProvider
                            }

                            val cameraSelector = if (cameraProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)) {
                                CameraSelector.DEFAULT_FRONT_CAMERA
                            } else if (cameraProvider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)) {
                                CameraSelector.DEFAULT_BACK_CAMERA
                            } else {
                                null
                            }

                            if (cameraSelector != null) {
                                cameraProvider.unbindAll()
                                cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, preview)
                            } else {
                                onCameraFailure("No camera found on this device")
                            }
                        } catch (e: Throwable) {
                            Log.w("RecorderEngine", "Front camera initialization failed: ${e.message}")
                            onCameraFailure("Front camera unavailable: ${e.message}")
                        }
                    }, ContextCompat.getMainExecutor(ctx))

                    previewViewRef = this
                }
            },
            modifier = Modifier.fillMaxSize(),
        )

        // Close bubble button (small top-right corner)
        IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(24.dp)
                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                .testTag("face_cam_close_btn"),
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close Face Cam",
                tint = Color.White,
                modifier = Modifier.size(16.dp),
            )
        }

        // Size toggle button (Small / Medium)
        androidx.compose.foundation.layout.Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(6.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.65f))
                .clickable {
                    val next = if (sizeOption == FaceCamSize.SMALL) FaceCamSize.MEDIUM else FaceCamSize.SMALL
                    faceCamSource.setSize(next)
                }
                .padding(horizontal = 6.dp, vertical = 2.dp)
                .testTag("face_cam_size_toggle"),
        ) {
            Text(
                text = if (sizeOption == FaceCamSize.SMALL) "S" else "M",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
fun CameraPermissionRationaleDialog(
    onGrantRequested: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Camera Permission") },
        text = {
            Text("Teaching Recorder uses the front camera to show your face bubble on slides while teaching. No video or images are stored online.")
        },
        confirmButton = {
            Button(
                onClick = onGrantRequested,
                modifier = Modifier.testTag("camera_grant_btn"),
            ) {
                Text("Allow Camera")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("camera_cancel_btn"),
            ) {
                Text("Cancel")
            }
        },
        modifier = Modifier.testTag("camera_rationale_dialog"),
    )
}
