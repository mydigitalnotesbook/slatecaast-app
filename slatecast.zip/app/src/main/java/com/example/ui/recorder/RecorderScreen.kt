package com.example.ui.recorder

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

/**
 * Recorder UI controls and overlay components.
 * TODO(step 4): Floating control overlay for pause/resume, mic mute, slide navigation, and pen selector.
 */
@Composable
fun RecorderControlsPlaceholder(
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        Text("Recorder Controls (Step 4)")
    }
}
