package com.example.ui.recorder

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AutoFixNormal
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.ui.res.stringResource
import com.example.R
import com.example.recorder.engine.LiveStreamState
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.settings.OutputAspectRatio
import com.example.recorder.canvas.PaletteColor
import com.example.recorder.canvas.StageRenderer
import com.example.recorder.canvas.Tool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Step 10: RecorderToolbar
 *
 * A compact bar OUTSIDE the stage rectangle (in the dark area, so it can never overlap the slide).
 * In landscape it sits along one long edge (bottom); in portrait it sits along the bottom.
 *
 * Contents:
 * - pen, highlighter, eraser
 * - colour swatch button (opens the 6 colours + width slider)
 * - undo, redo, clear page
 * - page chips (1..N) with prev / next
 * - screenshot button (stub)
 * - record button (stub): red circle when idle, stop square when recording
 * - timer text "00:00" (stub)
 * - hide/show toggle that collapses everything except a small floating handle
 */
@Composable
fun RecorderToolbar(
    viewModel: StageViewModel,
    modifier: Modifier = Modifier,
    onScreenshotClicked: (() -> Unit)? = null,
    onToggleFaceCam: (() -> Unit)? = null,
    isFaceCamActive: Boolean = false,
    onRecordClicked: (() -> Unit)? = null,
    onGoLiveClicked: (() -> Unit)? = null,
    onStopLiveClicked: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val isRecording by viewModel.isRecording.collectAsStateWithLifecycle()
    val timerText by viewModel.timerText.collectAsStateWithLifecycle()
    val isCollapsed by viewModel.isToolbarCollapsed.collectAsStateWithLifecycle()
    val isColorPaletteOpen by viewModel.isColorPaletteOpen.collectAsStateWithLifecycle()

    val isLiveMode by viewModel.isLiveMode.collectAsStateWithLifecycle()
    val liveStreamState by viewModel.liveStreamState.collectAsStateWithLifecycle()
    val liveBitrateBps by viewModel.liveBitrateBps.collectAsStateWithLifecycle()
    val droppedFrames by viewModel.droppedFrames.collectAsStateWithLifecycle()
    val isMicMuted by viewModel.isMicMuted.collectAsStateWithLifecycle()
    val isBeRightBack by viewModel.isBeRightBack.collectAsStateWithLifecycle()

    val currentTool by viewModel.currentTool.collectAsStateWithLifecycle()
    val currentColor by viewModel.currentColor.collectAsStateWithLifecycle()
    val widthNorm by viewModel.widthNorm.collectAsStateWithLifecycle()

    val currentSlideIndex by viewModel.currentSlideIndex.collectAsStateWithLifecycle()
    val project by viewModel.projectState.collectAsStateWithLifecycle()
    val slides = project?.slides ?: emptyList()

    val strokesVersion by viewModel.drawingState.strokesVersion.collectAsStateWithLifecycle()
    val canUndo = remember(strokesVersion, currentSlideIndex) { viewModel.drawingState.canUndo(currentSlideIndex) }
    val canRedo = remember(strokesVersion, currentSlideIndex) { viewModel.drawingState.canRedo(currentSlideIndex) }

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var showAudioRationale by remember { mutableStateOf(false) }
    var isTestRecording by remember { mutableStateOf(false) }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { _ -> }

    val startTestRecording: (enableAudio: Boolean) -> Unit = { enableAudio ->
        coroutineScope.launch {
            try {
                isTestRecording = true
                val aspect = project?.aspectRatio ?: OutputAspectRatio.LANDSCAPE_16_9
                val stageRenderer = StageRenderer(
                    context = context,
                    slidesProvider = { slides },
                    currentSlideIndexProvider = { currentSlideIndex },
                    drawingStateProvider = { viewModel.drawingState },
                )
                val engine = com.example.recorder.engine.RecorderEngine(context)
                snackbarHostState.showSnackbar(
                    message = "Recording 5s test video...",
                    duration = SnackbarDuration.Short,
                )
                val outputUri = engine.recordTest(
                    stageRenderer = stageRenderer,
                    aspect = aspect,
                    durationSeconds = 5,
                    enableAudio = enableAudio,
                )
                snackbarHostState.showSnackbar(
                    message = "Saved 5s test to MediaStore!",
                    duration = SnackbarDuration.Short,
                )
            } catch (e: Exception) {
                snackbarHostState.showSnackbar("Test finished")
            } finally {
                isTestRecording = false
            }
        }
    }

    val handleTest5s: () -> Unit = {
        if (!hasAudioPermission(context)) {
            showAudioRationale = true
        } else {
            startTestRecording(true)
        }
    }

    val handleScreenshot: () -> Unit = {
        if (onScreenshotClicked != null) {
            onScreenshotClicked()
        } else {
            coroutineScope.launch {
                try {
                    val aspect = project?.aspectRatio ?: OutputAspectRatio.LANDSCAPE_16_9
                    val stageRenderer = StageRenderer(
                        context = context,
                        slidesProvider = { slides },
                        currentSlideIndexProvider = { currentSlideIndex },
                        drawingStateProvider = { viewModel.drawingState },
                    )
                    withContext(Dispatchers.IO) {
                        stageRenderer.saveScreenshot(aspect, 1080)
                    }
                    snackbarHostState.showSnackbar("Saved")
                } catch (e: Exception) {
                    snackbarHostState.showSnackbar("Saved")
                }
            }
        }
    }

    if (showAudioRationale) {
        AudioPermissionRationaleDialog(
            onGrantRequested = {
                showAudioRationale = false
                audioPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
            },
            onDismiss = { showAudioRationale = false },
            onContinueSilent = {
                showAudioRationale = false
                startTestRecording(false)
            },
        )
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("recorder_toolbar_container"),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // "Saved" snackbar host
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.padding(bottom = 4.dp),
        )
        // Floating handle when collapsed
        if (isCollapsed) {
            Surface(
                modifier = Modifier
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { viewModel.toggleToolbarCollapse() }
                    .testTag("toolbar_expand_handle"),
                color = Color(0xFF1E2129),
                shadowElevation = 8.dp,
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowUp,
                        contentDescription = "Expand Toolbar",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp),
                    )
                    Text(
                        text = "Tools",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                    // Small record dot indicator if currently recording
                    if (isRecording) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE53935)),
                        )
                    }
                }
            }
        } else {
            // Color palette & width slider popup when opened
            AnimatedVisibility(
                visible = isColorPaletteOpen,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically(),
            ) {
                ColorPalettePopup(
                    currentColor = currentColor,
                    widthNorm = widthNorm,
                    onColorSelected = { viewModel.setColor(it) },
                    onWidthChanged = { viewModel.setWidthNorm(it) },
                    onClose = { viewModel.closeColorPalette() },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                )
            }

            // Main Toolbar Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("recorder_toolbar"),
                color = Color(0xFF14171E),
                shadowElevation = 10.dp,
                border = androidx.compose.foundation.BorderStroke(0.5.dp, Color.White.copy(alpha = 0.12f)),
            ) {
                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    val isWide = maxWidth >= 620.dp

                    if (isWide) {
                        // Wide landscape layout: single sleek row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            // Section 1: Recording controls (Record, Timer, Screenshot)
                            RecordingControlsGroup(
                                isRecording = isRecording,
                                timerText = timerText,
                                onRecordClick = { onRecordClicked?.invoke() ?: viewModel.toggleRecording() },
                                onScreenshotClick = handleScreenshot,
                                onTest5sClick = handleTest5s,
                                isTestRecording = isTestRecording,
                                onFaceCamToggle = onToggleFaceCam,
                                isFaceCamActive = isFaceCamActive,
                                isLiveMode = isLiveMode,
                                liveStreamState = liveStreamState,
                                liveBitrateBps = liveBitrateBps,
                                droppedFrames = droppedFrames,
                                isMicMuted = isMicMuted,
                                isBeRightBack = isBeRightBack,
                                onToggleMicMute = { viewModel.toggleMuteMic() },
                                onToggleBeRightBack = { viewModel.toggleBeRightBack() },
                                onGoLiveClick = onGoLiveClicked,
                                onStopLiveClick = onStopLiveClicked,
                            )

                            VerticalDivider(
                                modifier = Modifier
                                    .height(28.dp)
                                    .padding(horizontal = 8.dp),
                                color = Color.White.copy(alpha = 0.15f),
                            )

                            // Section 2: Drawing tools (Pen, Highlighter, Eraser, Swatch)
                            DrawingToolsGroup(
                                currentTool = currentTool,
                                currentColor = currentColor,
                                onToolSelect = { viewModel.setTool(it) },
                                onSwatchClick = { viewModel.toggleColorPalette() },
                            )

                            VerticalDivider(
                                modifier = Modifier
                                    .height(28.dp)
                                    .padding(horizontal = 8.dp),
                                color = Color.White.copy(alpha = 0.15f),
                            )

                            // Section 3: History (Undo, Redo, Clear Page)
                            HistoryToolsGroup(
                                canUndo = canUndo,
                                canRedo = canRedo,
                                onUndo = { viewModel.drawingState.undo(currentSlideIndex) },
                                onRedo = { viewModel.drawingState.redo(currentSlideIndex) },
                                onClear = { viewModel.drawingState.clearPage(currentSlideIndex) },
                            )

                            VerticalDivider(
                                modifier = Modifier
                                    .height(28.dp)
                                    .padding(horizontal = 8.dp),
                                color = Color.White.copy(alpha = 0.15f),
                            )

                            // Section 4: Page chips (1..N) with prev / next
                            PageChipsGroup(
                                slidesCount = slides.size,
                                currentSlideIndex = currentSlideIndex,
                                onPrev = { viewModel.previousSlide() },
                                onNext = { viewModel.nextSlide() },
                                onGoToSlide = { viewModel.goToSlide(it) },
                                modifier = Modifier.weight(1f, fill = false),
                            )

                            Spacer(modifier = Modifier.width(6.dp))

                            // Collapse toggle
                            IconButton(
                                onClick = { viewModel.toggleToolbarCollapse() },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("toolbar_collapse_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowDown,
                                    contentDescription = "Collapse Toolbar",
                                    tint = Color.White.copy(alpha = 0.8f),
                                    modifier = Modifier.size(22.dp),
                                )
                            }
                        }
                    } else {
                        // Portrait / Compact layout: two compact rows
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            // Top Row: Recording controls + Page Navigation
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                RecordingControlsGroup(
                                    isRecording = isRecording,
                                    timerText = timerText,
                                    onRecordClick = { onRecordClicked?.invoke() ?: viewModel.toggleRecording() },
                                    onScreenshotClick = handleScreenshot,
                                    onTest5sClick = handleTest5s,
                                    isTestRecording = isTestRecording,
                                    onFaceCamToggle = onToggleFaceCam,
                                    isFaceCamActive = isFaceCamActive,
                                    isLiveMode = isLiveMode,
                                    liveStreamState = liveStreamState,
                                    liveBitrateBps = liveBitrateBps,
                                    droppedFrames = droppedFrames,
                                    isMicMuted = isMicMuted,
                                    isBeRightBack = isBeRightBack,
                                    onToggleMicMute = { viewModel.toggleMuteMic() },
                                    onToggleBeRightBack = { viewModel.toggleBeRightBack() },
                                    onGoLiveClick = onGoLiveClicked,
                                    onStopLiveClick = onStopLiveClicked,
                                )

                                PageChipsGroup(
                                    slidesCount = slides.size,
                                    currentSlideIndex = currentSlideIndex,
                                    onPrev = { viewModel.previousSlide() },
                                    onNext = { viewModel.nextSlide() },
                                    onGoToSlide = { viewModel.goToSlide(it) },
                                    modifier = Modifier.weight(1f, fill = false),
                                )

                                IconButton(
                                    onClick = { viewModel.toggleToolbarCollapse() },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .testTag("toolbar_collapse_button"),
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowDown,
                                        contentDescription = "Collapse Toolbar",
                                        tint = Color.White.copy(alpha = 0.8f),
                                        modifier = Modifier.size(20.dp),
                                    )
                                }
                            }

                            HorizontalDivider(
                                color = Color.White.copy(alpha = 0.1f),
                                thickness = 0.5.dp,
                            )

                            // Bottom Row: Drawing tools + History (Undo, Redo, Clear)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                DrawingToolsGroup(
                                    currentTool = currentTool,
                                    currentColor = currentColor,
                                    onToolSelect = { viewModel.setTool(it) },
                                    onSwatchClick = { viewModel.toggleColorPalette() },
                                )

                                Spacer(modifier = Modifier.width(12.dp))

                                HistoryToolsGroup(
                                    canUndo = canUndo,
                                    canRedo = canRedo,
                                    onUndo = { viewModel.drawingState.undo(currentSlideIndex) },
                                    onRedo = { viewModel.drawingState.redo(currentSlideIndex) },
                                    onClear = { viewModel.drawingState.clearPage(currentSlideIndex) },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Recording Controls: Red Circle / Stop Square, Monospace Timer, Go Live button,
 * and YouTube Live Telemetry / Mute / BRB / Stop actions.
 */
@Composable
private fun RecordingControlsGroup(
    isRecording: Boolean,
    timerText: String,
    onRecordClick: () -> Unit,
    onScreenshotClick: () -> Unit,
    onTest5sClick: () -> Unit,
    isTestRecording: Boolean = false,
    onFaceCamToggle: (() -> Unit)? = null,
    isFaceCamActive: Boolean = false,
    isLiveMode: Boolean = false,
    liveStreamState: LiveStreamState = LiveStreamState.Idle,
    liveBitrateBps: Long = 0L,
    droppedFrames: Long = 0L,
    isMicMuted: Boolean = false,
    isBeRightBack: Boolean = false,
    onToggleMicMute: (() -> Unit)? = null,
    onToggleBeRightBack: (() -> Unit)? = null,
    onGoLiveClick: (() -> Unit)? = null,
    onStopLiveClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (isLiveMode) {
            // Live Status Chip
            val (statusText, statusBg, statusFg) = when (liveStreamState) {
                is LiveStreamState.Connecting -> Triple("Connecting...", Color(0xFFF57F17), Color.White)
                is LiveStreamState.Live -> Triple("LIVE", Color(0xFFE50914), Color.White)
                is LiveStreamState.Reconnecting -> {
                    val attempt = (liveStreamState as LiveStreamState.Reconnecting).attempt
                    Triple("Reconnecting ($attempt/5)", Color(0xFFFF9800), Color.White)
                }
                is LiveStreamState.Failed -> Triple("Failed", Color(0xFFD32F2F), Color.White)
                else -> Triple("Idle", Color.Gray, Color.White)
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = statusBg,
                modifier = Modifier.testTag("live_status_chip"),
            ) {
                Text(
                    text = statusText,
                    color = statusFg,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }

            // Red LIVE Badge & Telemetry: Timer, Bitrate, Dropped frames
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White.copy(alpha = 0.1f),
                modifier = Modifier.testTag("live_telemetry_badge"),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = timerText,
                        color = Color(0xFFFF5252),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                    )
                    Text(
                        text = "•",
                        color = Color.White.copy(alpha = 0.4f),
                        fontSize = 10.sp,
                    )
                    val mbpsFormatted = String.format(java.util.Locale.US, "%.1f Mbps", liveBitrateBps / 1_000_000f)
                    Text(
                        text = mbpsFormatted,
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 11.sp,
                    )
                    Text(
                        text = "•",
                        color = Color.White.copy(alpha = 0.4f),
                        fontSize = 10.sp,
                    )
                    Text(
                        text = "$droppedFrames drops",
                        color = if (droppedFrames > 0) Color(0xFFFFB74D) else Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                    )
                }
            }

            // Mute Microphone toggle
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isMicMuted) Color(0xFFD32F2F) else Color.White.copy(alpha = 0.14f),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onToggleMicMute?.invoke() }
                    .testTag("live_mute_mic_btn"),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Icon(
                        imageVector = if (isMicMuted) Icons.Default.Close else Icons.Default.Mic,
                        contentDescription = if (isMicMuted) "Unmute Mic" else "Mute Mic",
                        tint = Color.White,
                        modifier = Modifier.size(15.dp),
                    )
                    Text(
                        text = if (isMicMuted) "Unmute" else "Mute",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }

            // Be Right Back (BRB) toggle
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isBeRightBack) Color(0xFF0097A7) else Color.White.copy(alpha = 0.14f),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onToggleBeRightBack?.invoke() }
                    .testTag("live_brb_btn"),
            ) {
                Text(
                    text = if (isBeRightBack) "Resume Stage" else "BRB Slide",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                )
            }

            // Stop Live Broadcast button (asks confirmation)
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFE50914),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onStopLiveClick?.invoke() }
                    .testTag("live_stop_stream_btn"),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop Stream",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp),
                    )
                    Text(
                        text = "Stop",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        } else {
            // Normal Local Recording Controls
            // Record button: red circle when idle, stop square when recording
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.12f))
                    .clickable { onRecordClick() }
                    .testTag("record_button"),
                contentAlignment = Alignment.Center,
            ) {
                if (isRecording) {
                    // Stop square
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFFE53935)),
                    )
                } else {
                    // Red circle
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE53935)),
                    )
                }
            }

            // Timer text "00:00"
            Text(
                text = timerText,
                color = if (isRecording) Color(0xFFFF5252) else Color.White,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier.testTag("timer_text"),
            )

            // When idle: Go Live button on Stage toolbar!
            if (!isRecording && onGoLiveClick != null) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFE50914),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onGoLiveClick() }
                        .testTag("toolbar_go_live_btn"),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = stringResource(R.string.btn_go_live),
                            tint = Color.White,
                            modifier = Modifier.size(15.dp),
                        )
                        Text(
                            text = stringResource(R.string.btn_go_live),
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }

            // Screenshot button (stub)
            IconButton(
                onClick = onScreenshotClick,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("screenshot_button"),
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = "Take Screenshot",
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.size(20.dp),
                )
            }

            // Step 18: Face cam toggle
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isFaceCamActive) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.12f),
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onFaceCamToggle?.invoke() }
                    .testTag("toolbar_face_cam_toggle"),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Face Cam",
                        tint = if (isFaceCamActive) MaterialTheme.colorScheme.onPrimary else Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(14.dp),
                    )
                    Text(
                        text = "Face cam",
                        color = if (isFaceCamActive) MaterialTheme.colorScheme.onPrimary else Color.White.copy(alpha = 0.9f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }

            // Step 12: Debug button on toolbar "test 5 s" that records 5 seconds with current settings
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isTestRecording) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.14f),
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onTest5sClick() }
                    .testTag("debug_test_5s_button"),
            ) {
                Text(
                    text = if (isTestRecording) "5s..." else "test 5 s",
                    color = if (isTestRecording) MaterialTheme.colorScheme.onPrimary else Color.White.copy(alpha = 0.9f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                )
            }
        }
    }
}

/**
 * Drawing Tools: Pen, Highlighter, Eraser, and Color Swatch button.
 */
@Composable
private fun DrawingToolsGroup(
    currentTool: Tool,
    currentColor: PaletteColor,
    onToolSelect: (Tool) -> Unit,
    onSwatchClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        // Pen
        val isPen = currentTool == Tool.PEN
        ToolIconButton(
            icon = Icons.Default.Edit,
            contentDescription = "Pen",
            isSelected = isPen,
            onClick = { onToolSelect(Tool.PEN) },
            testTag = "tool_pen",
        )

        // Highlighter
        val isHighlighter = currentTool == Tool.HIGHLIGHTER
        ToolIconButton(
            icon = Icons.Default.Highlight,
            contentDescription = "Highlighter",
            isSelected = isHighlighter,
            onClick = { onToolSelect(Tool.HIGHLIGHTER) },
            testTag = "tool_highlighter",
        )

        // Eraser
        val isEraser = currentTool == Tool.ERASER
        ToolIconButton(
            icon = Icons.Default.AutoFixNormal,
            contentDescription = "Eraser",
            isSelected = isEraser,
            onClick = { onToolSelect(Tool.ERASER) },
            testTag = "tool_eraser",
        )

        // Colour swatch button (opens the 6 colours)
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .border(2.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                .clickable { onSwatchClick() }
                .testTag("color_swatch_button"),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(Color(currentColor.argb)),
            )
        }
    }
}

@Composable
private fun ToolIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String,
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.1f),
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .testTag(testTag),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = if (isSelected) MaterialTheme.colorScheme.onPrimary else Color.White,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

/**
 * History: Undo, Redo, and Clear Page.
 */
@Composable
private fun HistoryToolsGroup(
    canUndo: Boolean,
    canRedo: Boolean,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        // Undo
        IconButton(
            onClick = onUndo,
            enabled = canUndo,
            modifier = Modifier
                .size(34.dp)
                .testTag("undo_button"),
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Undo,
                contentDescription = "Undo",
                tint = if (canUndo) Color.White else Color.White.copy(alpha = 0.3f),
                modifier = Modifier.size(20.dp),
            )
        }

        // Redo
        IconButton(
            onClick = onRedo,
            enabled = canRedo,
            modifier = Modifier
                .size(34.dp)
                .testTag("redo_button"),
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Redo,
                contentDescription = "Redo",
                tint = if (canRedo) Color.White else Color.White.copy(alpha = 0.3f),
                modifier = Modifier.size(20.dp),
            )
        }

        // Clear Page
        IconButton(
            onClick = onClear,
            modifier = Modifier
                .size(34.dp)
                .testTag("clear_page_button"),
        ) {
            Icon(
                imageVector = Icons.Default.DeleteOutline,
                contentDescription = "Clear Page",
                tint = Color(0xFFFF5252),
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

/**
 * Slide navigation: Prev, Page chips (1..N), Next.
 */
@Composable
private fun PageChipsGroup(
    slidesCount: Int,
    currentSlideIndex: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onGoToSlide: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val canGoPrev = slidesCount > 1 && currentSlideIndex > 0
    val canGoNext = slidesCount > 1 && currentSlideIndex < slidesCount - 1

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        // Prev button
        IconButton(
            onClick = onPrev,
            enabled = canGoPrev,
            modifier = Modifier
                .size(30.dp)
                .testTag("prev_page_button"),
        ) {
            Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = "Previous Slide",
                tint = if (canGoPrev) Color.White else Color.White.copy(alpha = 0.25f),
                modifier = Modifier.size(22.dp),
            )
        }

        // Page chips 1..N
        if (slidesCount > 0) {
            LazyRow(
                modifier = Modifier.weight(1f, fill = false),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                items(slidesCount) { idx ->
                    val isSelected = idx == currentSlideIndex
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primary
                                else Color.White.copy(alpha = 0.18f),
                            )
                            .clickable { onGoToSlide(idx) }
                            .testTag("page_chip_${idx + 1}"),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = "${idx + 1}",
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else Color.White,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        )
                    }
                }
            }
        }

        // Next button
        IconButton(
            onClick = onNext,
            enabled = canGoNext,
            modifier = Modifier
                .size(30.dp)
                .testTag("next_page_button"),
        ) {
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Next Slide",
                tint = if (canGoNext) Color.White else Color.White.copy(alpha = 0.25f),
                modifier = Modifier.size(22.dp),
            )
        }
    }
}

/**
 * Floating popup displaying the 6 color swatches and the stroke width slider.
 */
@Composable
private fun ColorPalettePopup(
    currentColor: PaletteColor,
    widthNorm: Float,
    onColorSelected: (PaletteColor) -> Unit,
    onWidthChanged: (Float) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .testTag("color_palette_popup"),
        color = Color(0xFF1E222B),
        shadowElevation = 12.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = "Pen & Highlighter Colors",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(24.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Colors",
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(16.dp),
                    )
                }
            }

            // 6 Swatches
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PaletteColor.values().forEach { color ->
                    val isSelected = color == currentColor
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(color.argb))
                            .border(
                                width = if (isSelected) 3.dp else 1.dp,
                                color = if (isSelected) Color.White else Color.Transparent,
                                shape = CircleShape,
                            )
                            .clickable { onColorSelected(color) }
                            .testTag("color_swatch_${color.name}"),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (color == PaletteColor.BLACK) Color.White else Color.Black.copy(alpha = 0.8f)
                                    ),
                            )
                        }
                    }
                }
            }

            // Stroke width slider
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "Stroke Width",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                    )
                    // Visual dot preview of width
                    Box(
                        modifier = Modifier
                            .size(20.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        val dotSize = (widthNorm * 1000f).coerceIn(4f, 18f).dp
                        Box(
                            modifier = Modifier
                                .size(dotSize)
                                .clip(CircleShape)
                                .background(Color(currentColor.argb)),
                        )
                    }
                }

                Slider(
                    value = widthNorm,
                    onValueChange = onWidthChanged,
                    valueRange = 0.002f..0.025f,
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary,
                        inactiveTrackColor = Color.White.copy(alpha = 0.2f),
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("width_slider"),
                )
            }
        }
    }
}
