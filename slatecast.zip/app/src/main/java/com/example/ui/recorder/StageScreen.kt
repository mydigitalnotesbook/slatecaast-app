package com.example.ui.recorder

import android.Manifest
import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Build
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import com.example.data.settings.LiveStreamConfig
import com.example.data.settings.LiveStreamConfigStore
import com.example.ui.live.YouTubeLiveScreen
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import androidx.compose.ui.window.Dialog
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.settings.OutputAspectRatio
import com.example.data.settings.RecorderSettings
import com.example.data.storage.SlideProjectRepositoryImpl
import com.example.recorder.canvas.AspectStage
import com.example.recorder.canvas.StageRenderer
import com.example.recorder.engine.RecordingSessionState
import kotlinx.coroutines.launch
import java.io.File

/**
 * Stage Screen (Steps 8, 9, 10, 14):
 * - Immersive fullscreen (hidden system bars)
 * - Orientation locked: Landscape for 16:9, Portrait for 9:16
 * - AspectStage centered rectangle
 * - Drawing layer on top of stage
 * - Step 14 Session Controller: 3-2-1 countdown, Pause dialog, Back confirmation, and auto-pause on audio focus loss
 */
@Composable
fun StageScreen(
    projectId: String,
    autoStartLive: Boolean = false,
    onNavigateBack: () -> Unit,
    onNavigateToLibrary: (() -> Unit)? = null,
    onNavigateToSettings: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    viewModel: StageViewModel = rememberStageViewModel(projectId),
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val project by viewModel.projectState.collectAsStateWithLifecycle()
    val currentSlideIndex by viewModel.currentSlideIndex.collectAsStateWithLifecycle()
    val currentSlide by viewModel.currentSlide.collectAsStateWithLifecycle()
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()

    val isLiveMode by viewModel.isLiveMode.collectAsStateWithLifecycle()
    val systemMsg by viewModel.systemMessage.collectAsStateWithLifecycle()

    var showBackConfirmDialog by remember { mutableStateOf(false) }
    var showStopLiveConfirmDialog by remember { mutableStateOf(false) }
    var showLiveSetupSheet by remember { mutableStateOf(false) }
    var pendingLiveConfig by remember { mutableStateOf<LiveStreamConfig?>(null) }
    var showAudioRationale by remember { mutableStateOf(false) }
    var showCameraRationale by remember { mutableStateOf(false) }

    // Step 17 Web Page presentation state
    var webUrl by remember { mutableStateOf("https://en.wikipedia.org") }
    var webTouchMode by remember { mutableStateOf(com.example.ui.lecture.StageTouchMode.DRAW) }
    var webViewInstance by remember { mutableStateOf<android.webkit.WebView?>(null) }
    var latestWebFrame by remember { mutableStateOf<android.graphics.Bitmap?>(null) }

    val isFaceCamActive by viewModel.faceCamSource.isEnabled.collectAsStateWithLifecycle()

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { isGranted ->
        if (isGranted) {
            viewModel.faceCamSource.setEnabled(true)
        } else {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Camera permission is required for Face cam.")
            }
        }
    }

    val handleToggleFaceCam: () -> Unit = {
        if (!isFaceCamActive) {
            val hasCameraPerm = androidx.core.content.ContextCompat.checkSelfPermission(
                context, Manifest.permission.CAMERA
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

            if (!hasCameraPerm) {
                showCameraRationale = true
            } else {
                viewModel.faceCamSource.setEnabled(true)
            }
        } else {
            viewModel.faceCamSource.setEnabled(false)
        }
    }

    // Android 13+ Notification permission request
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { _ -> }

    DisposableEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        onDispose {}
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { isGranted ->
        if (isGranted) {
            val pendingConfig = pendingLiveConfig
            if (pendingConfig != null) {
                pendingLiveConfig = null
                startLiveStreamingWithSession(
                    context = context,
                    viewModel = viewModel,
                    project = project,
                    currentSlideIndex = currentSlideIndex,
                    liveConfig = pendingConfig,
                    latestWebFrameProvider = { latestWebFrame },
                )
            } else {
                startRecordingWithSession(
                    context = context,
                    viewModel = viewModel,
                    project = project,
                    currentSlideIndex = currentSlideIndex,
                    snackbarHostState = snackbarHostState,
                    coroutineScope = coroutineScope,
                    onNavigateToLibrary = onNavigateToLibrary,
                    enableAudio = true,
                    latestWebFrameProvider = { latestWebFrame },
                )
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(autoStartLive) {
        if (autoStartLive && !isLiveMode) {
            val store = LiveStreamConfigStore(context)
            val config = store.loadConfig()
            if (config.streamKey.isBlank()) {
                showLiveSetupSheet = true
            } else if (!hasAudioPermission(context)) {
                pendingLiveConfig = config
                showAudioRationale = true
            } else {
                startLiveStreamingWithSession(
                    context = context,
                    viewModel = viewModel,
                    project = project,
                    currentSlideIndex = currentSlideIndex,
                    liveConfig = config,
                    latestWebFrameProvider = { latestWebFrame },
                )
            }
        }
    }

    val handleRecordClick: () -> Unit = {
        when (sessionState) {
            is RecordingSessionState.Idle -> {
                if (!hasAudioPermission(context)) {
                    showAudioRationale = true
                } else {
                    startRecordingWithSession(
                        context = context,
                        viewModel = viewModel,
                        project = project,
                        currentSlideIndex = currentSlideIndex,
                        snackbarHostState = snackbarHostState,
                        coroutineScope = coroutineScope,
                        onNavigateToLibrary = onNavigateToLibrary,
                        enableAudio = true,
                        latestWebFrameProvider = { latestWebFrame },
                    )
                }
            }
            is RecordingSessionState.Recording -> {
                viewModel.pauseRecording()
            }
            is RecordingSessionState.Paused -> {
                viewModel.resumeRecording()
            }
            else -> {}
        }
    }

    val aspect = project?.aspectRatio ?: if (projectId.contains("9x16") || projectId.contains("PORTRAIT")) {
        OutputAspectRatio.PORTRAIT_9_16
    } else {
        OutputAspectRatio.LANDSCAPE_16_9
    }

    // Handle system Back button: if session is active, confirm before exiting
    BackHandler {
        if (isLiveMode) {
            showStopLiveConfirmDialog = true
        } else if (viewModel.isSessionActive()) {
            showBackConfirmDialog = true
        } else {
            onNavigateBack()
        }
    }

    // Immersive mode, keep screen awake, and lock orientation
    val activity = context as? Activity
    DisposableEffect(activity, aspect) {
        val originalOrientation = activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val window = activity?.window

        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        window?.let { win ->
            val insetsController = WindowCompat.getInsetsController(win, win.decorView)
            insetsController.hide(WindowInsetsCompat.Type.systemBars())
            insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        activity?.requestedOrientation = if (aspect == OutputAspectRatio.LANDSCAPE_16_9) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }

        onDispose {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            window?.let { win ->
                val insetsController = WindowCompat.getInsetsController(win, win.decorView)
                insetsController.show(WindowInsetsCompat.Type.systemBars())
            }
            activity?.requestedOrientation = originalOrientation
        }
    }

    val slides = project?.slides ?: emptyList()
    var dragTotal by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("stage_screen_root"),
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
        ) {
            // Step 17: WebStageControls outside the stage rectangle when browsing a web slide
            if (currentSlide?.sourceType == "web") {
                com.example.ui.lecture.WebStageControls(
                    urlInput = webUrl,
                    onUrlChange = { webUrl = it },
                    onNavigateUrl = { targetUrl ->
                        var formatted = targetUrl.trim()
                        if (!formatted.startsWith("http://") && !formatted.startsWith("https://")) {
                            formatted = "https://$formatted"
                        }
                        webUrl = formatted
                        webViewInstance?.loadUrl(formatted)
                    },
                    canGoBack = webViewInstance?.canGoBack() ?: false,
                    onGoBack = { webViewInstance?.goBack() },
                    canGoForward = webViewInstance?.canGoForward() ?: false,
                    onGoForward = { webViewInstance?.goForward() },
                    onReload = { webViewInstance?.reload() },
                    touchMode = webTouchMode,
                    onTouchModeChange = { webTouchMode = it },
                )
            }

            // 1. Stage Area (Takes remaining space, strictly bounding the stage rectangle above the toolbar)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) {
                // Center Stage bounded by exact Aspect Ratio
                AspectStage(
                    aspect = aspect,
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(slides.size, currentSlide?.sourceType, webTouchMode) {
                            if (slides.size > 1 && (currentSlide?.sourceType != "web" || webTouchMode == com.example.ui.lecture.StageTouchMode.DRAW)) {
                                detectHorizontalDragGestures(
                                    onDragStart = { dragTotal = 0f },
                                    onDragEnd = {
                                        if (dragTotal < -80f) {
                                            viewModel.nextSlide()
                                        } else if (dragTotal > 80f) {
                                            viewModel.previousSlide()
                                        }
                                        dragTotal = 0f
                                    },
                                    onHorizontalDrag = { _, dragAmount ->
                                        dragTotal += dragAmount
                                    },
                                )
                            }
                        },
                ) { stageW, stageH ->
                    if (currentSlide != null) {
                        if (currentSlide!!.sourceType == "web") {
                            com.example.ui.lecture.WebStageView(
                                url = webUrl,
                                onWebViewCreated = { webViewInstance = it },
                                onFrameCaptured = { frame ->
                                    latestWebFrame = frame
                                },
                                modifier = Modifier.fillMaxSize(),
                            )
                        } else {
                            AsyncImage(
                                model = File(currentSlide!!.filePath),
                                contentDescription = "Slide ${currentSlide!!.pageNumber}",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("stage_current_slide_image"),
                                contentScale = ContentScale.Fit,
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Icon(
                                imageVector = Icons.Default.Slideshow,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.4f),
                                modifier = Modifier.size(64.dp),
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = if (slides.isEmpty()) "No slides in this lecture" else "Loading slide...",
                                color = Color.White.copy(alpha = 0.8f),
                                style = MaterialTheme.typography.titleMedium,
                            )
                        }
                    }

                    // Step 9 & 17: Drawing Layer on top of the stage (inside the recorded stage bounds)
                    DrawingOverlay(
                        slideIndex = currentSlideIndex,
                        drawingState = viewModel.drawingState,
                        enabled = (currentSlide?.sourceType != "web" || webTouchMode == com.example.ui.lecture.StageTouchMode.DRAW),
                        modifier = Modifier.fillMaxSize(),
                    )

                    // Step 18: Face Camera Bubble on top inside the stage
                    if (isFaceCamActive) {
                        val density = androidx.compose.ui.platform.LocalDensity.current
                        val stageWPx = with(density) { stageW.toPx() }
                        val stageHPx = with(density) { stageH.toPx() }
                        FaceCamBubble(
                            faceCamSource = viewModel.faceCamSource,
                            stageWidthPx = stageWPx,
                            stageHeightPx = stageHPx,
                            onCameraFailure = { errorMsg ->
                                viewModel.faceCamSource.setEnabled(false)
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Face cam unavailable: $errorMsg")
                                }
                            },
                            onClose = {
                                viewModel.faceCamSource.setEnabled(false)
                            },
                        )
                    }
                }

                // Top-left Exit/Close button (outside the recording area)
                IconButton(
                    onClick = {
                        if (isLiveMode) {
                            showStopLiveConfirmDialog = true
                        } else if (viewModel.isSessionActive()) {
                            showBackConfirmDialog = true
                        } else {
                            onNavigateBack()
                        }
                    },
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(16.dp)
                        .size(44.dp)
                        .testTag("stage_close_btn"),
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.65f),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Stage",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp),
                            )
                        }
                    }
                }
            }

            // 2. Step 10 & 14 & 18: RecorderToolbar OUTSIDE the stage rectangle
            RecorderToolbar(
                viewModel = viewModel,
                onToggleFaceCam = handleToggleFaceCam,
                isFaceCamActive = isFaceCamActive,
                onRecordClicked = handleRecordClick,
                onGoLiveClicked = { showLiveSetupSheet = true },
                onStopLiveClicked = { showStopLiveConfirmDialog = true },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        // 3. Step 14: Countdown Overlay (3, 2, 1) outside the stage rectangle (NOT in video)
        if (sessionState is RecordingSessionState.Counting) {
            val count = (sessionState as RecordingSessionState.Counting).count
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .testTag("countdown_overlay"),
                contentAlignment = Alignment.Center,
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF1E2129),
                    shadowElevation = 16.dp,
                    border = androidx.compose.foundation.BorderStroke(4.dp, MaterialTheme.colorScheme.primary),
                    modifier = Modifier.size(140.dp),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "$count",
                            color = Color.White,
                            fontSize = 68.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.testTag("countdown_text"),
                        )
                    }
                }
            }
        }

        // 4. Step 14: "Recording paused" Dialog
        if (sessionState is RecordingSessionState.Paused) {
            Dialog(onDismissRequest = { /* Force user to choose resume or stop */ }) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF1E2129),
                    shadowElevation = 16.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .testTag("recording_paused_dialog"),
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFE53935).copy(alpha = 0.2f),
                            modifier = Modifier.size(52.dp),
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Pause,
                                    contentDescription = null,
                                    tint = Color(0xFFE53935),
                                    modifier = Modifier.size(28.dp),
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "Recording paused",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Timer is paused. Would you like to resume teaching or finish and save your lecture?",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.75f),
                            lineHeight = 20.sp,
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.stopRecording { uri ->
                                        showSavedSnackbar(
                                            coroutineScope = coroutineScope,
                                            snackbarHostState = snackbarHostState,
                                            onNavigateToLibrary = onNavigateToLibrary,
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("paused_dialog_stop_btn"),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFFFF5252),
                                ),
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("STOP")
                            }

                            Button(
                                onClick = { viewModel.resumeRecording() },
                                modifier = Modifier
                                    .weight(1.2f)
                                    .testTag("paused_dialog_resume_btn"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary,
                                ),
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("RESUME")
                            }
                        }
                    }
                }
            }
        }

        // 5. Back-press confirmation Dialog while recording
        if (showBackConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showBackConfirmDialog = false },
                title = { Text("Stop recording?", color = Color.White) },
                text = {
                    Text(
                        "You have an ongoing recording session. Would you like to save this lecture video before leaving?",
                        color = Color.White.copy(alpha = 0.85f),
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showBackConfirmDialog = false
                            viewModel.stopRecording {
                                onNavigateBack()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.testTag("back_confirm_save_btn"),
                    ) {
                        Text("Save & Exit")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showBackConfirmDialog = false },
                        modifier = Modifier.testTag("back_confirm_cancel_btn"),
                    ) {
                        Text("Keep Recording", color = Color.White.copy(alpha = 0.7f))
                    }
                },
                containerColor = Color(0xFF1E2129),
            )
        }

        // 6. Audio rationale dialog if permission is missing
        if (showAudioRationale) {
            AudioPermissionRationaleDialog(
                onGrantRequested = {
                    showAudioRationale = false
                    audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                onDismiss = { showAudioRationale = false },
                onContinueSilent = {
                    showAudioRationale = false
                    startRecordingWithSession(
                        context = context,
                        viewModel = viewModel,
                        project = project,
                        currentSlideIndex = currentSlideIndex,
                        snackbarHostState = snackbarHostState,
                        coroutineScope = coroutineScope,
                        onNavigateToLibrary = onNavigateToLibrary,
                        enableAudio = false,
                        latestWebFrameProvider = { latestWebFrame },
                    )
                },
            )
        }

        // 7. Global Snackbar Host for "Saved to Lectures"
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 70.dp)
                .testTag("stage_snackbar_host"),
        )

        // 8. Hardware Encoder Failure Dialog (Step 16)
        if (sessionState is RecordingSessionState.Failed) {
            val failureReason = (sessionState as RecordingSessionState.Failed).reason
            AlertDialog(
                onDismissRequest = { viewModel.dismissFailure() },
                title = { Text(stringResource(R.string.recording_failed_title), color = Color.White) },
                text = {
                    Text(
                        text = stringResource(R.string.recording_failed_msg, failureReason),
                        color = Color.White.copy(alpha = 0.85f),
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.dismissFailure()
                            onNavigateToSettings?.invoke()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.testTag("open_recorder_settings_btn"),
                    ) {
                        Text(stringResource(R.string.btn_open_recorder_settings))
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { viewModel.dismissFailure() },
                        modifier = Modifier.testTag("dismiss_failure_btn"),
                    ) {
                        Text(stringResource(R.string.btn_cancel), color = Color.White.copy(alpha = 0.7f))
                    }
                },
                containerColor = Color(0xFF1E2129),
                modifier = Modifier.testTag("recording_failure_dialog"),
            )
        }

        // 9. Camera permission rationale dialog (Step 18)
        if (showCameraRationale) {
            CameraPermissionRationaleDialog(
                onGrantRequested = {
                    showCameraRationale = false
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                },
                onDismiss = { showCameraRationale = false },
            )
        }

        // 10. Stop YouTube Live confirmation dialog
        if (showStopLiveConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showStopLiveConfirmDialog = false },
                title = { Text(stringResource(R.string.live_stop_confirm_title), color = Color.White) },
                text = {
                    Text(
                        text = stringResource(R.string.live_stop_confirm_msg),
                        color = Color.White.copy(alpha = 0.85f),
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showStopLiveConfirmDialog = false
                            viewModel.stopRecording { uri ->
                                if (uri != android.net.Uri.EMPTY) {
                                    showSavedSnackbar(
                                        coroutineScope = coroutineScope,
                                        snackbarHostState = snackbarHostState,
                                        onNavigateToLibrary = onNavigateToLibrary,
                                    )
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE50914)),
                        modifier = Modifier.testTag("live_confirm_stop_btn"),
                    ) {
                        Text(stringResource(R.string.live_stop_confirm_yes))
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showStopLiveConfirmDialog = false },
                        modifier = Modifier.testTag("live_confirm_cancel_btn"),
                    ) {
                        Text(stringResource(R.string.live_stop_confirm_no), color = Color.White.copy(alpha = 0.7f))
                    }
                },
                containerColor = Color(0xFF1E2129),
            )
        }

        // 11. YouTube Live Setup Dialog
        if (showLiveSetupSheet) {
            Dialog(
                onDismissRequest = { showLiveSetupSheet = false },
                properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
            ) {
                YouTubeLiveScreen(
                    onNavigateBack = { showLiveSetupSheet = false },
                    onStartLive = { config ->
                        showLiveSetupSheet = false
                        if (!hasAudioPermission(context)) {
                            pendingLiveConfig = config
                            showAudioRationale = true
                        } else {
                            startLiveStreamingWithSession(
                                context = context,
                                viewModel = viewModel,
                                project = project,
                                currentSlideIndex = currentSlideIndex,
                                liveConfig = config,
                                latestWebFrameProvider = { latestWebFrame },
                            )
                        }
                    },
                )
            }
        }

        // 12. System message banner (Incoming phone calls auto-muting, low battery < 15%)
        if (systemMsg != null) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFD32F2F),
                shadowElevation = 8.dp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp, start = 16.dp, end = 16.dp)
                    .testTag("live_system_message_banner"),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp),
                    )
                    Text(
                        text = systemMsg!!,
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    IconButton(
                        onClick = { viewModel.clearSystemMessage() },
                        modifier = Modifier.size(24.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp),
                        )
                    }
                }
            }
        }
    }
}

private fun startLiveStreamingWithSession(
    context: android.content.Context,
    viewModel: StageViewModel,
    project: com.example.data.storage.ProjectInfo?,
    currentSlideIndex: Int,
    liveConfig: com.example.data.settings.LiveStreamConfig,
    latestWebFrameProvider: () -> android.graphics.Bitmap? = { null },
) {
    val slides = project?.slides ?: emptyList()
    val aspect = project?.aspectRatio ?: OutputAspectRatio.LANDSCAPE_16_9
    val stageRenderer = StageRenderer(
        context = context,
        slidesProvider = { slides },
        currentSlideIndexProvider = { currentSlideIndex },
        drawingStateProvider = { viewModel.drawingState },
        webFrameProvider = latestWebFrameProvider,
        faceCamCompositor = { canvas, width, height ->
            viewModel.faceCamSource.composite(canvas, width, height)
        },
    )
    viewModel.startLiveStream(
        stageRenderer = stageRenderer,
        liveConfig = liveConfig,
        aspect = aspect,
    )
}

private fun startRecordingWithSession(
    context: android.content.Context,
    viewModel: StageViewModel,
    project: com.example.data.storage.ProjectInfo?,
    currentSlideIndex: Int,
    snackbarHostState: SnackbarHostState,
    coroutineScope: kotlinx.coroutines.CoroutineScope,
    onNavigateToLibrary: (() -> Unit)?,
    enableAudio: Boolean = true,
    latestWebFrameProvider: () -> android.graphics.Bitmap? = { null },
) {
    val slides = project?.slides ?: emptyList()
    val aspect = project?.aspectRatio ?: OutputAspectRatio.LANDSCAPE_16_9
    val stageRenderer = StageRenderer(
        context = context,
        slidesProvider = { slides },
        currentSlideIndexProvider = { currentSlideIndex },
        drawingStateProvider = { viewModel.drawingState },
        webFrameProvider = latestWebFrameProvider,
        faceCamCompositor = { canvas, width, height ->
            viewModel.faceCamSource.composite(canvas, width, height)
        },
    )
    viewModel.startRecording(
        stageRenderer = stageRenderer,
        settings = RecorderSettings(),
        aspect = aspect,
        enableAudio = enableAudio,
    ) { savedUri ->
        showSavedSnackbar(coroutineScope, snackbarHostState, onNavigateToLibrary)
    }
}

private fun showSavedSnackbar(
    coroutineScope: kotlinx.coroutines.CoroutineScope,
    snackbarHostState: SnackbarHostState,
    onNavigateToLibrary: (() -> Unit)?,
) {
    coroutineScope.launch {
        val result = snackbarHostState.showSnackbar(
            message = "Saved to Lectures",
            actionLabel = "Open",
            duration = SnackbarDuration.Long,
        )
        if (result == SnackbarResult.ActionPerformed) {
            onNavigateToLibrary?.invoke()
        }
    }
}

@Composable
fun rememberStageViewModel(projectId: String): StageViewModel {
    val context = LocalContext.current.applicationContext
    return remember(projectId) {
        val repo = SlideProjectRepositoryImpl(context)
        StageViewModel(projectId, repo, context)
    }
}
