package com.example.ui.recorder

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.settings.OutputAspectRatio
import com.example.data.settings.RecorderSettings
import com.example.data.storage.ProjectInfo
import com.example.data.storage.SlideItem
import com.example.data.storage.SlideProjectRepository
import com.example.recorder.canvas.DrawingState
import com.example.recorder.canvas.PaletteColor
import com.example.recorder.canvas.StageRenderer
import com.example.recorder.canvas.Tool
import com.example.recorder.engine.RecorderController
import com.example.recorder.engine.RecordingSessionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * StageState ViewModel managing current slide index, slide items, drawing state,
 * and the Step 14 RecorderController session state.
 */
class StageViewModel(
    val projectId: String,
    private val repository: SlideProjectRepository,
    context: Context? = null,
) : ViewModel() {

    val drawingState = DrawingState()
    val faceCamSource = com.example.recorder.engine.FaceCamSource()

    // Step 14 RecorderController
    val recorderController: RecorderController? = context?.let {
        RecorderController(it, viewModelScope)
    }

    private val fallbackSessionState = MutableStateFlow<RecordingSessionState>(RecordingSessionState.Idle)
    val sessionState: StateFlow<RecordingSessionState> = recorderController?.sessionState ?: fallbackSessionState.asStateFlow()

    private val fallbackTimer = MutableStateFlow(0L)
    val elapsedTimeSeconds: StateFlow<Long> = recorderController?.elapsedTimeSeconds ?: fallbackTimer.asStateFlow()

    val timerText: StateFlow<String> = elapsedTimeSeconds.map { sec ->
        String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "00:00")

    private val fallbackIsRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = if (recorderController != null) {
        sessionState.map { it is RecordingSessionState.Recording }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    } else {
        fallbackIsRecording.asStateFlow()
    }

    // Live Streaming State
    val isLiveMode: StateFlow<Boolean> = recorderController?.isLiveMode ?: MutableStateFlow(false).asStateFlow()
    val liveStreamState: StateFlow<com.example.recorder.engine.LiveStreamState> =
        recorderController?.liveStreamState ?: MutableStateFlow<com.example.recorder.engine.LiveStreamState>(com.example.recorder.engine.LiveStreamState.Idle).asStateFlow()
    val liveBitrateBps: StateFlow<Long> = recorderController?.liveBitrateBps ?: MutableStateFlow(0L).asStateFlow()
    val droppedFrames: StateFlow<Long> = recorderController?.droppedFrames ?: MutableStateFlow(0L).asStateFlow()
    val isMicMuted: StateFlow<Boolean> = recorderController?.isMicMuted ?: MutableStateFlow(false).asStateFlow()
    val isBeRightBack: StateFlow<Boolean> = recorderController?.isBeRightBack ?: MutableStateFlow(false).asStateFlow()
    val systemMessage: StateFlow<String?> = recorderController?.systemMessage ?: MutableStateFlow<String?>(null).asStateFlow()

    init {
        recorderController?.engine?.customFrameHook = { canvas, width, height ->
            if (isBeRightBack.value) {
                drawBeRightBackScreen(canvas, width, height)
            }
        }
    }

    // Toolbar state (Step 10)
    val currentTool = drawingState.currentTool
    val currentColor = drawingState.currentColor
    val widthNorm = drawingState.widthNorm

    private val _isToolbarCollapsed = MutableStateFlow(false)
    val isToolbarCollapsed: StateFlow<Boolean> = _isToolbarCollapsed.asStateFlow()

    private val _isColorPaletteOpen = MutableStateFlow(false)
    val isColorPaletteOpen: StateFlow<Boolean> = _isColorPaletteOpen.asStateFlow()

    fun setTool(tool: Tool) {
        drawingState.setTool(tool)
    }

    fun setColor(color: PaletteColor) {
        drawingState.setColor(color)
    }

    fun setWidthNorm(width: Float) {
        drawingState.setWidthNorm(width)
    }

    fun toggleRecording() {
        if (recorderController != null) {
            when (sessionState.value) {
                is RecordingSessionState.Idle -> {
                    // Trigger countdown and session start handled via UI stageRenderer
                }
                is RecordingSessionState.Recording -> {
                    pauseRecording()
                }
                is RecordingSessionState.Paused -> {
                    resumeRecording()
                }
                else -> {}
            }
        } else {
            fallbackIsRecording.value = !fallbackIsRecording.value
        }
    }

    fun setRecording(recording: Boolean) {
        fallbackIsRecording.value = recording
    }

    fun startRecording(
        stageRenderer: StageRenderer,
        settings: RecorderSettings = RecorderSettings(),
        aspect: OutputAspectRatio = OutputAspectRatio.LANDSCAPE_16_9,
        enableAudio: Boolean = true,
        onSaved: ((Uri) -> Unit)? = null,
    ) {
        if (recorderController != null) {
            recorderController.startSession(stageRenderer, settings, aspect, enableAudio, onSaved)
        } else {
            fallbackSessionState.value = RecordingSessionState.Recording
            fallbackIsRecording.value = true
        }
    }

    fun pauseRecording() {
        recorderController?.pause() ?: run {
            fallbackSessionState.value = RecordingSessionState.Paused
        }
    }

    fun resumeRecording() {
        recorderController?.resume() ?: run {
            fallbackSessionState.value = RecordingSessionState.Recording
        }
    }

    fun stopRecording(onSaved: ((Uri) -> Unit)? = null) {
        if (recorderController != null) {
            recorderController.stop(onSaved)
        } else {
            fallbackSessionState.value = RecordingSessionState.Idle
            fallbackIsRecording.value = false
            fallbackTimer.value = 0L
            onSaved?.invoke(Uri.EMPTY)
        }
    }

    fun dismissFailure() {
        recorderController?.dismissFailure()
    }

    fun isSessionActive(): Boolean {
        return recorderController?.isSessionActive() ?: fallbackIsRecording.value
    }

    fun toggleToolbarCollapse() {
        _isToolbarCollapsed.value = !_isToolbarCollapsed.value
    }

    fun setToolbarCollapsed(collapsed: Boolean) {
        _isToolbarCollapsed.value = collapsed
    }

    fun toggleColorPalette() {
        _isColorPaletteOpen.value = !_isColorPaletteOpen.value
    }

    fun closeColorPalette() {
        _isColorPaletteOpen.value = false
    }

    fun toggleFaceCam(hasPermission: Boolean) {
        if (!hasPermission) {
            faceCamSource.setEnabled(false)
            return
        }
        faceCamSource.setEnabled(!faceCamSource.isEnabled.value)
    }

    private val _projectState = MutableStateFlow<ProjectInfo?>(null)
    val projectState: StateFlow<ProjectInfo?> = _projectState.asStateFlow()

    init {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.Unconfined) {
            repository.getProjectFlow(projectId).collect { info ->
                _projectState.value = info
            }
        }
    }

    private val _currentSlideIndex = MutableStateFlow(0)
    val currentSlideIndex: StateFlow<Int> = _currentSlideIndex.asStateFlow()

    val currentSlide: StateFlow<SlideItem?> = combine(projectState, _currentSlideIndex) { project, index ->
        val slides = project?.slides ?: emptyList()
        if (slides.isNotEmpty() && index in slides.indices) {
            slides[index]
        } else null
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null,
    )

    fun nextSlide() {
        val total = projectState.value?.slides?.size ?: 0
        if (total > 0 && _currentSlideIndex.value < total - 1) {
            _currentSlideIndex.value += 1
        }
    }

    fun previousSlide() {
        if (_currentSlideIndex.value > 0) {
            _currentSlideIndex.value -= 1
        }
    }

    fun goToSlide(index: Int) {
        val total = projectState.value?.slides?.size ?: 0
        if (total > 0 && index in 0 until total) {
            _currentSlideIndex.value = index
        }
    }

    fun startLiveStream(
        stageRenderer: StageRenderer,
        liveConfig: com.example.data.settings.LiveStreamConfig,
        aspect: OutputAspectRatio = OutputAspectRatio.LANDSCAPE_16_9,
        onSaved: ((Uri) -> Unit)? = null,
    ) {
        recorderController?.startLiveSession(stageRenderer, liveConfig, aspect, onSaved)
    }

    fun toggleMuteMic(): Boolean {
        return recorderController?.toggleMuteMic() ?: false
    }

    fun toggleBeRightBack(): Boolean {
        return recorderController?.toggleBeRightBack() ?: false
    }

    fun clearSystemMessage() {
        recorderController?.clearSystemMessage()
    }

    private fun drawBeRightBackScreen(canvas: android.graphics.Canvas, width: Int, height: Int) {
        val bgPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.rgb(11, 20, 38)
            style = android.graphics.Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        val cardPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.rgb(20, 32, 54)
            style = android.graphics.Paint.Style.FILL
        }
        val cardStroke = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(0, 188, 212)
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = 6f
        }
        val left = width * 0.08f
        val top = height * 0.32f
        val right = width * 0.92f
        val bottom = height * 0.68f
        canvas.drawRoundRect(left, top, right, bottom, 36f, 36f, cardPaint)
        canvas.drawRoundRect(left, top, right, bottom, 36f, 36f, cardStroke)

        val titlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = if (width > height) width * 0.040f else width * 0.065f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            textAlign = android.graphics.Paint.Align.CENTER
        }
        canvas.drawText("☕ BE RIGHT BACK", width / 2f, height * 0.46f, titlePaint)

        val subPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.argb(210, 255, 255, 255)
            textSize = if (width > height) width * 0.022f else width * 0.036f
            textAlign = android.graphics.Paint.Align.CENTER
        }
        canvas.drawText("The live presentation will resume shortly", width / 2f, height * 0.53f, subPaint)

        val badgePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(229, 9, 20)
            style = android.graphics.Paint.Style.FILL
        }
        val bw = if (width > height) width * 0.12f else width * 0.22f
        val bh = if (width > height) height * 0.045f else height * 0.035f
        val by = height * 0.59f
        canvas.drawRoundRect(width / 2f - bw / 2f, by, width / 2f + bw / 2f, by + bh, 18f, 18f, badgePaint)
        val badgeTextPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = bh * 0.6f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            textAlign = android.graphics.Paint.Align.CENTER
        }
        canvas.drawText("🔴 LIVE", width / 2f, by + bh * 0.72f, badgeTextPaint)
    }
}
