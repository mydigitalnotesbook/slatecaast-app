package com.example.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import android.util.Log
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.data.settings.AudioSourceOption
import com.example.data.settings.OutputAspectRatio
import com.example.data.settings.VideoCodecOption
import com.example.data.settings.isHevcSupported
import com.example.recorder.canvas.DrawingState
import com.example.recorder.canvas.StageRenderer
import com.example.recorder.engine.RecorderEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Recorder Settings screen featuring Audio and Video sections, single-choice dialogs,
 * hardware HEVC capability detection, top failure guidance note, and Reset-to-defaults menu.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    var showMenu by remember { mutableStateOf(false) }

    // Dialog state holders
    var showAudioSourceDialog by remember { mutableStateOf(false) }
    var showAudioBitrateDialog by remember { mutableStateOf(false) }
    var showVideoCodecDialog by remember { mutableStateOf(false) }
    var showVideoQualityDialog by remember { mutableStateOf(false) }
    var showFpsDialog by remember { mutableStateOf(false) }
    var showVideoBitrateDialog by remember { mutableStateOf(false) }
    var showDefaultAspectDialog by remember { mutableStateOf(false) }

    val hevcAvailable = remember { isHevcSupported() }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isTestingPhone by remember { mutableStateOf(false) }
    var testResultText by remember { mutableStateOf<String?>(null) }
    var testResultSuccess by remember { mutableStateOf(true) }

    val runPhoneTest: () -> Unit = {
        coroutineScope.launch {
            isTestingPhone = true
            testResultText = null
            try {
                val stageRenderer = StageRenderer(
                    context = context,
                    slidesProvider = { emptyList() },
                    drawingStateProvider = { DrawingState() },
                )
                val engine = RecorderEngine(context)
                withContext(Dispatchers.IO) {
                    engine.recordTest(
                        stageRenderer = stageRenderer,
                        settings = settings,
                        aspect = settings.defaultAspect,
                        durationSeconds = 3,
                        enableAudio = false,
                    )
                }
                testResultSuccess = true
                testResultText = context.getString(
                    R.string.settings_test_phone_success,
                    settings.videoCodec.name,
                    settings.videoQuality,
                )
            } catch (e: Throwable) {
                Log.e("RecorderEngine", "Test my phone failed: ${e.message}", e)
                testResultSuccess = false
                testResultText = context.getString(
                    R.string.settings_test_phone_failed,
                    e.message ?: "Encoder unsupported",
                )
            } finally {
                isTestingPhone = false
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("settings_screen"),
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.screen_settings_title)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("settings_back_btn")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.btn_back),
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showMenu = true }, modifier = Modifier.testTag("settings_menu_btn")) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = null,
                        )
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                    ) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.settings_menu_reset)) },
                            onClick = {
                                showMenu = false
                                viewModel.resetDefaults()
                            },
                            leadingIcon = {
                                Icon(Icons.Default.Refresh, contentDescription = null)
                            },
                            modifier = Modifier.testTag("settings_reset_item"),
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                ),
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Failure guidance note banner at the top
            Card(
                modifier = Modifier.fillMaxWidth().testTag("settings_note_card"),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                ),
                shape = RoundedCornerShape(12.dp),
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp),
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = stringResource(R.string.settings_note_fails),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Audio Section
            SettingsSectionHeader(title = stringResource(R.string.settings_section_audio))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                shape = RoundedCornerShape(14.dp),
            ) {
                Column {
                    SettingsRowItem(
                        icon = Icons.Default.Mic,
                        title = stringResource(R.string.settings_audio_source),
                        subtitle = settings.audioSource.name,
                        onClick = { showAudioSourceDialog = true },
                        testTag = "settings_row_audio_source",
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    SettingsRowItem(
                        icon = Icons.Default.Tune,
                        title = stringResource(R.string.settings_audio_bitrate),
                        subtitle = stringResource(R.string.settings_audio_bitrate_val, settings.audioBitrateKbps),
                        onClick = { showAudioBitrateDialog = true },
                        testTag = "settings_row_audio_bitrate",
                    )
                }
            }

            // Video Section
            SettingsSectionHeader(title = stringResource(R.string.settings_section_video))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                shape = RoundedCornerShape(14.dp),
            ) {
                Column {
                    SettingsRowItem(
                        icon = Icons.Default.Movie,
                        title = stringResource(R.string.settings_video_codec),
                        subtitle = settings.videoCodec.name,
                        onClick = { showVideoCodecDialog = true },
                        testTag = "settings_row_video_codec",
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    SettingsRowItem(
                        icon = Icons.Default.Videocam,
                        title = stringResource(R.string.settings_video_quality),
                        subtitle = stringResource(R.string.settings_video_quality_short_side, settings.videoQuality),
                        onClick = { showVideoQualityDialog = true },
                        testTag = "settings_row_video_quality",
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    SettingsRowItem(
                        icon = Icons.Default.Speed,
                        title = stringResource(R.string.settings_fps),
                        subtitle = stringResource(R.string.settings_fps_val, settings.fps),
                        onClick = { showFpsDialog = true },
                        testTag = "settings_row_fps",
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    SettingsRowItem(
                        icon = Icons.Default.Tune,
                        title = stringResource(R.string.settings_video_bitrate),
                        subtitle = stringResource(R.string.settings_video_bitrate_val, settings.videoBitrateMbps),
                        onClick = { showVideoBitrateDialog = true },
                        testTag = "settings_row_video_bitrate",
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    SettingsRowItem(
                        icon = Icons.Default.AspectRatio,
                        title = stringResource(R.string.settings_default_aspect),
                        subtitle = if (settings.defaultAspect == OutputAspectRatio.LANDSCAPE_16_9) {
                            stringResource(R.string.aspect_16_9_label)
                        } else {
                            stringResource(R.string.aspect_9_16_label)
                        },
                        onClick = { showDefaultAspectDialog = true },
                        testTag = "settings_row_default_aspect",
                    )
                }
            }

            // Device Compatibility Section (Step 16)
            SettingsSectionHeader(title = stringResource(R.string.settings_test_phone_title))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_compatibility_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                shape = RoundedCornerShape(14.dp),
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.settings_test_phone_btn),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.settings_test_phone_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = runPhoneTest,
                        enabled = !isTestingPhone,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_my_phone_btn"),
                    ) {
                        if (isTestingPhone) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp,
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Testing phone...")
                        } else {
                            Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.settings_test_phone_btn))
                        }
                    }

                    testResultText?.let { resultText ->
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (testResultSuccess) Color(0xFF1B5E20).copy(alpha = 0.2f) else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("test_phone_result"),
                        ) {
                            Text(
                                text = resultText,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (testResultSuccess) Color(0xFF4CAF50) else MaterialTheme.colorScheme.error,
                                modifier = Modifier.padding(12.dp),
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Audio Source Dialog (MIC, CAMCORDER)
    if (showAudioSourceDialog) {
        SingleChoiceDialog(
            title = stringResource(R.string.settings_audio_source),
            options = AudioSourceOption.entries.toList(),
            selectedOption = settings.audioSource,
            labelProvider = { it.name },
            onOptionSelected = {
                viewModel.setAudioSource(it)
                showAudioSourceDialog = false
            },
            onDismiss = { showAudioSourceDialog = false },
        )
    }

    // Audio Bitrate Dialog (64, 128, 192 kbps)
    if (showAudioBitrateDialog) {
        SingleChoiceDialog(
            title = stringResource(R.string.settings_audio_bitrate),
            options = listOf(64, 128, 192),
            selectedOption = settings.audioBitrateKbps,
            labelProvider = { "$it kbps" },
            onOptionSelected = {
                viewModel.setAudioBitrate(it)
                showAudioBitrateDialog = false
            },
            onDismiss = { showAudioBitrateDialog = false },
        )
    }

    // Video Codec Dialog (H264, and HEVC only if supported)
    if (showVideoCodecDialog) {
        val codecOptions = if (hevcAvailable) {
            listOf(VideoCodecOption.H264, VideoCodecOption.HEVC)
        } else {
            listOf(VideoCodecOption.H264)
        }
        SingleChoiceDialog(
            title = stringResource(R.string.settings_video_codec),
            options = codecOptions,
            selectedOption = settings.videoCodec,
            labelProvider = { it.name },
            onOptionSelected = {
                viewModel.setVideoCodec(it)
                showVideoCodecDialog = false
            },
            onDismiss = { showVideoCodecDialog = false },
        )
    }

    // Video Quality Dialog (720, 1080)
    if (showVideoQualityDialog) {
        SingleChoiceDialog(
            title = stringResource(R.string.settings_video_quality),
            options = listOf(720, 1080),
            selectedOption = settings.videoQuality,
            labelProvider = { "$it" + "p (Short side)" },
            onOptionSelected = {
                viewModel.setVideoQuality(it)
                showVideoQualityDialog = false
            },
            onDismiss = { showVideoQualityDialog = false },
        )
    }

    // FPS Dialog (24, 30, 60)
    if (showFpsDialog) {
        SingleChoiceDialog(
            title = stringResource(R.string.settings_fps),
            options = listOf(24, 30, 60),
            selectedOption = settings.fps,
            labelProvider = { "$it FPS" },
            onOptionSelected = {
                viewModel.setFps(it)
                showFpsDialog = false
            },
            onDismiss = { showFpsDialog = false },
        )
    }

    // Video Bitrate Dialog (2, 4, 6, 8 Mbps)
    if (showVideoBitrateDialog) {
        SingleChoiceDialog(
            title = stringResource(R.string.settings_video_bitrate),
            options = listOf(2, 4, 6, 8),
            selectedOption = settings.videoBitrateMbps,
            labelProvider = { "$it Mbps" },
            onOptionSelected = {
                viewModel.setVideoBitrate(it)
                showVideoBitrateDialog = false
            },
            onDismiss = { showVideoBitrateDialog = false },
        )
    }

    // Default Aspect Ratio Dialog (16:9, 9:16)
    if (showDefaultAspectDialog) {
        SingleChoiceDialog(
            title = stringResource(R.string.settings_default_aspect),
            options = listOf(OutputAspectRatio.LANDSCAPE_16_9, OutputAspectRatio.PORTRAIT_9_16),
            selectedOption = settings.defaultAspect,
            labelProvider = {
                if (it == OutputAspectRatio.LANDSCAPE_16_9) "16:9 Landscape" else "9:16 Portrait"
            },
            onOptionSelected = {
                viewModel.setDefaultAspect(it)
                showDefaultAspectDialog = false
            },
            onDismiss = { showDefaultAspectDialog = false },
        )
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 4.dp, top = 8.dp),
    )
}

@Composable
private fun SettingsRowItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(24.dp),
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun <T> SingleChoiceDialog(
    title: String,
    options: List<T>,
    selectedOption: T,
    labelProvider: @Composable (T) -> String,
    onOptionSelected: (T) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column {
                options.forEach { option ->
                    val isSelected = option == selectedOption
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = isSelected,
                                onClick = { onOptionSelected(option) },
                                role = Role.RadioButton,
                            )
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = null,
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = labelProvider(option),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.btn_cancel))
            }
        },
    )
}
