package com.example.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.settings.AudioSourceOption
import com.example.data.settings.OutputAspectRatio
import com.example.data.settings.RecorderSettings
import com.example.data.settings.SettingsRepository
import com.example.data.settings.VideoCodecOption
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val repository: SettingsRepository,
) : ViewModel() {

    val settings: StateFlow<RecorderSettings> = repository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = RecorderSettings(),
        )

    fun setAudioSource(source: AudioSourceOption) {
        viewModelScope.launch { repository.setAudioSource(source) }
    }

    fun setAudioBitrate(kbps: Int) {
        viewModelScope.launch { repository.setAudioBitrateKbps(kbps) }
    }

    fun setVideoCodec(codec: VideoCodecOption) {
        viewModelScope.launch { repository.setVideoCodec(codec) }
    }

    fun setVideoQuality(quality: Int) {
        viewModelScope.launch { repository.setVideoQuality(quality) }
    }

    fun setFps(fps: Int) {
        viewModelScope.launch { repository.setFps(fps) }
    }

    fun setVideoBitrate(mbps: Int) {
        viewModelScope.launch { repository.setVideoBitrateMbps(mbps) }
    }

    fun setDefaultAspect(aspect: OutputAspectRatio) {
        viewModelScope.launch { repository.setDefaultAspect(aspect) }
    }

    fun resetDefaults() {
        viewModelScope.launch { repository.resetToDefaults() }
    }
}
