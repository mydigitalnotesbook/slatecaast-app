package com.example.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Original SlateCast Material 3 Color Palette
 * - Primary: Deep Indigo
 * - Accent: Warm Coral (Secondary)
 * - Surfaces & Background: Neutral Cool-Grey
 */

// Light Palette
val DeepIndigoPrimaryLight = Color(0xFF1E2F65)
val DeepIndigoOnPrimaryLight = Color(0xFFFFFFFF)
val DeepIndigoPrimaryContainerLight = Color(0xFFDAE2FF)
val DeepIndigoOnPrimaryContainerLight = Color(0xFF00184A)

val WarmCoralSecondaryLight = Color(0xFFD64D3B)
val WarmCoralOnSecondaryLight = Color(0xFFFFFFFF)
val WarmCoralSecondaryContainerLight = Color(0xFFFFDAD4)
val WarmCoralOnSecondaryContainerLight = Color(0xFF3B0904)

val SlateIndigoTertiaryLight = Color(0xFF3C5F8A)
val SlateIndigoOnTertiaryLight = Color(0xFFFFFFFF)
val SlateIndigoTertiaryContainerLight = Color(0xFFD3E4FF)
val SlateIndigoOnTertiaryContainerLight = Color(0xFF001C38)

val CoolGreyBackgroundLight = Color(0xFFF7F9FC)
val CoolGreyOnBackgroundLight = Color(0xFF161920)
val CoolGreySurfaceLight = Color(0xFFF0F3F8)
val CoolGreyOnSurfaceLight = Color(0xFF161920)
val CoolGreySurfaceVariantLight = Color(0xFFDFE3EB)
val CoolGreyOnSurfaceVariantLight = Color(0xFF414650)
val CoolGreyOutlineLight = Color(0xFF727782)
val CoolGreyOutlineVariantLight = Color(0xFFC3C7D1)

// Dark Palette
val DeepIndigoPrimaryDark = Color(0xFFB1C6FF)
val DeepIndigoOnPrimaryDark = Color(0xFF032A75)
val DeepIndigoPrimaryContainerDark = Color(0xFF223F88)
val DeepIndigoOnPrimaryContainerDark = Color(0xFFDAE2FF)

val WarmCoralSecondaryDark = Color(0xFFFF8A78)
val WarmCoralOnSecondaryDark = Color(0xFF5E160D)
val WarmCoralSecondaryContainerDark = Color(0xFF7E2A20)
val WarmCoralOnSecondaryContainerDark = Color(0xFFFFDAD4)

val SlateIndigoTertiaryDark = Color(0xFFA5C8F8)
val SlateIndigoOnTertiaryDark = Color(0xFF02315A)
val SlateIndigoTertiaryContainerDark = Color(0xFF224771)
val SlateIndigoOnTertiaryContainerDark = Color(0xFFD3E4FF)

val CoolGreyBackgroundDark = Color(0xFF0E1116)
val CoolGreyOnBackgroundDark = Color(0xFFE2E6EE)
val CoolGreySurfaceDark = Color(0xFF15181F)
val CoolGreyOnSurfaceDark = Color(0xFFE2E6EE)
val CoolGreySurfaceVariantDark = Color(0xFF252A34)
val CoolGreyOnSurfaceVariantDark = Color(0xFFC2C7D2)
val CoolGreyOutlineDark = Color(0xFF8C919D)
val CoolGreyOutlineVariantDark = Color(0xFF424752)
