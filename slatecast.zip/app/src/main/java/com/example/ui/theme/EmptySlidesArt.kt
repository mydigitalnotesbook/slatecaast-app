package com.example.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * Empty-state illustration drawn with Compose Canvas.
 * Renders a slide canvas frame with a centered plus sign using current Material 3 theme colours.
 */
@Composable
fun EmptySlidesArt(
    modifier: Modifier = Modifier,
) {
    val slideBgColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    val slideBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
    val plusColor = MaterialTheme.colorScheme.secondary
    val headerBarColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f)

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.size(width = 160.dp, height = 100.dp)) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // 1. Slide frame background
            val cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx())
            drawRoundRect(
                color = slideBgColor,
                topLeft = Offset(4.dp.toPx(), 4.dp.toPx()),
                size = Size(canvasWidth - 8.dp.toPx(), canvasHeight - 8.dp.toPx()),
                cornerRadius = cornerRadius,
            )

            // 2. Dashed slide frame outline
            val strokeWidth = 2.dp.toPx()
            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
            drawRoundRect(
                color = slideBorderColor,
                topLeft = Offset(4.dp.toPx(), 4.dp.toPx()),
                size = Size(canvasWidth - 8.dp.toPx(), canvasHeight - 8.dp.toPx()),
                cornerRadius = cornerRadius,
                style = Stroke(width = strokeWidth, pathEffect = dashEffect),
            )

            // 3. Subtle top slide header accent bar
            drawRoundRect(
                color = headerBarColor,
                topLeft = Offset(16.dp.toPx(), 14.dp.toPx()),
                size = Size(canvasWidth * 0.35f, 5.dp.toPx()),
                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
            )

            // 4. Centered Plus Sign
            val centerX = canvasWidth / 2f
            val centerY = canvasHeight / 2f
            val plusArmLength = 14.dp.toPx()
            val plusStrokeWidth = 3.5.dp.toPx()

            // Horizontal arm
            drawLine(
                color = plusColor,
                start = Offset(centerX - plusArmLength, centerY),
                end = Offset(centerX + plusArmLength, centerY),
                strokeWidth = plusStrokeWidth,
                cap = StrokeCap.Round,
            )

            // Vertical arm
            drawLine(
                color = plusColor,
                start = Offset(centerX, centerY - plusArmLength),
                end = Offset(centerX, centerY + plusArmLength),
                strokeWidth = plusStrokeWidth,
                cap = StrokeCap.Round,
            )
        }
    }
}
