package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val SlateCastLightColorScheme = lightColorScheme(
    primary = DeepIndigoPrimaryLight,
    onPrimary = DeepIndigoOnPrimaryLight,
    primaryContainer = DeepIndigoPrimaryContainerLight,
    onPrimaryContainer = DeepIndigoOnPrimaryContainerLight,
    secondary = WarmCoralSecondaryLight,
    onSecondary = WarmCoralOnSecondaryLight,
    secondaryContainer = WarmCoralSecondaryContainerLight,
    onSecondaryContainer = WarmCoralOnSecondaryContainerLight,
    tertiary = SlateIndigoTertiaryLight,
    onTertiary = SlateIndigoOnTertiaryLight,
    tertiaryContainer = SlateIndigoTertiaryContainerLight,
    onTertiaryContainer = SlateIndigoOnTertiaryContainerLight,
    background = CoolGreyBackgroundLight,
    onBackground = CoolGreyOnBackgroundLight,
    surface = CoolGreySurfaceLight,
    onSurface = CoolGreyOnSurfaceLight,
    surfaceVariant = CoolGreySurfaceVariantLight,
    onSurfaceVariant = CoolGreyOnSurfaceVariantLight,
    outline = CoolGreyOutlineLight,
    outlineVariant = CoolGreyOutlineVariantLight,
)

private val SlateCastDarkColorScheme = darkColorScheme(
    primary = DeepIndigoPrimaryDark,
    onPrimary = DeepIndigoOnPrimaryDark,
    primaryContainer = DeepIndigoPrimaryContainerDark,
    onPrimaryContainer = DeepIndigoOnPrimaryContainerDark,
    secondary = WarmCoralSecondaryDark,
    onSecondary = WarmCoralOnSecondaryDark,
    secondaryContainer = WarmCoralSecondaryContainerDark,
    onSecondaryContainer = WarmCoralOnSecondaryContainerDark,
    tertiary = SlateIndigoTertiaryDark,
    onTertiary = SlateIndigoOnTertiaryDark,
    tertiaryContainer = SlateIndigoTertiaryContainerDark,
    onTertiaryContainer = SlateIndigoOnTertiaryContainerDark,
    background = CoolGreyBackgroundDark,
    onBackground = CoolGreyOnBackgroundDark,
    surface = CoolGreySurfaceDark,
    onSurface = CoolGreyOnSurfaceDark,
    surfaceVariant = CoolGreySurfaceVariantDark,
    onSurfaceVariant = CoolGreyOnSurfaceVariantDark,
    outline = CoolGreyOutlineDark,
    outlineVariant = CoolGreyOutlineVariantDark,
)

@Composable
fun SlateCastTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep original curated palette by default
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> SlateCastDarkColorScheme
        else -> SlateCastLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content,
    )
}
