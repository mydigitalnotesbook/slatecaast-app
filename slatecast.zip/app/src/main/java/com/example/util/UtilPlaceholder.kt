package com.example.util

/**
 * Utility functions for stage geometry, video dimensions, and file paths.
 */
object SlateCastUtils {
    const val VIDEO_WIDTH_LANDSCAPE = 1920
    const val VIDEO_HEIGHT_LANDSCAPE = 1080

    const val VIDEO_WIDTH_PORTRAIT = 1080
    const val VIDEO_HEIGHT_PORTRAIT = 1920

    /**
     * Helper to compute target recording dimensions.
     */
    fun getVideoDimensions(isLandscape: Boolean): Pair<Int, Int> {
        return if (isLandscape) {
            Pair(VIDEO_WIDTH_LANDSCAPE, VIDEO_HEIGHT_LANDSCAPE)
        } else {
            Pair(VIDEO_WIDTH_PORTRAIT, VIDEO_HEIGHT_PORTRAIT)
        }
    }
}
