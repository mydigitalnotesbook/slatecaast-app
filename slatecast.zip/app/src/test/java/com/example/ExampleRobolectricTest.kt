package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Teaching Recorder Vertical (9:16)", appName)
    assertEquals("support@slatecast.app", context.getString(R.string.my_support_email))
    assertEquals("https://slatecast.app/privacy", context.getString(R.string.privacy_url))
  }

  @Test
  fun `verify outputSize calculation`() {
    val landscape1080 = com.example.data.settings.outputSize(com.example.data.settings.OutputAspectRatio.LANDSCAPE_16_9, 1080)
    assertEquals(1920, landscape1080.width)
    assertEquals(1080, landscape1080.height)

    val portrait1080 = com.example.data.settings.outputSize(com.example.data.settings.OutputAspectRatio.PORTRAIT_9_16, 1080)
    assertEquals(1080, portrait1080.width)
    assertEquals(1920, portrait1080.height)

    val landscape720 = com.example.data.settings.outputSize(com.example.data.settings.OutputAspectRatio.LANDSCAPE_16_9, 720)
    assertEquals(1280, landscape720.width)
    assertEquals(720, landscape720.height)

    val portrait720 = com.example.data.settings.outputSize(com.example.data.settings.OutputAspectRatio.PORTRAIT_9_16, 720)
    assertEquals(720, portrait720.width)
    assertEquals(1280, portrait720.height)
  }

  @Test
  fun `verify default recorder settings values`() {
    val defaultSettings = com.example.data.settings.RecorderSettings()
    assertEquals(com.example.data.settings.AudioSourceOption.MIC, defaultSettings.audioSource)
    assertEquals(128, defaultSettings.audioBitrateKbps)
    assertEquals(com.example.data.settings.VideoCodecOption.H264, defaultSettings.videoCodec)
    assertEquals(1080, defaultSettings.videoQuality)
    assertEquals(30, defaultSettings.fps)
    assertEquals(4, defaultSettings.videoBitrateMbps)
    assertEquals(com.example.data.settings.OutputAspectRatio.LANDSCAPE_16_9, defaultSettings.defaultAspect)
  }

  @Test
  fun `verify SlideProjectRepository blank slides, reordering, and deleting`() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = com.example.data.storage.SlideProjectRepositoryImpl(context)

    val projectId = "test_project_16x9"
    val project = repo.getProject(projectId)
    org.junit.Assert.assertNotNull(project)
    assertEquals(0, project?.slides?.size ?: -1)

    // Add white blank slide
    val whiteSlide = repo.addBlankSlide(projectId, isWhite = true)
    assertEquals(1, whiteSlide.pageNumber)
    assertEquals("blank_white", whiteSlide.sourceType)

    // Add black blank slide
    val blackSlide = repo.addBlankSlide(projectId, isWhite = false)
    assertEquals(2, blackSlide.pageNumber)
    assertEquals("blank_black", blackSlide.sourceType)

    val afterAdding = repo.getProject(projectId)
    assertEquals(2, afterAdding?.slides?.size)

    // Reorder: move slide 0 to 1
    repo.reorderSlides(projectId, 0, 1)
    val afterReorder = repo.getProject(projectId)
    assertEquals(2, afterReorder?.slides?.size)
    assertEquals(blackSlide.id, afterReorder?.slides?.get(0)?.id)
    assertEquals(1, afterReorder?.slides?.get(0)?.pageNumber)
    assertEquals(whiteSlide.id, afterReorder?.slides?.get(1)?.id)
    assertEquals(2, afterReorder?.slides?.get(1)?.pageNumber)

    // Delete first slide
    repo.deleteSlide(projectId, blackSlide.id)
    val afterDelete = repo.getProject(projectId)
    assertEquals(1, afterDelete?.slides?.size)
    assertEquals(whiteSlide.id, afterDelete?.slides?.get(0)?.id)
    assertEquals(1, afterDelete?.slides?.get(0)?.pageNumber)
  }

  @Test
  fun `verify StageViewModel slide navigation and bounds`() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = com.example.data.storage.SlideProjectRepositoryImpl(context)

    val projectId = "test_stage_nav"
    repo.addBlankSlide(projectId, isWhite = true)
    repo.addBlankSlide(projectId, isWhite = false)
    repo.addBlankSlide(projectId, isWhite = true)

    val viewModel = com.example.ui.recorder.StageViewModel(projectId, repo)
    // Wait for project state to emit
    var attempts = 0
    while (viewModel.projectState.value?.slides.isNullOrEmpty() && attempts < 20) {
      kotlinx.coroutines.delay(50)
      attempts++
    }

    assertEquals(0, viewModel.currentSlideIndex.value)

    viewModel.nextSlide()
    assertEquals(1, viewModel.currentSlideIndex.value)

    viewModel.nextSlide()
    assertEquals(2, viewModel.currentSlideIndex.value)

    // Cannot go beyond last slide
    viewModel.nextSlide()
    assertEquals(2, viewModel.currentSlideIndex.value)

    viewModel.previousSlide()
    assertEquals(1, viewModel.currentSlideIndex.value)

    viewModel.goToSlide(0)
    assertEquals(0, viewModel.currentSlideIndex.value)

    // Cannot go below zero
    viewModel.previousSlide()
    assertEquals(0, viewModel.currentSlideIndex.value)
  }

  @Test
  fun `verify DrawingState stroke addition, undo, redo, clearPage, and stroke eraser`() {
    val drawingState = com.example.recorder.canvas.DrawingState()
    val slide0 = 0
    val slide1 = 1

    assertEquals(0, drawingState.getStrokesForSlide(slide0).size)
    assertFalse(drawingState.canUndo(slide0))
    assertFalse(drawingState.canRedo(slide0))

    val strokeA = com.example.recorder.canvas.Stroke(
      tool = com.example.recorder.canvas.Tool.PEN,
      colorArgb = android.graphics.Color.RED,
      widthNorm = 0.006f,
      points = listOf(android.graphics.PointF(0.1f, 0.1f), android.graphics.PointF(0.2f, 0.2f))
    )
    val strokeB = com.example.recorder.canvas.Stroke(
      tool = com.example.recorder.canvas.Tool.HIGHLIGHTER,
      colorArgb = android.graphics.Color.BLUE,
      widthNorm = 0.010f,
      points = listOf(android.graphics.PointF(0.5f, 0.5f), android.graphics.PointF(0.6f, 0.6f))
    )

    // Add to slide 0
    drawingState.addStroke(slide0, strokeA)
    drawingState.addStroke(slide0, strokeB)
    assertEquals(2, drawingState.getStrokesForSlide(slide0).size)
    assertEquals(0, drawingState.getStrokesForSlide(slide1).size)
    assertTrue(drawingState.canUndo(slide0))

    // Undo stroke B
    drawingState.undo(slide0)
    assertEquals(1, drawingState.getStrokesForSlide(slide0).size)
    assertTrue(drawingState.canRedo(slide0))

    // Redo stroke B
    drawingState.redo(slide0)
    assertEquals(2, drawingState.getStrokesForSlide(slide0).size)
    assertFalse(drawingState.canRedo(slide0))

    // Test stroke eraser at point near stroke A (0.1, 0.1)
    val erased = drawingState.eraseStrokesAt(slide0, 0.11f, 0.11f, radiusNorm = 0.03f)
    assertTrue(erased)
    assertEquals(1, drawingState.getStrokesForSlide(slide0).size)
    assertEquals(strokeB, drawingState.getStrokesForSlide(slide0)[0])

    // Clear Page
    drawingState.clearPage(slide0)
    assertEquals(0, drawingState.getStrokesForSlide(slide0).size)

    // Verify StrokeRenderer executes safely without error on bitmap canvas
    val bitmap = android.graphics.Bitmap.createBitmap(1920, 1080, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    com.example.recorder.canvas.StrokeRenderer.drawStrokes(canvas, listOf(strokeA, strokeB), 1920, 1080)
    bitmap.recycle()
  }

  @Test
  fun `verify StageViewModel toolbar state for tools, colors, collapse, and recording`() {
    val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
    val repo = com.example.data.storage.SlideProjectRepositoryImpl(context)
    val viewModel = com.example.ui.recorder.StageViewModel("test-toolbar-proj", repo)

    // Initial tool is PEN
    assertEquals(com.example.recorder.canvas.Tool.PEN, viewModel.currentTool.value)
    viewModel.setTool(com.example.recorder.canvas.Tool.HIGHLIGHTER)
    assertEquals(com.example.recorder.canvas.Tool.HIGHLIGHTER, viewModel.currentTool.value)
    viewModel.setTool(com.example.recorder.canvas.Tool.ERASER)
    assertEquals(com.example.recorder.canvas.Tool.ERASER, viewModel.currentTool.value)

    // Palette Color
    assertEquals(com.example.recorder.canvas.PaletteColor.RED, viewModel.currentColor.value)
    viewModel.setColor(com.example.recorder.canvas.PaletteColor.BLUE)
    assertEquals(com.example.recorder.canvas.PaletteColor.BLUE, viewModel.currentColor.value)

    // Stroke width
    viewModel.setWidthNorm(0.015f)
    assertEquals(0.015f, viewModel.widthNorm.value, 0.0001f)

    // Recording toggle
    assertFalse(viewModel.isRecording.value)
    viewModel.toggleRecording()
    assertTrue(viewModel.isRecording.value)
    viewModel.toggleRecording()
    assertFalse(viewModel.isRecording.value)

    // Collapse toggle
    assertFalse(viewModel.isToolbarCollapsed.value)
    viewModel.toggleToolbarCollapse()
    assertTrue(viewModel.isToolbarCollapsed.value)
    viewModel.toggleToolbarCollapse()
    assertFalse(viewModel.isToolbarCollapsed.value)

    // Color palette toggle
    assertFalse(viewModel.isColorPaletteOpen.value)
    viewModel.toggleColorPalette()
    assertTrue(viewModel.isColorPaletteOpen.value)
    viewModel.closeColorPalette()
    assertFalse(viewModel.isColorPaletteOpen.value)

    // Stub timer text
    assertEquals("00:00", viewModel.timerText.value)
  }

  @Test
  fun `verify StageRenderer render and saveScreenshot at outputSize`() {
    val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
    val drawingState = com.example.recorder.canvas.DrawingState()
    val stroke = com.example.recorder.canvas.Stroke(
      tool = com.example.recorder.canvas.Tool.PEN,
      colorArgb = android.graphics.Color.GREEN,
      widthNorm = 0.008f,
      points = listOf(android.graphics.PointF(0.2f, 0.2f), android.graphics.PointF(0.8f, 0.8f)),
    )
    drawingState.addStroke(0, stroke)

    // Create a temporary slide file
    val slideFile = java.io.File(context.cacheDir, "test_slide_render.jpg")
    val slideBitmap = android.graphics.Bitmap.createBitmap(800, 600, android.graphics.Bitmap.Config.ARGB_8888)
    java.io.FileOutputStream(slideFile).use { out ->
      slideBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, out)
    }
    slideBitmap.recycle()

    val testSlide = com.example.data.storage.SlideItem(
      id = "test-slide-1",
      pageNumber = 1,
      filePath = slideFile.absolutePath,
    )

    val stageRenderer = com.example.recorder.canvas.StageRenderer(
      context = context,
      slidesProvider = { listOf(testSlide) },
      currentSlideIndexProvider = { 0 },
      drawingStateProvider = { drawingState },
    )

    // Verify render on landscape canvas
    val landscapeBitmap = android.graphics.Bitmap.createBitmap(1920, 1080, android.graphics.Bitmap.Config.ARGB_8888)
    val landscapeCanvas = android.graphics.Canvas(landscapeBitmap)
    stageRenderer.render(landscapeCanvas, 1920, 1080)
    assertNotNull(landscapeBitmap)
    landscapeBitmap.recycle()

    // Verify render on portrait canvas
    val portraitBitmap = android.graphics.Bitmap.createBitmap(1080, 1920, android.graphics.Bitmap.Config.ARGB_8888)
    val portraitCanvas = android.graphics.Canvas(portraitBitmap)
    stageRenderer.render(portraitCanvas, 1080, 1920)
    assertNotNull(portraitBitmap)
    portraitBitmap.recycle()

    // Verify saveScreenshot in landscape and portrait
    val landscapeUri = stageRenderer.saveScreenshot(com.example.data.settings.OutputAspectRatio.LANDSCAPE_16_9, 1080)
    assertNotNull(landscapeUri)

    val portraitUri = stageRenderer.saveScreenshot(com.example.data.settings.OutputAspectRatio.PORTRAIT_9_16, 1080)
    assertNotNull(portraitUri)

    stageRenderer.release()
  }

  @Test
  fun `verify RecordingClock monotonic PTS and pause tracking`() {
    val clock = com.example.recorder.engine.RecordingClock()
    assertEquals(0L, clock.currentPtsUs())
    assertFalse(clock.isStarted())
    assertFalse(clock.isPaused())

    clock.start()
    assertTrue(clock.isStarted())
    assertFalse(clock.isPaused())

    Thread.sleep(15)
    val pts1 = clock.currentPtsUs()
    assertTrue(pts1 > 0L)

    // Pause
    clock.pause()
    assertTrue(clock.isPaused())
    val pausedPts = clock.currentPtsUs()
    Thread.sleep(25)
    val pausedPtsAfterSleep = clock.currentPtsUs()
    assertEquals(pausedPts, pausedPtsAfterSleep)

    // Resume
    clock.resume()
    assertFalse(clock.isPaused())
    Thread.sleep(15)
    val pts2 = clock.currentPtsUs()
    assertTrue(pts2 > pausedPts)

    clock.reset()
    assertFalse(clock.isStarted())
    assertEquals(0L, clock.currentPtsUs())
  }

  @Test
  fun `verify VideoStoreHelper creates valid video output`() {
    val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
    val output = com.example.recorder.engine.VideoStoreHelper.createOutputUri(context, "test_lecture")
    assertNotNull(output.uri)
    assertNotNull(output.pfd)
    output.pfd.close()

    com.example.recorder.engine.VideoStoreHelper.publishOutputUri(context, output.uri)
  }

  @Test
  fun `verify AudioPermissionHelper check does not crash`() {
    val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
    val hasPermission = com.example.ui.recorder.hasAudioPermission(context)
    // Running in Robolectric without runtime permission grant defaults to false or true safely
    assertNotNull(hasPermission)
  }

  @Test
  fun `verify VideoItem formatting and aspect badge calculation`() {
    val landscapeItem = com.example.data.storage.VideoItem(
      id = "item1",
      uri = android.net.Uri.parse("content://media/external/video/media/1"),
      name = "Lecture_Landscape.mp4",
      durationMs = 125_000L, // 2m 5s
      sizeBytes = 15_728_640L, // 15 MB
      dateAddedMs = 1700000000000L,
      width = 1920,
      height = 1080,
    )
    assertEquals("16:9", landscapeItem.aspectBadge)
    assertEquals("02:05", landscapeItem.formattedDuration)
    assertTrue(landscapeItem.formattedSize.contains("15.0 MB"))

    val portraitItem = com.example.data.storage.VideoItem(
      id = "item2",
      uri = android.net.Uri.parse("content://media/external/video/media/2"),
      name = "Lecture_Portrait.mp4",
      durationMs = 3661_000L, // 1h 1m 1s
      sizeBytes = 512_000L, // 500 KB
      dateAddedMs = 1700000000000L,
      width = 1080,
      height = 1920,
    )
    assertEquals("9:16", portraitItem.aspectBadge)
    assertEquals("1:01:01", portraitItem.formattedDuration)
    assertTrue(portraitItem.formattedSize.contains("500 KB"))
  }

  @Test
  fun `verify VideoStore listVideos, rename, and delete on local storage`() = kotlinx.coroutines.runBlocking {
    val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
    val videoStore = com.example.data.storage.VideoStoreImpl(context)

    // Create a mock mp4 file in fallback lectures directory
    val lecturesDir = java.io.File(context.filesDir, "lectures").apply { mkdirs() }
    val testVideoFile = java.io.File(lecturesDir, "Test_Mock_Lecture.mp4")
    testVideoFile.writeBytes(ByteArray(1024))

    val videos = videoStore.listVideos()
    assertTrue(videos.isNotEmpty())
    val found = videos.find { it.name == "Test_Mock_Lecture.mp4" }
    assertNotNull(found)

    // Rename
    val renamed = videoStore.renameVideo(found!!, "Renamed_Lecture")
    assertTrue(renamed)
    val videosAfterRename = videoStore.listVideos()
    assertTrue(videosAfterRename.any { it.name == "Renamed_Lecture.mp4" })

    // Delete
    val itemToDelete = videosAfterRename.first { it.name == "Renamed_Lecture.mp4" }
    val deleted = videoStore.deleteVideo(itemToDelete)
    assertTrue(deleted)

    val videosAfterDelete = videoStore.listVideos()
    assertFalse(videosAfterDelete.any { it.name == "Renamed_Lecture.mp4" })
  }

  @Test
  fun `verify LibraryViewModel loading, selecting, and operations`(): Unit = kotlinx.coroutines.runBlocking {
    val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
    val videoStore = com.example.data.storage.VideoStoreImpl(context)
    val viewModel = com.example.ui.library.LibraryViewModel(videoStore)

    viewModel.loadVideos()
    assertNotNull(viewModel.videos.value)
    assertNull(viewModel.selectedVideo.value)

    val dummy = com.example.data.storage.VideoItem(
      id = "test-dummy",
      uri = android.net.Uri.parse("content://dummy"),
      name = "Dummy.mp4",
      durationMs = 1000L,
      sizeBytes = 1024L,
      dateAddedMs = 0L,
      width = 1920,
      height = 1080,
    )
    viewModel.selectVideo(dummy)
    assertEquals(dummy, viewModel.selectedVideo.value)
    viewModel.selectVideo(null)
    assertNull(viewModel.selectedVideo.value)
  }

  @Test
  fun `verify CapabilityChecker fallback sequence and remembered working config`() {
    val initialSettings = com.example.data.settings.RecorderSettings(
      videoCodec = com.example.data.settings.VideoCodecOption.HEVC,
      fps = 60,
      videoQuality = 1080,
      videoBitrateMbps = 8,
    )

    // Step 1: HEVC -> H264
    val retry1 = com.example.recorder.engine.CapabilityChecker.getNextRetrySettings(initialSettings)
    assertNotNull(retry1)
    assertEquals(com.example.data.settings.VideoCodecOption.H264, retry1!!.videoCodec)
    assertEquals(60, retry1.fps)
    assertEquals(1080, retry1.videoQuality)
    assertEquals(8, retry1.videoBitrateMbps)

    // Step 2: 60 fps -> 30 fps
    val retry2 = com.example.recorder.engine.CapabilityChecker.getNextRetrySettings(retry1)
    assertNotNull(retry2)
    assertEquals(com.example.data.settings.VideoCodecOption.H264, retry2!!.videoCodec)
    assertEquals(30, retry2.fps)
    assertEquals(1080, retry2.videoQuality)
    assertEquals(8, retry2.videoBitrateMbps)

    // Step 3: 1080 -> 720
    val retry3 = com.example.recorder.engine.CapabilityChecker.getNextRetrySettings(retry2)
    assertNotNull(retry3)
    assertEquals(com.example.data.settings.VideoCodecOption.H264, retry3!!.videoCodec)
    assertEquals(30, retry3.fps)
    assertEquals(720, retry3.videoQuality)
    assertEquals(8, retry3.videoBitrateMbps)

    // Step 4: bitrate -> 4 Mbps
    val retry4 = com.example.recorder.engine.CapabilityChecker.getNextRetrySettings(retry3)
    assertNotNull(retry4)
    assertEquals(com.example.data.settings.VideoCodecOption.H264, retry4!!.videoCodec)
    assertEquals(30, retry4.fps)
    assertEquals(720, retry4.videoQuality)
    assertEquals(4, retry4.videoBitrateMbps)

    // Step 5: exhausted -> null
    val retry5 = com.example.recorder.engine.CapabilityChecker.getNextRetrySettings(retry4)
    assertNull(retry5)

    // Remember working config
    com.example.recorder.engine.CapabilityChecker.rememberWorkingConfig(retry4)
    assertEquals(retry4, com.example.recorder.engine.CapabilityChecker.rememberedWorkingSettings)
  }

  @Test
  fun `verify RecorderController dismissFailure returns to Idle state`() {
    val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
    val controller = com.example.recorder.engine.RecorderController(
      context,
      kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Unconfined)
    )

    assertEquals(com.example.recorder.engine.RecordingSessionState.Idle, controller.sessionState.value)
    // If dismissFailure is called on Idle, it stays Idle
    controller.dismissFailure()
    assertEquals(com.example.recorder.engine.RecordingSessionState.Idle, controller.sessionState.value)
  }

  @Test
  fun `verify FaceCamSource lifecycle, position coercion, and compositing`() {
    val faceCamSource = com.example.recorder.engine.FaceCamSource()
    assertFalse(faceCamSource.isEnabled.value)

    faceCamSource.setEnabled(true)
    assertTrue(faceCamSource.isEnabled.value)

    faceCamSource.setSize(com.example.recorder.engine.FaceCamSize.MEDIUM)
    assertEquals(com.example.recorder.engine.FaceCamSize.MEDIUM, faceCamSource.size.value)

    faceCamSource.updatePosition(0.01f, 1.5f) // Should coerce between 0.08 and 0.92
    assertEquals(0.08f, faceCamSource.xNorm.value, 0.001f)
    assertEquals(0.92f, faceCamSource.yNorm.value, 0.001f)

    // Verify compositing doesn't throw even with a dummy bitmap
    val dummyFrame = android.graphics.Bitmap.createBitmap(100, 100, android.graphics.Bitmap.Config.ARGB_8888)
    faceCamSource.updateFrame(dummyFrame)
    val targetBitmap = android.graphics.Bitmap.createBitmap(1920, 1080, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(targetBitmap)
    faceCamSource.composite(canvas, 1920, 1080)

    faceCamSource.release()
    assertFalse(faceCamSource.isEnabled.value)
  }

  @Test
  fun `verify SlideSource WebSlide and ImageSlide render without exceptions`() {
    val dummyBitmap = android.graphics.Bitmap.createBitmap(800, 600, android.graphics.Bitmap.Config.ARGB_8888)
    val targetBitmap = android.graphics.Bitmap.createBitmap(1920, 1080, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(targetBitmap)

    val webSlide = com.example.recorder.canvas.WebSlide(
      id = "web-1",
      initialUrl = "https://en.wikipedia.org",
      frameProvider = { dummyBitmap },
    )
    webSlide.render(canvas, 1920, 1080)

    val imageSlide = com.example.recorder.canvas.ImageSlide(
      slideItem = com.example.data.storage.SlideItem(
        id = "img-1",
        filePath = "/dummy/path.jpg",
        pageNumber = 1,
      ),
      bitmapProvider = { dummyBitmap },
    )
    imageSlide.render(canvas, 1920, 1080)
  }

  @Test
  fun `verify SlideProjectRepository addWebSlide adds web slide to deck`() = kotlinx.coroutines.runBlocking {
    val context = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>()
    val repo = com.example.data.storage.SlideProjectRepositoryImpl(context)

    val project = repo.getProject("test_web_project") ?: com.example.data.storage.ProjectInfo(id = "test_web_project", title = "Web Deck")
    repo.saveProject(project)

    val webSlide = repo.addWebSlide("test_web_project", "https://developer.android.com")
    assertEquals("web", webSlide.sourceType)
    assertNotNull(webSlide.filePath)
    assertTrue(java.io.File(webSlide.filePath).exists())

    val updatedProject = repo.getProject("test_web_project")
    assertNotNull(updatedProject)
    assertTrue(updatedProject!!.slides.any { it.sourceType == "web" })
  }
}
